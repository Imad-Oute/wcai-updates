<?php return array('dependencies' => array('react-jsx-runtime', 'wp-element'), 'version' => 'c0cb82098856c8c0f29d');
