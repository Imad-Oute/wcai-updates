"use strict";(()=>{function o(i,e,t){let a=document.createElement(i);return _(a,e),v(a,t),a}function _(i,e){if(e){for(let[t,a]of Object.entries(e))if(a!==void 0){if(t==="className"){i.className=String(a);continue}if(t.startsWith("on")&&typeof a=="function"){i.addEventListener(t.slice(2).toLowerCase(),a);continue}if(typeof a=="boolean"){a&&i.setAttribute(t,"");continue}i.setAttribute(t,String(a))}}}function v(i,e){if(e)for(let t of e)t===!1||t===null||t===void 0||i.appendChild(typeof t=="string"?document.createTextNode(t):t)}function l(i,e){for(;i.firstChild;)i.removeChild(i.firstChild);v(i,e)}function y(i){let e=[],t=i;for(;;){let a=t.indexOf("**"),n=a===-1?-1:t.indexOf("**",a+2);if(a===-1||n===-1)return t!==""&&e.push(t),e;a>0&&e.push(t.slice(0,a));let r=document.createElement("strong");r.textContent=t.slice(a+2,n),e.push(r),t=t.slice(n+2)}}var m="http://www.w3.org/2000/svg";function d(i,e=18){let t=document.createElementNS(m,"svg");t.setAttribute("viewBox","0 0 24 24"),t.setAttribute("width",String(e)),t.setAttribute("height",String(e)),t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.9"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),t.setAttribute("aria-hidden","true"),t.setAttribute("focusable","false");for(let a of i){let n=document.createElementNS(m,"path");n.setAttribute("d",a),t.appendChild(n)}return t}function w(i=14){let e=d(["M12 16v-4M12 8h.01"],i),t=document.createElementNS(m,"circle");return t.setAttribute("cx","12"),t.setAttribute("cy","12"),t.setAttribute("r","9"),e.insertBefore(t,e.firstChild),e}var B="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-3.9-.9L3 20l1.4-4.6a8.5 8.5 0 0 1-.9-3.9A8.38 8.38 0 0 1 12 3a8.38 8.38 0 0 1 9 8.5Z",D="M18 6 6 18M6 6l12 12",H="M12 19V5M5 12l7-7 7 7",h=i=>d([B],i),T=i=>d([D],i),k=i=>d([H],i),C=i=>w(i);var p=class{constructor(e){this.previouslyFocused=null;this.onKeydown=e=>{if(e.key!=="Tab")return;let t=this.focusableElements(),a=t[0],n=t[t.length-1];if(!a||!n)return;let r=this.activeElement();e.shiftKey&&r===a?(e.preventDefault(),n.focus()):!e.shiftKey&&r===n&&(e.preventDefault(),a.focus())};this.root=e}activeElement(){var t;return(t=this.root.getRootNode().activeElement)!=null?t:null}focusableElements(){return Array.from(this.root.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')).filter(t=>t.offsetParent!==null)}activate(){var t;this.previouslyFocused=this.activeElement(),this.root.addEventListener("keydown",this.onKeydown),((t=this.focusableElements()[0])!=null?t:this.root).focus()}deactivate(){var e;this.root.removeEventListener("keydown",this.onKeydown),(e=this.previouslyFocused)==null||e.focus()}};function b(i){let e=/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(i.trim()),t=e==null?void 0:e[1];if(!t)return null;let a=t.length===3?t.split("").map(r=>r+r).join(""):t,n=parseInt(a,16);return[n>>16&255,n>>8&255,n&255]}function A([i,e,t]){let a=n=>{let r=n/255;return r<=.03928?r/12.92:Math.pow((r+.055)/1.055,2.4)};return .2126*a(i)+.7152*a(e)+.0722*a(t)}function W(i,e){let t=b(i),a=b(e);if(!t||!a)return null;let n=A(t),r=A(a),s=Math.max(n,r),c=Math.min(n,r);return(s+.05)/(c+.05)}function z(i,e){let t=b(i);if(!t)return null;let a=1-e,n=s=>Math.max(0,Math.min(255,Math.round(s*a))),r=s=>s.toString(16).padStart(2,"0");return`#${r(n(t[0]))}${r(n(t[1]))}${r(n(t[2]))}`}function L(i,e){let t=W(i,e);return t===null||t>=4.5?null:z(i,.15)}async function S(i){try{return await i.json()}catch{return null}}function q(i){return typeof i=="object"&&i!==null&&typeof i.code=="string"&&typeof i.message=="string"}function j(i){if(typeof i!="object"||i===null)return!1;let e=i;return typeof e.reply=="string"&&(e.routing==="direct"||e.routing==="hedged"||e.routing==="deflected")&&Array.isArray(e.suggestions)&&typeof e.session_id=="string"&&typeof e.detected_locale=="string"&&typeof e.quota_remaining=="number"}async function E(i,e,t,a){try{let n=await fetch(`${i}/v1/auth/session`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({widget_token:e,origin:t}),signal:a,credentials:"omit"});if(!n.ok)return null;let r=await S(n);return typeof r=="object"&&r!==null&&typeof r.session_token=="string"?r.session_token:null}catch{return null}}async function x(i,e,t,a){let n={"content-type":"application/json"},r={...t};e.sessionToken?n.authorization=`Bearer ${e.sessionToken}`:r.widget_token=e.widgetToken;let s;try{s=await fetch(`${i}/v1/chat`,{method:"POST",headers:n,body:JSON.stringify(r),signal:a,credentials:"omit"})}catch(f){if(f instanceof DOMException&&f.name==="AbortError")throw f;return{kind:"error",status:0,error:null}}let c=await S(s);return s.ok&&j(c)?{kind:"ok",data:c}:{kind:"error",status:s.status,error:q(c)?c:null}}var N={openChatAriaLabel:"Open chat assistant",closeChatAriaLabel:"Close chat",askQuestionAriaLabel:"Ask a question",sendMessageAriaLabel:"Send message",dialogAriaLabel:"Store Chat Assistant",conversationAriaLabel:"Conversation",headerTitle:"Store Assistant",headerStatus:"Online",headerStatusUnavailable:"Unavailable",disclosureText:"You are chatting with an AI assistant.",welcomeText:"Hi! I can answer questions about our products, prices, and stock. What are you looking for?",placeholder:"Ask a question\u2026",typingLabel:"Assistant is typing\u2026",stillWorkingText:"Still working on it\u2026",timeoutFallbackText:"This is taking longer than expected. ",contactLinkText:"Contact us",hedgeDisclaimer:"This may not be fully up to date \u2014 please confirm on the product page.",quotaNoticeText:"Chat is taking a short break and will be back soon.",unreachableText:"Warming up \u2014 reconnecting\u2026",retryButtonText:"Retry",youSaidPrefix:"You said: ",assistantSaidPrefix:"Assistant said: "},O={openChatAriaLabel:"Ouvrir l'assistant de chat",closeChatAriaLabel:"Fermer le chat",askQuestionAriaLabel:"Poser une question",sendMessageAriaLabel:"Envoyer le message",dialogAriaLabel:"Assistant de chat de la boutique",conversationAriaLabel:"Conversation",headerTitle:"Assistant de la boutique",headerStatus:"En ligne",headerStatusUnavailable:"Indisponible",disclosureText:"Vous discutez avec un assistant IA.",welcomeText:"Bonjour ! Je peux r\xE9pondre \xE0 vos questions sur nos produits, leurs prix et leur disponibilit\xE9. Que cherchez-vous ?",placeholder:"Posez une question\u2026",typingLabel:"L'assistant est en train d'\xE9crire\u2026",stillWorkingText:"Toujours en cours\u2026",timeoutFallbackText:"Cela prend plus de temps que pr\xE9vu. ",contactLinkText:"Nous contacter",hedgeDisclaimer:"Cette information n'est peut-\xEAtre plus \xE0 jour \u2014 merci de v\xE9rifier sur la page du produit.",quotaNoticeText:"Le chat fait une courte pause et sera bient\xF4t de retour.",unreachableText:"Reconnexion en cours\u2026",retryButtonText:"R\xE9essayer",youSaidPrefix:"Vous avez dit : ",assistantSaidPrefix:"L'assistant a dit : "},F={openChatAriaLabel:"Abrir el asistente de chat",closeChatAriaLabel:"Cerrar el chat",askQuestionAriaLabel:"Hacer una pregunta",sendMessageAriaLabel:"Enviar mensaje",dialogAriaLabel:"Asistente de chat de la tienda",conversationAriaLabel:"Conversaci\xF3n",headerTitle:"Asistente de la tienda",headerStatus:"En l\xEDnea",headerStatusUnavailable:"No disponible",disclosureText:"Est\xE1s chateando con un asistente de IA.",welcomeText:"\xA1Hola! Puedo responder preguntas sobre nuestros productos, precios y disponibilidad. \xBFQu\xE9 est\xE1s buscando?",placeholder:"Haz una pregunta\u2026",typingLabel:"El asistente est\xE1 escribiendo\u2026",stillWorkingText:"Seguimos trabajando en ello\u2026",timeoutFallbackText:"Esto est\xE1 tardando m\xE1s de lo esperado. ",contactLinkText:"Cont\xE1ctanos",hedgeDisclaimer:"Esta informaci\xF3n puede no estar totalmente actualizada \u2014 conf\xEDrmalo en la p\xE1gina del producto.",quotaNoticeText:"El chat est\xE1 en una breve pausa y volver\xE1 pronto.",unreachableText:"Reconectando\u2026",retryButtonText:"Reintentar",youSaidPrefix:"T\xFA dijiste: ",assistantSaidPrefix:"El asistente dijo: "},U={openChatAriaLabel:"Chat-Assistenten \xF6ffnen",closeChatAriaLabel:"Chat schlie\xDFen",askQuestionAriaLabel:"Frage stellen",sendMessageAriaLabel:"Nachricht senden",dialogAriaLabel:"Chat-Assistent des Shops",conversationAriaLabel:"Unterhaltung",headerTitle:"Shop-Assistent",headerStatus:"Online",headerStatusUnavailable:"Nicht verf\xFCgbar",disclosureText:"Sie chatten mit einem KI-Assistenten.",welcomeText:"Hallo! Ich beantworte Fragen zu unseren Produkten, Preisen und Best\xE4nden. Wonach suchen Sie?",placeholder:"Stellen Sie eine Frage\u2026",typingLabel:"Der Assistent schreibt\u2026",stillWorkingText:"Wird noch bearbeitet\u2026",timeoutFallbackText:"Das dauert l\xE4nger als erwartet. ",contactLinkText:"Kontaktieren Sie uns",hedgeDisclaimer:"Diese Information ist m\xF6glicherweise nicht mehr aktuell \u2014 bitte auf der Produktseite best\xE4tigen.",quotaNoticeText:"Der Chat macht kurz Pause und ist bald wieder da.",unreachableText:"Verbindung wird wiederhergestellt\u2026",retryButtonText:"Erneut versuchen",youSaidPrefix:"Sie sagten: ",assistantSaidPrefix:"Der Assistent sagte: "},G={openChatAriaLabel:"Apri l'assistente chat",closeChatAriaLabel:"Chiudi la chat",askQuestionAriaLabel:"Fai una domanda",sendMessageAriaLabel:"Invia messaggio",dialogAriaLabel:"Assistente chat del negozio",conversationAriaLabel:"Conversazione",headerTitle:"Assistente del negozio",headerStatus:"Online",headerStatusUnavailable:"Non disponibile",disclosureText:"Stai chattando con un assistente IA.",welcomeText:"Ciao! Posso rispondere a domande su prodotti, prezzi e disponibilit\xE0. Cosa stai cercando?",placeholder:"Fai una domanda\u2026",typingLabel:"L'assistente sta scrivendo\u2026",stillWorkingText:"Ci sto ancora lavorando\u2026",timeoutFallbackText:"Ci sta volendo pi\xF9 tempo del previsto. ",contactLinkText:"Contattaci",hedgeDisclaimer:"Questa informazione potrebbe non essere aggiornata \u2014 verifica nella pagina del prodotto.",quotaNoticeText:"La chat si sta prendendo una breve pausa e torner\xE0 presto.",unreachableText:"Riconnessione in corso\u2026",retryButtonText:"Riprova",youSaidPrefix:"Tu hai detto: ",assistantSaidPrefix:"L'assistente ha detto: "},V={openChatAriaLabel:"Abrir o assistente de chat",closeChatAriaLabel:"Fechar o chat",askQuestionAriaLabel:"Fazer uma pergunta",sendMessageAriaLabel:"Enviar mensagem",dialogAriaLabel:"Assistente de chat da loja",conversationAriaLabel:"Conversa",headerTitle:"Assistente da loja",headerStatus:"Online",headerStatusUnavailable:"Indispon\xEDvel",disclosureText:"Est\xE1 a conversar com um assistente de IA.",welcomeText:"Ol\xE1! Posso responder a perguntas sobre os nossos produtos, pre\xE7os e stock. O que procura?",placeholder:"Fa\xE7a uma pergunta\u2026",typingLabel:"O assistente est\xE1 a escrever\u2026",stillWorkingText:"Ainda a processar\u2026",timeoutFallbackText:"Isto est\xE1 a demorar mais do que o esperado. ",contactLinkText:"Contacte-nos",hedgeDisclaimer:"Esta informa\xE7\xE3o pode n\xE3o estar totalmente atualizada \u2014 confirme na p\xE1gina do produto.",quotaNoticeText:"O chat est\xE1 numa pequena pausa e voltar\xE1 em breve.",unreachableText:"A reconectar\u2026",retryButtonText:"Tentar novamente",youSaidPrefix:"Disse: ",assistantSaidPrefix:"O assistente disse: "},K={en:N,fr:O,es:F,de:U,it:G,pt:V},$="en";function M(i){var t,a,n;let e=(a=(t=i.split(/[-_]/)[0])==null?void 0:t.toLowerCase())!=null?a:$;return(n=K[e])!=null?n:N}var P="system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif",I=`
*{box-sizing:border-box;}

:host{
  all:initial;
  --aica-primary:#3f3ff5;
  --aica-text-on-primary:#ffffff;
  --aica-z-index:999999;
  --bg-2:#eef0fb;--panel:#ffffff;--card:#ffffff;--card-2:#f6f7fc;--elev:#eceefa;
  --line:rgba(20,20,45,0.08);--line-2:rgba(20,20,45,0.14);
  --fg:#15162b;--fg-2:#5b5f76;--fg-3:#9397ab;
  --accent:var(--aica-primary);--accent-fg:var(--aica-text-on-primary);
  --accent-weak:color-mix(in srgb, var(--accent) 10%, transparent);
  --accent-glow:color-mix(in srgb, var(--accent) 24%, transparent);
  --accent-line:color-mix(in srgb, var(--accent) 25%, transparent);
  --shadow:0 1px 2px rgba(20,20,45,.06),0 20px 60px rgba(20,20,45,.14);
  --display:${P};--body:${P};
  position:fixed;right:18px;bottom:18px;z-index:var(--aica-z-index);
  font-family:var(--body);color:var(--fg);
}
/* The merchant's launcher corner (FR-012). \`right\` is the default declared above; the
   left variant has to unset it explicitly, because a custom property cannot switch which
   physical side an element is pinned to. */
:host([data-position="bottom-left"]){right:auto;left:18px;}
:host *{box-sizing:border-box;font-family:inherit;}
:host button{font:inherit;}
/* The \`hidden\` attribute is this widget's entire show/hide mechanism (panel, launcher,
   chips, counter, notice). The UA sheet's \`[hidden]{display:none}\` loses to any author
   \`display:\` \u2014 author origin beats UA origin regardless of specificity \u2014 so every class
   above that declares \`display:flex\` was silently un-hiding its element (the panel
   rendered open on page load). \`!important\` restores the attribute's meaning. */
:host [hidden]{display:none !important;}

.aica-launcher{
  width:56px;height:56px;border-radius:50%;border:none;cursor:pointer;
  background:linear-gradient(145deg,var(--accent),color-mix(in srgb, var(--accent) 80%, black));
  color:var(--accent-fg);display:flex;align-items:center;justify-content:center;
  box-shadow:0 8px 30px var(--accent-glow);
  animation:aica-pulse 2.6s infinite;
}
.aica-launcher:hover{transform:scale(1.05);}
/* The panel's height is a *clamp*, not a fixed number. The host is pinned
   \`position:fixed;bottom:18px\` with the launcher stacked below the panel, so the space
   actually available is the viewport minus the launcher, minus both gaps. A flat height
   overflowed the top of any viewport shorter than roughly the ideal plus 130px \u2014 a laptop
   with a browser toolbar and a theme's sticky header is well inside that \u2014 and the panel's
   header and first messages were cut off above the fold with no way to scroll to them.
   \`min()\` keeps the ideal and yields to the viewport when there is less.

   420\xD7620 rather than requirements.md's WUX-003 380\xD7520 \u2014 a deliberate, merchant-requested
   departure from that number, recorded here because the frozen value is what a reader will
   otherwise assume this should be. At 380\xD7520 the log showed roughly three exchanges before
   scrolling, and product answers are long: this widget's replies routinely list five items
   with prices and stock, so the shopper was reading a catalogue through a letterbox. The
   clamp is what keeps the larger ideal safe \u2014 on a viewport too short for 620px the panel
   still shrinks to fit rather than overflowing, so the extra height costs nothing where
   there is no room for it. The mobile breakpoint below is untouched: WUX-003's "full-width
   minus 32px, max 60vh" still governs there. */
.aica-panel{
  display:flex;flex-direction:column;background:var(--panel);
  border:1px solid var(--line-2);border-radius:18px;box-shadow:var(--shadow);
  overflow:hidden;animation:aica-slide-up .28s cubic-bezier(.2,.7,.2,1);
  width:420px;height:min(620px, calc(100vh - 130px));min-height:320px;
}
@media (max-width:479px){
  /* Below this width the panel spans the viewport, so the corner setting stops
     applying \u2014 both edges are pinned regardless of which side the launcher chose. */
  :host,:host([data-position="bottom-left"]){right:16px;bottom:16px;left:16px;}
  .aica-panel{width:100%;height:min(60vh,520px);}
}

.aica-header{
  display:flex;align-items:center;justify-content:space-between;flex-shrink:0;
  padding:14px 16px;border-bottom:1px solid var(--line);
}
.aica-header-id{display:flex;align-items:center;gap:10px;}
.aica-header-badge{
  width:30px;height:30px;border-radius:9px;flex-shrink:0;
  background:linear-gradient(145deg,var(--accent),color-mix(in srgb, var(--accent) 80%, black));
  color:var(--accent-fg);display:flex;align-items:center;justify-content:center;
}
.aica-header-title{font-family:var(--display);font-size:14.5px;font-weight:600;line-height:1.3;}
.aica-header-status{font-size:11px;color:#2f9e58;display:flex;align-items:center;gap:5px;}
.aica-header-status::before{content:'';width:6px;height:6px;border-radius:50%;background:currentColor;}
/* Quota reached or backend unreachable: the header follows the panel rather than
   claiming "Online" directly above a notice saying the opposite. Setting the dot to
   currentColor above is what makes one class change carry both label and indicator. */
.aica-header-status.is-unavailable{color:var(--fg-3);}
.aica-icon-btn{
  width:44px;height:44px;border-radius:9px;border:none;background:transparent;
  color:var(--fg-2);cursor:pointer;display:flex;align-items:center;justify-content:center;
}
.aica-icon-btn:hover{background:var(--elev);color:var(--fg);}

.aica-disclosure{
  flex-shrink:0;padding:9px 16px;background:var(--accent-weak);border-bottom:1px solid var(--line);
  font-size:11.5px;color:var(--fg-2);display:flex;align-items:center;gap:8px;
}
.aica-disclosure svg{color:var(--accent);flex-shrink:0;}

/* RC-006: the merchant's age/content disclaimer \u2014 a neutral sibling of the AI
   disclosure strip above it, persistent in every mode like the disclosure itself. */
.aica-disclaimer{
  flex-shrink:0;padding:8px 16px;background:var(--card-2);border-bottom:1px solid var(--line);
  font-size:11.5px;line-height:1.45;color:var(--fg-2);
}

/* Padding and gap track the panel's width: at 420px the old 16px/14px left the bubbles
   reading as one dense block, and the whole point of the extra width is that a five-item
   product answer is legible. Gap is the larger jump because the boundary between turns is
   what the eye actually looks for when scanning back through a conversation. */
.aica-log{
  list-style:none;margin:0;flex:1;overflow-y:auto;padding:18px;
  display:flex;flex-direction:column;gap:16px;
}
.aica-row{display:flex;gap:9px;align-items:flex-start;}
.aica-row-shopper{justify-content:flex-end;}
.aica-row-assistant{justify-content:flex-start;}
.aica-avatar{
  width:28px;height:28px;border-radius:8px;flex-shrink:0;background:var(--card-2);
  border:1px solid var(--line);color:var(--accent);display:flex;align-items:center;justify-content:center;
  margin-top:1px;
}
.aica-col{display:flex;flex-direction:column;max-width:78%;}
.aica-col-shopper{align-items:flex-end;}
.aica-col-assistant{align-items:flex-start;}
.aica-bubble{
  padding:10px 13px;font-size:14px;line-height:1.5;color:var(--fg);
  white-space:pre-wrap;overflow-wrap:anywhere;
}
.aica-bubble-shopper{
  border-radius:14px 14px 5px 14px;background:var(--accent-weak);
  border:1px solid var(--accent-line);
}
.aica-bubble-assistant{
  border-radius:5px 14px 14px 14px;background:var(--card-2);border:1px solid var(--line);
}
.aica-trailing{
  display:block;margin-top:8px;padding-top:8px;border-top:1px solid var(--line);
  color:var(--fg-3);font-size:12.5px;line-height:1.45;
}
.aica-sr-only{
  position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;
  clip:rect(0,0,0,0);white-space:nowrap;border:0;
}
.aica-time{font-family:monospace;font-size:10px;color:var(--fg-3);margin-top:4px;padding:0 3px;}

.aica-typing{display:flex;gap:9px;align-items:flex-start;}
.aica-typing-dots{
  padding:12px 15px;background:var(--card-2);border:1px solid var(--line);
  border-radius:5px 14px 14px 14px;display:flex;gap:4px;align-items:center;
}
.aica-typing-dots span{width:6px;height:6px;border-radius:50%;background:var(--fg-3);animation:aica-tdot 1.2s infinite;}
.aica-typing-dots span:nth-child(2){animation-delay:.18s;}
.aica-typing-dots span:nth-child(3){animation-delay:.36s;}

.aica-chips{display:flex;flex-wrap:wrap;gap:8px;margin:2px 0 0 37px;}
.aica-chip{
  font-size:13px;font-weight:600;min-height:44px;padding:0 14px;
  display:inline-flex;align-items:center;border-radius:99px;border:1px solid var(--line-2);
  background:var(--card);color:var(--fg-2);cursor:pointer;
}
.aica-chip:hover{border-color:var(--accent);color:var(--accent);}

.aica-composer{flex-shrink:0;border-top:1px solid var(--line);padding:12px 14px;}
.aica-counter{text-align:right;font-family:monospace;font-size:11px;color:var(--fg-3);margin-bottom:5px;}
.aica-input-row{display:flex;gap:8px;align-items:flex-end;}
.aica-input-wrap{
  flex:1;display:flex;align-items:center;gap:6px;min-height:44px;
  padding:4px 6px 4px 14px;border-radius:12px;border:1px solid var(--line-2);background:var(--card-2);
  transition:border-color .15s ease, box-shadow .15s ease;
}
/* One ring, not three.
   This rule used to pair \`border-color\` with \`outline:2px ... outline-offset:1px\`, which
   already draws two concentric edges with a 1px gap between them. The third came from the
   input *inside* it: \`.aica-input{outline:none}\` is specificity (0,1,0) and the global
   \`:host :focus-visible\` below is (0,2,0), so the reset lost and the field drew its own
   outline at \`outline-offset:2px\` on top of the wrapper's two. Focusing the composer
   produced a stack of three rings at three different radii.
   A soft \`box-shadow\` halo replaces the outline: it follows \`border-radius\` (an outline
   does not, which is the other reason the old ring looked wrong against a 12px corner) and
   reads as one edge with a glow rather than as concentric boxes. */
.aica-input-wrap:focus-within{
  border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-weak);
}
.aica-input{
  flex:1;border:none;background:transparent;color:var(--fg);font-size:14px;padding:6px 0;outline:none;
}
/* Specificity (0,3,0), so it beats the global \`:host :focus-visible\` regardless of source
   order \u2014 the reset above cannot be trusted to hold on its own, which is the bug this
   fixes. The field is not left without a focus indicator: \`:focus-within\` on the wrapper
   draws it one element out, which is what AX-005/WCAG 2.4.7 asks for and is more legible
   than a ring hugging the caret. */
:host .aica-input:focus-visible{outline:none;}
.aica-input::placeholder{color:var(--fg-3);}
.aica-send{
  width:44px;height:44px;flex-shrink:0;border-radius:11px;border:none;
  display:flex;align-items:center;justify-content:center;cursor:pointer;
  background:linear-gradient(145deg,var(--accent),color-mix(in srgb, var(--accent) 80%, black));
  color:var(--accent-fg);box-shadow:0 4px 16px var(--accent-glow);
}
.aica-send:disabled{background:var(--elev);color:var(--fg-3);box-shadow:none;cursor:not-allowed;}

.aica-notice{flex-shrink:0;border-top:1px solid var(--line);padding:18px;text-align:center;background:var(--card-2);}
.aica-notice-text{font-size:13px;color:var(--fg-2);line-height:1.5;}
.aica-fallback-link{color:var(--accent);font-weight:600;}

.aica-unreachable-bar{
  display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px;
  padding:8px 12px;background:var(--card-2);border-radius:10px;
}
.aica-retry{
  font-size:12.5px;font-weight:600;color:var(--accent);background:none;border:none;cursor:pointer;
  padding:8px;min-height:44px;
}
.aica-retry:hover{text-decoration:underline;}

:host :focus-visible{outline:2px solid var(--accent);outline-offset:2px;}

@keyframes aica-slide-up{from{opacity:0;transform:translateY(16px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes aica-tdot{0%,60%,100%{opacity:.25;transform:translateY(0)}30%{opacity:1;transform:translateY(-3px)}}
@keyframes aica-pulse{0%{box-shadow:0 0 0 0 var(--accent-glow)}70%{box-shadow:0 0 0 7px transparent}100%{box-shadow:0 0 0 0 transparent}}

@media (prefers-reduced-motion: reduce){
  :host *,:host{animation:none !important;transition:none !important;}
}
`;var u=500,Q=u-20,Y=300,X=8e3,J=15e3,Z=1800*1e3,g=class{constructor(e){this.open=!1;this.lastMessageText="";this.revealTimer=null;this.revealScrollListener=null;this.sessionToken=null;this.sessionId=null;this.typingTimer=null;this.stillWorkingTimer=null;this.fallbackTimer=null;this.idleTimer=null;this.config=e;let t=M(e.locale);this.copy={...t,headerTitle:e.title!==""?e.title:t.headerTitle,placeholder:e.placeholder!==""?e.placeholder:t.placeholder},this.host=document.createElement("div"),this.host.setAttribute("data-wcai-widget",""),this.applyAppearance(e),document.body.appendChild(this.host),this.shadow=this.host.attachShadow({mode:"closed"});let a=document.createElement("style");a.textContent=I,this.shadow.appendChild(a),this.launcher=o("button",{className:"aica-launcher",type:"button","aria-label":this.copy.openChatAriaLabel,onclick:()=>this.openPanel()},[h(25)]),this.log=o("ul",{className:"aica-log",role:"log","aria-live":"polite","aria-label":this.copy.conversationAriaLabel}),this.chipsContainer=o("div",{className:"aica-chips",hidden:!0}),this.counter=o("div",{className:"aica-counter",hidden:!0}),this.input=o("input",{className:"aica-input",type:"text",maxlength:u,autocomplete:"off",placeholder:this.copy.placeholder,"aria-label":this.copy.askQuestionAriaLabel,oninput:()=>this.onInput()}),this.sendButton=o("button",{className:"aica-send",type:"submit",disabled:!0,"aria-label":this.copy.sendMessageAriaLabel},[k()]),this.composer=o("form",{className:"aica-composer",onsubmit:r=>{r.preventDefault(),this.send()}},[this.counter,o("div",{className:"aica-input-row"},[o("div",{className:"aica-input-wrap"},[this.input]),this.sendButton])]),this.notice=o("div",{className:"aica-notice",hidden:!0}),this.headerStatus=o("div",{className:"aica-header-status"},[this.copy.headerStatus]);let n=o("button",{className:"aica-icon-btn",type:"button","aria-label":this.copy.closeChatAriaLabel,onclick:()=>this.closePanel()},[T()]);this.panel=o("div",{className:"aica-panel",role:"dialog","aria-modal":"true","aria-label":this.copy.dialogAriaLabel,hidden:!0},[o("div",{className:"aica-header"},[o("div",{className:"aica-header-id"},[o("span",{className:"aica-header-badge"},[h(15)]),o("div",{},[o("div",{className:"aica-header-title"},[this.copy.headerTitle]),this.headerStatus])]),n]),o("div",{className:"aica-disclosure"},[C(),this.copy.disclosureText]),e.disclaimer!==""&&o("div",{className:"aica-disclaimer"},[e.disclaimer]),this.log,this.chipsContainer,this.composer,this.notice]),this.shadow.append(this.launcher,this.panel),this.focusTrap=new p(this.panel),this.shadow.addEventListener("keydown",r=>{r instanceof KeyboardEvent&&r.key==="Escape"&&this.open&&this.closePanel()}),this.applyAutoDarken(),this.setupLauncherReveal(e),this.resetIdleTimer()}setupLauncherReveal(e){if(!(e.triggerDelay<=0&&e.triggerScroll<=0)&&(this.launcher.hidden=!0,e.triggerDelay>0&&(this.revealTimer=setTimeout(()=>this.revealLauncher(),e.triggerDelay*1e3)),e.triggerScroll>0)){let t=()=>{this.scrolledPercent()>=e.triggerScroll&&this.revealLauncher()};this.revealScrollListener=t,window.addEventListener("scroll",t,{passive:!0}),t()}}scrolledPercent(){let e=document.documentElement,t=e.scrollHeight-e.clientHeight;return t<=0?100:(window.scrollY||e.scrollTop||0)/t*100}revealLauncher(){this.revealTimer!==null&&(clearTimeout(this.revealTimer),this.revealTimer=null),this.revealScrollListener!==null&&(window.removeEventListener("scroll",this.revealScrollListener),this.revealScrollListener=null),this.launcher.hidden=!1}applyAppearance(e){e.accentColor!==""&&this.host.style.setProperty("--aica-primary",e.accentColor),this.host.setAttribute("data-position",e.position)}applyAutoDarken(){let e=getComputedStyle(this.host),t=e.getPropertyValue("--aica-primary").trim(),a=e.getPropertyValue("--aica-text-on-primary").trim();if(!t||!a){console.warn("[wcai] widget accent tokens unresolved \u2014 AX-002 contrast check skipped.");return}let n=L(t,a);n&&this.host.style.setProperty("--aica-primary",n)}openPanel(){this.open=!0,this.launcher.hidden=!0,this.panel.hidden=!1,this.log.childNodes.length===0&&this.appendMessage({role:"assistant",text:this.copy.welcomeText}),this.focusTrap.activate(),this.resetIdleTimer()}closePanel(){this.open=!1,this.panel.hidden=!0,this.launcher.hidden=!1,this.focusTrap.deactivate()}resetIdleTimer(){this.idleTimer!==null&&clearTimeout(this.idleTimer),this.idleTimer=setTimeout(()=>this.clearContext(),Z)}clearContext(){this.sessionId=null,this.lastMessageText="",l(this.log,[]),l(this.chipsContainer,[]),this.chipsContainer.hidden=!0,this.setMode("input")}onInput(){this.resetIdleTimer();let e=this.input.value.length;this.sendButton.disabled=this.input.value.trim()==="",this.counter.hidden=e<Q,this.counter.hidden===!1&&l(this.counter,[`${e}/${u}`]),this.chipsContainer.childNodes.length>0&&(l(this.chipsContainer,[]),this.chipsContainer.hidden=!0)}setMode(e){this.composer.hidden=e!=="input",this.notice.hidden=e==="input";let t=e!=="input";this.headerStatus.textContent=t?this.copy.headerStatusUnavailable:this.copy.headerStatus,this.headerStatus.classList.toggle("is-unavailable",t),e==="quota"?l(this.notice,[o("span",{className:"aica-notice-text"},[this.copy.quotaNoticeText])]):e==="unreachable"&&this.renderUnreachableNotice()}renderUnreachableNotice(){l(this.notice,[o("div",{className:"aica-unreachable-bar"},[o("span",{className:"aica-notice-text"},[this.copy.unreachableText]),o("button",{className:"aica-retry",type:"button",onclick:()=>this.retry()},[this.copy.retryButtonText])])])}retry(){this.setMode("input"),this.lastMessageText&&this.dispatch(this.lastMessageText,!1)}appendMessage(e){let t=e.role==="shopper",a=y(e.text);e.link&&(a.push(" "),a.push(o("a",{className:"aica-fallback-link",href:e.link.href,target:"_blank",rel:"noopener noreferrer"},[e.link.text]))),e.trailing&&a.push(o("span",{className:"aica-trailing"},[e.trailing]));let n=o("li",{className:`aica-row aica-row-${t?"shopper":"assistant"}`},[!t&&o("span",{className:"aica-avatar"},[h(14)]),o("div",{className:`aica-col aica-col-${t?"shopper":"assistant"}`},[o("span",{className:"aica-sr-only"},[t?this.copy.youSaidPrefix:this.copy.assistantSaidPrefix]),o("div",{className:`aica-bubble aica-bubble-${t?"shopper":"assistant"}`},a)])]);this.log.appendChild(n),this.log.scrollTop=this.log.scrollHeight}showTyping(e){let t=this.shadow.querySelector(".aica-typing");e&&!t?(t=o("li",{className:"aica-typing"},[o("span",{className:"aica-avatar"},[h(14)]),o("div",{className:"aica-typing-dots",role:"status"},[o("span",{className:"aica-sr-only aica-typing-label"},[this.copy.typingLabel]),o("span",{"aria-hidden":"true"}),o("span",{"aria-hidden":"true"}),o("span",{"aria-hidden":"true"})])]),this.log.appendChild(t),this.log.scrollTop=this.log.scrollHeight):!e&&t&&t.remove()}showChips(e){e.length!==0&&(this.chipsContainer.hidden=!0,l(this.chipsContainer,[]),setTimeout(()=>{l(this.chipsContainer,e.slice(0,3).map(t=>o("button",{className:"aica-chip",type:"button",onclick:()=>{this.input.value=t,this.onInput(),this.input.focus()}},[t]))),this.chipsContainer.hidden=!1},200))}clearTimers(){this.typingTimer!==null&&(clearTimeout(this.typingTimer),this.typingTimer=null),this.stillWorkingTimer!==null&&(clearTimeout(this.stillWorkingTimer),this.stillWorkingTimer=null),this.fallbackTimer!==null&&(clearTimeout(this.fallbackTimer),this.fallbackTimer=null)}send(){let e=this.input.value.trim();e!==""&&(this.input.value="",this.onInput(),this.dispatch(e))}dispatch(e,t=!0){this.resetIdleTimer(),this.lastMessageText=e,t&&this.appendMessage({role:"shopper",text:e}),this.sendButton.disabled=!0,this.input.disabled=!0,this.clearTimers(),this.typingTimer=setTimeout(()=>this.showTyping(!0),Y),this.stillWorkingTimer=setTimeout(()=>{let n=this.shadow.querySelector(".aica-typing-label");n&&(n.classList.remove("aica-sr-only"),l(n,[this.copy.stillWorkingText]))},X);let a=new AbortController;this.fallbackTimer=setTimeout(()=>a.abort(),J),this.runChat(e,a)}async runChat(e,t){try{let a={message:e.slice(0,u),session_id:this.sessionId,page_context:window.location.pathname,child_audience:this.config.childAudience};this.sessionToken||(this.sessionToken=await this.mintToken(t));let n=await x(this.config.apiBase,{sessionToken:this.sessionToken,widgetToken:this.config.widgetToken},a,t.signal);n.kind==="error"&&n.status===401&&this.sessionToken&&(this.sessionToken=await this.mintToken(t),n=await x(this.config.apiBase,{sessionToken:this.sessionToken,widgetToken:this.config.widgetToken},a,t.signal)),this.onChatSettled(n)}catch(a){if(a instanceof DOMException&&a.name==="AbortError"){this.onTimeout();return}this.onChatSettled({kind:"error",status:0,error:null})}}mintToken(e){return E(this.config.apiBase,this.config.widgetToken,window.location.origin,e.signal)}onChatSettled(e){if(this.clearTimers(),this.showTyping(!1),this.input.disabled=!1,this.sendButton.disabled=this.input.value.trim()==="",e.kind==="ok"){this.sessionId=e.data.session_id;let t={role:"assistant",text:e.data.reply};e.data.routing==="hedged"?t.trailing=this.copy.hedgeDisclaimer:e.data.routing==="deflected"&&(t.link={text:this.copy.contactLinkText,href:this.config.contactUrl}),this.appendMessage(t),this.showChips(e.data.suggestions);return}if(e.status===402){this.setMode("quota");return}this.setMode("unreachable")}onTimeout(){this.clearTimers(),this.showTyping(!1),this.input.disabled=!1,this.sendButton.disabled=this.input.value.trim()==="",this.appendMessage({role:"assistant",text:this.copy.timeoutFallbackText,link:{text:this.copy.contactLinkText,href:this.config.contactUrl}})}};function ee(i=window){let e=i.wcaiWidgetConfig;return!e||!e.apiBase||!e.widgetToken?null:{apiBase:e.apiBase.replace(/\/+$/,""),widgetToken:e.widgetToken,locale:e.locale||document.documentElement.lang||"en",contactUrl:e.contactUrl||i.location.origin,position:e.position==="bottom-left"?"bottom-left":"bottom-right",accentColor:typeof e.accentColor=="string"?e.accentColor:"",title:typeof e.title=="string"?e.title:"",placeholder:typeof e.placeholder=="string"?e.placeholder:"",triggerDelay:R(e.triggerDelay),triggerScroll:Math.min(R(e.triggerScroll),100),disclaimer:typeof e.disclaimer=="string"?e.disclaimer.trim():"",childAudience:te(e.childAudience)}}function R(i){let e=typeof i=="number"?i:typeof i=="string"?Number(i):NaN;return Number.isFinite(e)&&e>0?e:0}function te(i){return i===!0||i==="1"||i==="true"}function ie(){let i=ee();i!==null&&new g(i)}ie();})();
