/**
 * The Merchant Admin Panel's client (`add-merchant-insight-ops §1.3`, §2.1–2.4).
 *
 * The panel's pages render server-side as empty shells and this fills them from
 * `admin-ajax.php` after paint (NFR-005, design D-1). Everything it inserts was shaped and
 * escaped in PHP — see `OverviewPage::payload()` and friends — so the rule here is
 * `textContent`, never `innerHTML`, for anything that came back from the backend. The one
 * exception is the deflection chart, whose SVG this script builds nothing of: it is emitted
 * by `AnalyticsPage::chart_svg()` from numbers, with no backend string in it.
 *
 * No framework and no build step. It is roughly two hundred lines of DOM writes against a
 * shell that already exists, and shipping a bundle to do that would spend the page's
 * latency budget on the thing meant to protect it.
 */
( function () {
	'use strict';

	var cfg = window.wcaiPanel || {};

	/** `[data-wcai-field="name"]` within a root. */
	function field( root, name ) {
		return root.querySelector( '[data-wcai-field="' + name + '"]' );
	}

	/**
	 * Set a field's text, if the field is on this page.
	 *
	 * Marks the node `data-filled` once a real value lands. The server renders an em-dash
	 * placeholder into the metric cards, and the em-dash is *also* the correct final state
	 * for a live-but-quiet store — so the two cannot be told apart by their text. The
	 * attribute is what lets the stylesheet dim the not-yet-known one without dimming the
	 * genuinely-empty one.
	 */
	function setText( root, name, value ) {
		var node = field( root, name );
		if ( node ) {
			node.textContent = value;
			node.setAttribute( 'data-filled', '' );
		}
	}

	function show( node ) {
		if ( node ) {
			node.hidden = false;
		}
	}

	function hide( node ) {
		if ( node ) {
			node.hidden = true;
		}
	}

	/** Drop the loading line once a page has its answer — success or failure. */
	function clearLoading( root ) {
		var loader = root.querySelector( '[data-wcai-loading]' );
		if ( loader && loader.parentNode ) {
			loader.parentNode.removeChild( loader );
		}
	}

	/**
	 * Render a failure above the page body.
	 *
	 * The message and its follow-up link both come from PHP (`Panel::transport_error()`),
	 * because which of them applies is a backend-status question and SR-005 requires the
	 * answer to carry a fix rather than an apology.
	 */
	function renderError( root, payload ) {
		var notice = document.createElement( 'div' );
		notice.className = 'notice notice-error inline';

		var para = document.createElement( 'p' );
		para.textContent = ( payload && payload.message ) || cfg.i18n.loadFailed;
		notice.appendChild( para );

		if ( payload && payload.action && payload.actionLabel ) {
			var linkPara = document.createElement( 'p' );
			var link = document.createElement( 'a' );
			link.className = 'button';
			link.href = payload.action;
			link.textContent = payload.actionLabel;
			linkPara.appendChild( link );
			notice.appendChild( linkPara );
		}

		root.insertBefore( notice, root.firstChild );
	}

	/**
	 * POST to an `admin-ajax` action with the panel nonce.
	 *
	 * `credentials: 'same-origin'` is required: `admin-ajax.php` authenticates by cookie,
	 * and fetch does not send cookies cross-origin by default.
	 *
	 * `fields` carries the Knowledge Base's action arguments (§5.3–5.5). Every value is
	 * re-validated and sanitized in PHP behind the capability + nonce guard — nothing here
	 * is a check, it is just what the form had.
	 */
	function post( action, fields ) {
		var body = new URLSearchParams();
		body.set( 'action', action );
		body.set( 'nonce', cfg.nonce );

		if ( fields ) {
			Object.keys( fields ).forEach( function ( key ) {
				body.set( key, fields[ key ] );
			} );
		}

		return fetch( cfg.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: body.toString()
		} ).then( function ( response ) {
			return response.json();
		} );
	}

	// -- status pill -----------------------------------------------------------

	/**
	 * Correct the header pill from the backend's own `state` (FR-017).
	 *
	 * Both the class and the label come from the response; the plugin never re-derives a
	 * state from parts, so the pill cannot contradict the backend that owns the rule.
	 */
	function updatePill( state, label ) {
		var pill = document.querySelector( '[data-wcai-pill]' );
		if ( ! pill || ! state ) {
			return;
		}

		var safeState = state.replace( /[^a-z_]/g, '' );

		pill.className = 'wcai-pill wcai-pill-' + safeState;
		pill.setAttribute( 'data-state', state );

		// Rebuild rather than assigning `textContent`: the pill carries a visually-hidden
		// "Status:" prefix so a screen reader announces the state as a labelled value
		// instead of a bare word, and a plain text assignment would silently delete it on
		// the first refresh — leaving the sighted rendering correct and the accessible
		// one degraded, which is the kind of regression nobody sees.
		var prefix = pill.querySelector( '.wcai-visually-hidden' );

		pill.textContent = '';

		if ( prefix ) {
			pill.appendChild( prefix );
		}

		pill.appendChild( document.createTextNode( label || state ) );
	}

	// -- overview --------------------------------------------------------------

	function fillUsageBar( root, key, usage ) {
		var meter = field( root, key + 'Meter' );
		if ( meter ) {
			if ( usage.unlimited ) {
				// An unlimited plan has no proportion to draw. Removing the meter is
				// honest; leaving it at 0% would read as "nothing used of nothing".
				meter.remove();
			} else {
				meter.value = usage.percent;
			}
		}
		setText( root, key + 'Text', usage.text );
	}

	function renderOverview( root, data ) {
		if ( data.isIndexing ) {
			// ES-001 — the progress card stands alone; no metric cards, no usage bars.
			//
			// The cards and usage section have to be hidden explicitly. They render visible
			// from the start (see the note below on why), and `.is-loading` is a shimmer
			// that only ever stops when values arrive — which, on this path, they never do.
			// Returning without hiding them left four skeleton cards pulsing under the
			// "Setting up your assistant" panel for the entire duration of the first index
			// pass, reading as data about to land at any moment rather than a store that
			// has none yet.
			show( root.querySelector( '[data-wcai-empty="indexing"]' ) );
			hide( root.querySelector( '[data-wcai-cards]' ) );
			hide( root.querySelector( '[data-wcai-usage]' ) );
			return;
		}

		var cards = root.querySelector( '[data-wcai-cards]' );
		show( cards );
		// Drop the skeleton shimmer now the values are real. The cards render visible from
		// the start so the page has its layout immediately; `.is-loading` is what makes
		// them read as "not yet known" until this point.
		if ( cards ) {
			cards.classList.remove( 'is-loading' );
		}
		show( root.querySelector( '[data-wcai-usage]' ) );

		setText( root, 'qualityScore', String( data.qualityScore ) );
		fillUsageBar( root, 'replies', data.usage.replies );
		fillUsageBar( root, 'memoryItems', data.usage.memoryItems );
		setText( root, 'period', data.period );

		if ( data.staleness && data.staleness.isStale ) {
			var warning = document.createElement( 'div' );
			warning.className = 'notice notice-warning inline';
			var text = document.createElement( 'p' );
			text.textContent = data.staleness.text;
			warning.appendChild( text );
			root.insertBefore( warning, root.firstChild );
		}
	}

	/**
	 * The Overview's conversation and answer-rate cards come from the analytics endpoint,
	 * so they are filled by a second request. ES-002 applies to those two cards only —
	 * the quality score and usage bars are meaningful on a store nobody has chatted with.
	 */
	function fillOverviewFromAnalytics( root, analytics ) {
		if ( analytics.isEmpty ) {
			show( root.querySelector( '[data-wcai-empty="conversations"]' ) );
			return;
		}
		setText( root, 'conversations', analytics.conversationsWindow );
		setText( root, 'answerRate', analytics.answerRate );

		// Only when there is one. The card ships holding an em-dash, which is the correct
		// display for a store with nothing unanswered — writing '' over it would replace a
		// deliberate "nothing to report" with a blank box. Left unset entirely until now,
		// so the card read as an em-dash on every store forever, including ones with a
		// full unanswered log one click away.
		if ( analytics.topUnanswered ) {
			setText( root, 'topUnanswered', analytics.topUnanswered );
		}
	}

	// -- analytics -------------------------------------------------------------

	/** A `<tr>` of plain text cells. */
	function row( values ) {
		var tr = document.createElement( 'tr' );
		values.forEach( function ( value ) {
			var td = document.createElement( 'td' );
			td.textContent = value;
			tr.appendChild( td );
		} );
		return tr;
	}

	function fillRows( root, name, rows ) {
		var body = field( root, name );
		if ( ! body ) {
			return;
		}
		body.textContent = '';
		rows.forEach( function ( tr ) {
			body.appendChild( tr );
		} );
	}

	function renderAnalytics( root, data ) {
		if ( data.isEmpty ) {
			show( root.querySelector( '[data-wcai-empty="conversations"]' ) );
			return;
		}

		show( root.querySelector( '[data-wcai-analytics-body]' ) );

		setText( root, 'conversationsTotal', data.conversationsTotal );
		setText( root, 'conversationsWindow', data.conversationsWindow );
		setText( root, 'answerRate', data.answerRate );
		setText( root, 'deflectionRate', data.deflectionRate );

		// The only `innerHTML` in this file. The string is built by `chart_svg()` from
		// clamped numbers and translated labels — no backend text reaches it.
		var chart = field( root, 'deflectionChart' );
		if ( chart ) {
			chart.innerHTML = data.deflectionChart;
		}

		fillRows(
			root,
			'deflectionRows',
			data.deflectionRows.map( function ( point ) {
				return row( [ point.label, point.percent ] );
			} )
		);

		fillRows(
			root,
			'localeRows',
			data.localeRows.map( function ( locale ) {
				var tr = row( [ locale.language, locale.conversations, locale.percent ] );
				if ( locale.alert ) {
					// FR-091 — the row is marked and carries its own explanation, so the
					// alert is readable without colour alone (AX).
					tr.className = 'wcai-alert';
					var note = document.createElement( 'span' );
					note.className = 'wcai-alert-note';
					note.textContent = ' ' + locale.alertText;
					tr.lastChild.appendChild( note );
				}
				return tr;
			} )
		);

		fillRows(
			root,
			'topQuestionRows',
			data.topQuestionRows.map( function ( question ) {
				return row( [ question.question, question.count ] );
			} )
		);
	}

	// -- unanswered ------------------------------------------------------------

	function renderUnanswered( root, data ) {
		if ( data.isEmpty ) {
			show( root.querySelector( '[data-wcai-empty="unanswered"]' ) );
			return;
		}

		show( root.querySelector( '[data-wcai-unanswered-body]' ) );

		fillRows(
			root,
			'unansweredRows',
			data.rows.map( function ( item ) {
				var tr = row( [ item.question, item.count, item.locale, item.lastAsked ] );

				var actions = document.createElement( 'td' );
				var link = document.createElement( 'a' );
				link.className = 'button button-secondary';
				link.href = item.addAnswerUrl;
				link.textContent = cfg.i18n.addAnswer;
				actions.appendChild( link );
				tr.appendChild( actions );

				return tr;
			} )
		);
	}

	// -- knowledge base (add-content-ingestion-kb §5) --------------------------

	/** The offset the inventory is currently showing; the pager's only state. */
	var kbOffset = 0;

	/**
	 * A transient message above the table — the result of a toggle, a save, or a re-sync.
	 *
	 * `textContent`, like everywhere else: these strings are composed in PHP, but two of them
	 * (the transport errors) originate in a backend response, so the rule does not get an
	 * exception for being convenient here.
	 */
	function kbNotice( root, message, isError ) {
		var box = root.querySelector( '[data-wcai-kb-notice]' );
		if ( ! box ) {
			return;
		}
		box.className = 'wcai-kb-notice notice inline ' + ( isError ? 'notice-error' : 'notice-success' );
		box.textContent = message;
		box.hidden = false;
	}

	/**
	 * Open one of the page's two panels (manual entry, re-sync confirm) and close the
	 * other.
	 *
	 * `hidden` alone does not move the page: a panel that renders far from the button
	 * that opens it (the re-sync confirm sits ahead of the still-hidden knowledge body on
	 * an empty store) un-hid with no visual link back to that button. `scrollIntoView`
	 * closes that gap without depending on DOM order to keep the two next to each other.
	 */
	function kbPanel( root, name ) {
		var panels = root.querySelectorAll( '[data-wcai-panel]' );
		var opened = null;
		Array.prototype.forEach.call( panels, function ( panel ) {
			var isMatch = panel.getAttribute( 'data-wcai-panel' ) === name;
			panel.hidden = ! isMatch;
			if ( isMatch ) {
				opened = panel;
			}
		} );
		if ( opened ) {
			// The wizard's CSS honors `prefers-reduced-motion` for its own animations;
			// scrolling is the same vestibular trigger and gets the same respect.
			var reduceMotion = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
			opened.scrollIntoView( { behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' } );
		}
	}

	/**
	 * The per-item include switch (§5.3).
	 *
	 * `role="switch"` with `aria-checked` rather than a bare button: excluding an item
	 * deletes its chunks, and a control with that consequence has to announce its state to a
	 * screen reader rather than communicate it by position alone (AX).
	 *
	 * The switch is set to the server's answer, not to the optimistic flip — a delete that
	 * failed to enqueue must leave the switch showing the item as still included, because it
	 * still is.
	 */
	function kbSwitch( root, item ) {
		var button = document.createElement( 'button' );
		button.type = 'button';
		button.className = 'wcai-switch';
		button.setAttribute( 'role', 'switch' );
		button.setAttribute( 'aria-checked', item.included ? 'true' : 'false' );
		button.setAttribute( 'aria-label', cfg.i18n.includeLabel );
		button.textContent = item.included ? cfg.i18n.included : cfg.i18n.excluded;

		button.addEventListener( 'click', function () {
			var next = button.getAttribute( 'aria-checked' ) !== 'true';
			button.disabled = true;

			post( 'wcai_kb_toggle_item', {
				object_type: item.objectType,
				object_id: item.objectId,
				source_id: item.sourceId,
				included: next ? '1' : '0'
			} ).then( function ( response ) {
				button.disabled = false;
				if ( ! response.success ) {
					kbNotice( root, ( response.data && response.data.message ) || cfg.i18n.actionFailed, true );
					return;
				}
				button.setAttribute( 'aria-checked', response.data.included ? 'true' : 'false' );
				button.textContent = response.data.included ? cfg.i18n.included : cfg.i18n.excluded;
				kbNotice( root, response.data.message, false );
			} ).catch( function () {
				button.disabled = false;
				kbNotice( root, cfg.i18n.actionFailed, true );
			} );
		} );

		return button;
	}

	function renderQuality( root, quality ) {
		setText( root, 'qualityScore', String( quality.score ) );
		setText( root, 'qualityVerdict', quality.verdict );

		fillRows(
			root,
			'qualityFactors',
			quality.factors.map( function ( factor ) {
				return row( [ factor.label, String( factor.score ) ] );
			} )
		);

		var list = field( root, 'qualityImprovements' );
		if ( list ) {
			list.textContent = '';
			quality.improvements.forEach( function ( line ) {
				var li = document.createElement( 'li' );
				li.textContent = line;
				list.appendChild( li );
			} );
		}

		// Only shown when there is something on it — see the page's note on why an empty
		// "how to improve" heading is worse than none.
		var box = root.querySelector( '[data-wcai-improvements]' );
		if ( box ) {
			box.hidden = quality.improvements.length === 0;
		}

		// The go-live override (D9/FR-014). `canOverride` comes from the backend's `passed`
		// and is never re-derived here from score vs threshold: the gate that actually
		// withholds the widget reads `passed`, and a card that computed its own comparison
		// could offer "Publish anyway" to a store that is already published — or hide it
		// from one that is not.
		var override = root.querySelector( '[data-wcai-override]' );
		if ( override ) {
			override.hidden = ! quality.canOverride;
		}
	}

	function renderKnowledge( root, data ) {
		// The quality card renders either way: a store with nothing indexed still has a
		// score and a checklist, and that checklist is the whole point of ES-003.
		renderQuality( root, data.quality );

		if ( data.isEmpty ) {
			show( root.querySelector( '[data-wcai-empty="knowledge"]' ) );
			return;
		}

		show( root.querySelector( '[data-wcai-knowledge-body]' ) );
		setText( root, 'knowledgeCount', data.count );

		fillRows(
			root,
			'knowledgeRows',
			data.rows.map( function ( item ) {
				var tr = row( [ item.title, item.typeLabel, item.lastSynced, item.statusText ] );
				var cell = document.createElement( 'td' );
				cell.appendChild( kbSwitch( root, item ) );
				tr.appendChild( cell );
				return tr;
			} )
		);

		var pager = root.querySelector( '[data-wcai-pager]' );
		if ( pager ) {
			pager.hidden = ! data.hasPrev && ! data.hasNext;
			var prev = pager.querySelector( '[data-wcai-action="page-prev"]' );
			var next = pager.querySelector( '[data-wcai-action="page-next"]' );
			if ( prev ) {
				prev.disabled = ! data.hasPrev;
			}
			if ( next ) {
				next.disabled = ! data.hasNext;
			}
		}
	}

	function loadKnowledge( root ) {
		post( 'wcai_panel_knowledge', { offset: kbOffset } )
			.then( function ( response ) {
				clearLoading( root );
				if ( ! response.success ) {
					renderError( root, response.data );
					return;
				}
				renderKnowledge( root, response.data.knowledge );
			} )
			.catch( function () {
				clearLoading( root );
				renderError( root, null );
			} );
	}

	/** Re-read the current page after an action changed what is in it. */
	function reloadKnowledge( root ) {
		var body = root.querySelector( '[data-wcai-knowledge-body]' );
		if ( body ) {
			body.hidden = true;
		}
		hide( root.querySelector( '[data-wcai-empty="knowledge"]' ) );
		loadKnowledge( root );
	}

	/** The pending poll timer for a re-sync in progress, so a second click cancels the first. */
	var kbResyncPoll = null;

	/** Whether the last poll saw a walk running, so the finish is only handled once. */
	var kbWasIndexing = false;

	/**
	 * Paint the progress panel from a `resync_progress()` block.
	 *
	 * Everything here was shaped and translated in PHP — the counts, the phase name, the
	 * estimate — so this sets `textContent` and a number, and makes no sentences of its own.
	 */
	function renderProgress( root, progress ) {
		var panel = root.querySelector( '[data-wcai-kb-progress]' );
		if ( ! panel ) {
			return;
		}

		// `idle` — no walk, or one aged out as stale — is the only state with nothing to
		// show. A `done` walk is deliberately *not* hidden here: it carries "Re-index
		// complete" and a full bar, and blanking it the instant the work finished would
		// delete the one moment the merchant is waiting for. `pollResyncProgress()` hides
		// the panel explicitly once it has handled that finish.
		if ( ! progress || 'idle' === progress.state ) {
			panel.hidden = true;
			return;
		}

		// The panel supersedes any toast in the notice box — most importantly the green
		// "scheduled" confirmation, which otherwise sat above a red failure panel as a
		// success message about the same walk.
		hide( root.querySelector( '[data-wcai-kb-notice]' ) );

		panel.hidden = false;
		panel.setAttribute( 'data-state', progress.state );
		setText( root, 'progressText', progress.text );
		setText( root, 'progressDetail', progress.detail );

		var bar = field( root, 'progressBar' );
		if ( bar ) {
			bar.value = progress.percent;
			// The bar's own value is not announced as it moves (see the page's note on why
			// `aria-live` sits on the text instead), so the accessible name carries the same
			// sentence the sighted reader gets from the line above it.
			bar.setAttribute( 'aria-label', progress.text );
		}
	}

	/**
	 * Watch a re-index while it runs, and refresh the inventory when it lands.
	 *
	 * Polls `wcai_kb_progress` — the plugin's own record of the Action Scheduler walk (see
	 * `IndexingProgress`), which is the only component that knows the cursor. The backend's
	 * `IndexingProgress` block is still `idle/0/0`, so this deliberately does not ask it.
	 *
	 * Two things end the poll: the walk reporting `done`, or the record going quiet — which
	 * `IndexingProgress::read()` reports as `idle` once it is stale, so a job that dies takes
	 * the bar down with it instead of leaving it spinning forever.
	 *
	 * The interval is short enough to feel live and long enough that a slow store is not
	 * answering an admin-ajax request every second while it is also pushing its catalogue.
	 */
	function pollResyncProgress( root ) {
		if ( kbResyncPoll ) {
			clearTimeout( kbResyncPoll );
			kbResyncPoll = null;
		}

		var intervalMs = 4000;

		var stop = function () {
			if ( kbResyncPoll ) {
				clearTimeout( kbResyncPoll );
				kbResyncPoll = null;
			}
			renderProgress( root, null );
		};

		var tick = function () {
			post( 'wcai_kb_progress' ).then( function ( response ) {
				if ( ! response.success ) {
					stop();
					return;
				}

				var progress = response.data.progress;
				renderProgress( root, progress );

				if ( progress.isActive ) {
					kbWasIndexing = true;
					kbResyncPoll = setTimeout( tick, intervalMs );
					return;
				}

				// Finished (or went stale). Either way the inventory the merchant is looking
				// at predates the walk, so it is re-read once here rather than on every poll
				// — the table does not need to redraw fifty times while the bar fills.
				kbResyncPoll = null;
				if ( kbWasIndexing ) {
					kbWasIndexing = false;
					// No completion toast: the panel itself reads "Re-index complete." for
					// its parting beat, and a toast repeating it above was the same
					// two-voices problem as the "scheduled" one.
					kbOffset = 0;
					reloadKnowledge( root );
				}

				// A finished walk keeps its full bar and "Re-index complete" on screen for a
				// beat before the panel closes. Hiding it in the same tick as the render
				// above — which is what this used to do — meant the completed state existed
				// for a few milliseconds and the merchant only ever saw the bar vanish.
				// A stale/idle record has nothing to linger over and goes immediately.
				if ( 'done' === progress.state ) {
					setTimeout( function () {
						renderProgress( root, null );
					}, 4000 );
					return;
				}

				// `failed` — including a walk the backend finished-but-refused (zero-quota
				// plan) — stays on screen. It is the explanation for the empty inventory
				// below it, and a warning that dismisses itself is a warning that was not
				// delivered.
				if ( 'failed' === progress.state ) {
					return;
				}

				renderProgress( root, null );
			} ).catch( stop );
		};

		tick();
	}

	function saveManualEntry( root, button ) {
		var title = root.querySelector( '[data-wcai-input="manualTitle"]' );
		var body = root.querySelector( '[data-wcai-input="manualBody"]' );
		var label = button.textContent;

		button.disabled = true;
		button.textContent = cfg.i18n.saving;

		post( 'wcai_kb_manual_entry', {
			title: title ? title.value : '',
			content: body ? body.value : ''
		} ).then( function ( response ) {
			button.disabled = false;
			button.textContent = label;
			if ( ! response.success ) {
				kbNotice( root, ( response.data && response.data.message ) || cfg.i18n.actionFailed, true );
				return;
			}
			if ( title ) {
				title.value = '';
			}
			if ( body ) {
				body.value = '';
			}
			kbPanel( root, null );
			kbNotice( root, response.data.message, false );
			// The entry is indexed, so the inventory it should appear in is now stale.
			reloadKnowledge( root );
		} ).catch( function () {
			button.disabled = false;
			button.textContent = label;
			kbNotice( root, cfg.i18n.actionFailed, true );
		} );
	}

	/**
	 * The page's click delegation.
	 *
	 * One listener on the page root rather than one per button: the table's rows are replaced
	 * on every load, and per-button listeners would have to be re-bound each time (or leak).
	 * The switches are the exception — they are bound at construction because each one closes
	 * over the item it acts on.
	 */
	function bindKnowledgeActions( root ) {
		root.addEventListener( 'click', function ( event ) {
			var trigger = event.target.closest( '[data-wcai-action]' );
			if ( ! trigger || ! root.contains( trigger ) ) {
				return;
			}
			var action = trigger.getAttribute( 'data-wcai-action' );

			if ( action === 'manual-open' ) {
				kbPanel( root, 'manual' );
				var titleInput = root.querySelector( '[data-wcai-input="manualTitle"]' );
				if ( titleInput ) {
					titleInput.focus();
				}
			} else if ( action === 'resync-open' ) {
				kbPanel( root, 'resync' );
			} else if ( action === 'panel-close' ) {
				kbPanel( root, null );
			} else if ( action === 'manual-save' ) {
				saveManualEntry( root, trigger );
			} else if ( action === 'override-gate' ) {
				// Disabled for the duration: this is a write the merchant is watching, and a
				// second click while the first is in flight would be a second POST whose
				// response races the first to re-render the same card.
				trigger.disabled = true;
				post( 'wcai_kb_override_gate' ).then( function ( response ) {
					if ( ! response.success ) {
						// Re-enabled on failure, unlike the success path. The backend answers
						// 503 when it could not record the decision, and leaving the button
						// dead there would strand the merchant on a card that says they are
						// not live with no way to retry.
						trigger.disabled = false;
						kbNotice( root, ( response.data && response.data.message ) || cfg.i18n.actionFailed, true );
						return;
					}
					// Re-rendered from the backend's recomputed score rather than by flipping
					// a flag locally, so the card and the gate cannot disagree.
					renderQuality( root, response.data.quality );
					kbNotice( root, response.data.message, false );
				} ).catch( function () {
					trigger.disabled = false;
					kbNotice( root, cfg.i18n.actionFailed, true );
				} );
			} else if ( action === 'resync-confirm' ) {
				kbPanel( root, null );
				post( 'wcai_kb_resync' ).then( function ( response ) {
					if ( ! response.success ) {
						kbNotice( root, ( response.data && response.data.message ) || cfg.i18n.actionFailed, true );
						return;
					}
					// No "Re-index scheduled" toast: the progress panel appears on the next
					// tick and *is* the confirmation. The toast used to promise "this page
					// will show progress" directly above the panel already showing it — and,
					// worse, it stayed on screen as a green success line above the red
					// panel when the walk later failed. The notice box is reserved for
					// request failures now; `renderProgress()` also hides it defensively.
					//
					// `kbWasIndexing` is set here rather than waiting for the first poll to
					// see `isActive`: a walk over a tiny catalogue can finish inside the
					// first interval, and the merchant should still get the table refreshed
					// for a click they definitely made.
					hide( root.querySelector( '[data-wcai-kb-notice]' ) );
					kbWasIndexing = true;
					pollResyncProgress( root );
				} ).catch( function () {
					kbNotice( root, cfg.i18n.actionFailed, true );
				} );
			} else if ( action === 'page-prev' || action === 'page-next' ) {
				// The page size comes from PHP, where `KnowledgePage::PAGE_SIZE` is also what
				// the request is made with. A literal here would be a second copy of it, and
				// the two would drift the first time the constant is tuned.
				var step = action === 'page-next' ? cfg.pageSize : -cfg.pageSize;
				kbOffset = Math.max( 0, kbOffset + step );
				reloadKnowledge( root );
			}
		} );
	}

	// -- health check (add-merchant-insight-ops §4.1/§4.4) ---------------------

	/**
	 * One `HealthCheckItem` row.
	 *
	 * Every string here — label, explanation, fix, the "last checked" line — was already
	 * translated and formatted in PHP (`HealthCheckPage::payload()`), including the fix
	 * text SR-005 requires: this function only builds the DOM around values it did not
	 * author, the same rule the rest of this file follows.
	 */
	function healthItem( item ) {
		var li = document.createElement( 'li' );
		li.className = 'wcai-health-item wcai-health-' + item.status;

		var head = document.createElement( 'div' );
		head.className = 'wcai-health-item-head';

		var label = document.createElement( 'strong' );
		label.textContent = item.label;
		head.appendChild( label );

		var badge = document.createElement( 'span' );
		badge.className = 'wcai-health-badge';
		badge.textContent = item.statusLabel;
		head.appendChild( badge );

		li.appendChild( head );

		var explanation = document.createElement( 'p' );
		explanation.textContent = item.explanation;
		li.appendChild( explanation );

		// `fix` is present on every non-healthy check (the contract's own invariant,
		// FR-018/SR-005) — this branch is what keeps a check that somehow arrives without
		// one from rendering an empty, confusing paragraph rather than just omitting it.
		if ( item.fix ) {
			var fix = document.createElement( 'p' );
			fix.className = 'wcai-health-fix';
			fix.textContent = item.fix;
			li.appendChild( fix );
		}

		if ( item.resyncUrl ) {
			var cta = document.createElement( 'a' );
			cta.className = 'button button-secondary wcai-health-cta';
			cta.href = item.resyncUrl;
			cta.textContent = cfg.i18n.openKnowledgeBase;
			li.appendChild( cta );
		}

		if ( item.lastVerified ) {
			var verified = document.createElement( 'p' );
			verified.className = 'wcai-health-verified';
			verified.textContent = item.lastVerified;
			li.appendChild( verified );
		}

		return li;
	}

	function renderHealth( root, health ) {
		var banner = field( root, 'overallBanner' );
		if ( banner ) {
			banner.className = 'wcai-health-overall wcai-health-' + health.overall;
			banner.textContent = health.overallLabel;
			show( banner );
		}

		var list = root.querySelector( '[data-wcai-health-list]' );
		if ( list ) {
			list.textContent = '';
			health.checks.forEach( function ( item ) {
				list.appendChild( healthItem( item ) );
			} );
			show( list );
		}
	}

	// -- boot ------------------------------------------------------------------

	function loadOverview( root ) {
		post( 'wcai_panel_overview' )
			.then( function ( response ) {
				clearLoading( root );
				if ( ! response.success ) {
					renderError( root, response.data );
					return;
				}
				updatePill( response.data.state, response.data.stateLabel );
				renderOverview( root, response.data.overview );

				// ES-001 wins outright. While it shows there are no metric cards on the
				// page to fill, and a store still on its first index pass has no
				// conversations *by definition* — so `analytics.isEmpty` is always true
				// here and the second request could only ever add ES-002's "No
				// conversations yet" underneath ES-001's "Setting up your assistant":
				// two different explanations for one blank screen. ES-002 means "indexed
				// and live, but nobody has asked anything yet", which is not this state.
				if ( response.data.overview && response.data.overview.isIndexing ) {
					return;
				}

				// Second request only once the pill is correct; see the page's note on
				// why the two endpoints are not awaited together.
				return post( 'wcai_panel_analytics' ).then( function ( analytics ) {
					if ( analytics.success ) {
						fillOverviewFromAnalytics( root, analytics.data.analytics );
					}
				} );
			} )
			.catch( function () {
				clearLoading( root );
				renderError( root, null );
			} );
	}

	function loadAnalyticsPage( root, render, key ) {
		post( 'wcai_panel_analytics' )
			.then( function ( response ) {
				clearLoading( root );
				if ( ! response.success ) {
					renderError( root, response.data );
					return;
				}
				// The pill is on every page, and this endpoint does not carry it — the
				// server-rendered cached state stands until the merchant opens Overview.
				render( root, response.data[ key ] );
			} )
			.catch( function () {
				clearLoading( root );
				renderError( root, null );
			} );
	}

	function loadHealthPage( root ) {
		post( 'wcai_panel_health' )
			.then( function ( response ) {
				clearLoading( root );
				if ( ! response.success ) {
					renderError( root, response.data );
					return;
				}
				renderHealth( root, response.data.health );
				setText( root, 'indexingProgress', response.data.indexing.text );
			} )
			.catch( function () {
				clearLoading( root );
				renderError( root, null );
			} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var overview = document.querySelector( '[data-wcai-page="overview"]' );
		if ( overview ) {
			loadOverview( overview );
		}

		var analytics = document.querySelector( '[data-wcai-page="analytics"]' );
		if ( analytics ) {
			loadAnalyticsPage( analytics, renderAnalytics, 'analytics' );
		}

		var unanswered = document.querySelector( '[data-wcai-page="unanswered"]' );
		if ( unanswered ) {
			loadAnalyticsPage( unanswered, renderUnanswered, 'unanswered' );
		}

		var knowledge = document.querySelector( '[data-wcai-page="knowledge"]' );
		if ( knowledge ) {
			bindKnowledgeActions( knowledge );
			loadKnowledge( knowledge );
			// Not gated on having clicked the button in this session: the walk that matters
			// most is the one the onboarding wizard starts, which the merchant meets by
			// arriving on this page afterwards. One poll costs a cheap option read and
			// stops immediately when nothing is running.
			pollResyncProgress( knowledge );
		}

		var health = document.querySelector( '[data-wcai-page="health"]' );
		if ( health ) {
			loadHealthPage( health );
		}
	} );
} )();
