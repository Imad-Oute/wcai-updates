/**
 * Onboarding wizard client (`ux-design/.../Onboarding Wizard.dc.html`, FR-002, US-007).
 *
 * Enhancements over screens that already work without JavaScript. Every one of the six
 * steps is a real page that submits a real form; nothing here is load-bearing, and the
 * server re-validates everything it is handed.
 *
 *   Step 2  Gate the Activate button on a non-empty key plus ticked consent, and run the
 *           connectivity pre-flight (`wcai_wizard_check_connectivity`). It never judges
 *           the key itself — see the PHP handler on why a keystroke must not bind a
 *           license.
 *   Step 4  Poll `wcai_wizard_indexing` so the progress line moves while the merchant
 *           watches, rather than needing a manual refresh to tell the truth.
 *   Step 5  Post "Publish anyway" without losing the page.
 *   Step 6  Preview the accent colour live, and dim the picker while "match my theme"
 *           owns the value.
 *
 * ## Why each block guards itself instead of the file returning early
 *
 * These run on *different screens of the same page*, so at most a couple of them find
 * their elements on any given load. An early `return` on a missing licence field — which
 * is how this file was originally written, back when step 2 was the only enhanced screen
 * — would silently disable steps 4-6, and the symptom would be a progress bar that never
 * moves rather than an error anyone would notice. Each block therefore looks for its own
 * elements and does nothing when they are absent.
 *
 * Vanilla ES5-compatible DOM, no build step — same reasoning as `panel.js`: this file is
 * hand-written source served straight from `admin/`, and adding a bundler for ~250 lines
 * would put the wizard behind the same build that already shipped a stale widget once.
 *
 * @package WooAIChat
 */

/* global wcaiWizard */
( function () {
	'use strict';

	if ( typeof wcaiWizard === 'undefined' ) {
		return;
	}

	/**
	 * POST to admin-ajax with the wizard's nonce.
	 *
	 * `credentials: 'same-origin'` because admin-ajax authenticates by cookie; without it
	 * every call arrives logged-out and fails its capability check.
	 *
	 * @param {string} action The `wp_ajax_` action name.
	 * @param {Object} fields Extra form fields, if any.
	 * @return {Promise<Object>} The decoded response envelope.
	 */
	function post( action, fields ) {
		var body = new window.FormData();
		var name;

		body.append( 'action', action );
		body.append( 'nonce', wcaiWizard.nonce );

		if ( fields ) {
			for ( name in fields ) {
				if ( Object.prototype.hasOwnProperty.call( fields, name ) ) {
					body.append( name, fields[ name ] );
				}
			}
		}

		return window.fetch( wcaiWizard.ajaxUrl, {
			method: 'POST',
			body: body,
			credentials: 'same-origin'
		} ).then( function ( response ) {
			return response.json();
		} );
	}

	/* ---------------------------------------------------------------------------------
	 * Step 2 — license key
	 * ------------------------------------------------------------------------------- */

	( function licenseStep() {
		var form = document.querySelector( '.wcai-wizard-form' );

		if ( ! form ) {
			return;
		}

		var keyField = form.querySelector( '#wcai_license_key' );
		var consent = form.querySelector( '[data-wcai-consent]' );
		var submit = form.querySelector( '[data-wcai-submit]' );
		var status = document.querySelector( '[data-wcai-license-status]' );

		// Steps 4-6 also render a `.wcai-wizard-form` (it carries their navigation
		// buttons), so finding a form proves nothing on its own — these three fields are
		// what identify step 2.
		if ( ! keyField || ! consent || ! submit ) {
			return;
		}

		// Only the two the probe can produce. `wcai-license-ok`/`-err` belong to a verdict
		// on the key, which this file does not render.
		var STATUS_CLASSES = [
			'wcai-license-warn',
			'wcai-license-checking'
		];

		var probeTimer = null;

		/**
		 * Paint the connectivity line under the license field.
		 *
		 * `textContent`, never `innerHTML`: the message can carry a backend-supplied host
		 * name, and this element sits inside an authenticated admin page.
		 *
		 * @param {string} message Text to show; empty clears the line.
		 * @param {string} variant One of the STATUS_CLASSES, or '' for neutral.
		 */
		function setStatus( message, variant ) {
			if ( ! status ) {
				return;
			}

			STATUS_CLASSES.forEach( function ( name ) {
				status.classList.remove( name );
			} );

			status.textContent = message || '';

			if ( variant ) {
				status.classList.add( variant );
			}
		}

		/**
		 * The Activate button is available only when both inputs are satisfied.
		 *
		 * Consent is a legal precondition (NFR-032/RC-001), not a preference, so it gates
		 * the control rather than producing a warning after the fact.
		 */
		function syncSubmitState() {
			submit.disabled = ! ( '' !== keyField.value.trim() && consent.checked );
		}

		/**
		 * Ask the backend whether the licensing service is reachable.
		 *
		 * Connectivity only, never the key itself — see `ajax_check_connectivity()` on why
		 * a keystroke must not bind a license to this site. A merchant who is offline
		 * learns it here instead of from a failed activation. The wording stays
		 * "connection", not "license", so the message matches what was actually checked.
		 */
		function probe() {
			var key = keyField.value.trim();

			if ( '' === key ) {
				setStatus( '', '' );
				return;
			}

			setStatus( wcaiWizard.i18n.checking, 'wcai-license-checking' );

			post( 'wcai_wizard_check_connectivity', { license_key: key } ).then(
				function ( payload ) {
					if ( ! payload || ! payload.success || ! payload.data ) {
						setStatus( wcaiWizard.i18n.unreachable, 'wcai-license-warn' );
						return;
					}

					if ( 'unreachable' === payload.data.state ) {
						setStatus(
							payload.data.message || wcaiWizard.i18n.unreachable,
							'wcai-license-warn'
						);
						return;
					}

					// 'reachable' means the service answered — it says nothing about the
					// key. The line is cleared rather than showing a tick, so the merchant
					// is never told "accepted" about a key activation may yet reject.
					setStatus( '', '' );
				}
			).catch( function () {
				// A network failure here is itself the answer the merchant needs.
				setStatus( wcaiWizard.i18n.unreachable, 'wcai-license-warn' );
			} );
		}

		/** Debounced so typing a 20-character key is one request, not twenty. */
		function scheduleProbe() {
			window.clearTimeout( probeTimer );
			probeTimer = window.setTimeout( probe, 600 );
		}

		keyField.addEventListener( 'input', function () {
			syncSubmitState();
			scheduleProbe();
		} );

		consent.addEventListener( 'change', syncSubmitState );

		// Submitting is a one-shot action against a license binding: a double-click must
		// not send two activations, so the button latches off as the form goes.
		form.addEventListener( 'submit', function () {
			submit.disabled = true;
		} );

		syncSubmitState();
	}() );

	/* ---------------------------------------------------------------------------------
	 * Step 4 — indexing progress
	 * ------------------------------------------------------------------------------- */

	( function indexingStep() {
		var region = document.querySelector( '[data-wcai-index-status]' );

		if ( ! region ) {
			return;
		}

		var fill = region.querySelector( '[data-wcai-index-fill]' );
		var line = region.querySelector( '[data-wcai-index-line]' );
		var detail = region.querySelector( '[data-wcai-index-detail]' );
		var count = region.querySelector( '[data-wcai-index-count]' );

		// Five seconds is slow enough that a merchant reading the screen for a minute
		// costs the backend a dozen requests, and fast enough that a finishing index is
		// reflected while they are still looking at it.
		var INTERVAL = 5000;

		// A merchant who leaves this tab open all afternoon must not poll all afternoon.
		//
		// Raised from 20 (~100s) once the bar started reporting a real cursor: a catalogue of
		// a few hundred items walks for longer than that, and the old window expired
		// mid-walk — replacing a moving bar with "this continues in the background", which
		// reads as the step having given up. 120 polls is ten minutes, past a typical first
		// sync, and the background message still catches anything longer.
		var MAX_POLLS = 120;

		var polls = 0;
		var timer = null;

		/**
		 * Terminal states — there is nothing further for a poll to learn.
		 *
		 * `idle` is only terminal *with content already indexed*: the first sync finished
		 * before the merchant reached this screen. `idle` with an empty index is the
		 * opposite — the sync has not started reporting yet (the backend's queue relay
		 * reads `idle/0/0` until the first batch lands), and stopping here is what froze
		 * the "live progress" this step promises on its very first poll.
		 */
		function isSettled( state, total ) {
			// `done` is what the local walk record reports when it drains its last phase
			// (`IndexingProgress::STATE_DONE`); `complete` is the backend contract's word for
			// the same thing. Both are terminal, and matching only one of them would leave
			// the poll running against a finished walk until MAX_POLLS cut it off.
			if ( 'complete' === state || 'done' === state || 'failed' === state ) {
				return true;
			}

			return 'idle' === state && total > 0;
		}

		function stop() {
			window.clearTimeout( timer );
			timer = null;
		}

		function render( data ) {
			// Stamped so the stylesheet can colour the bar by outcome — a walk the plan
			// refused rendered a full *accent* bar over "could not store any of your
			// content", which is failure wearing success's clothes.
			if ( data.state ) {
				region.setAttribute( 'data-state', data.state );
			}

			if ( fill && 'number' === typeof data.percent ) {
				fill.style.width = Math.max( 0, Math.min( 100, data.percent ) ) + '%';
			}

			// `textContent`, not `innerHTML`: these strings are composed server-side and
			// carry merchant-influenced counts.
			if ( line && data.text ) {
				line.textContent = data.text;
			}

			// Assigned unconditionally, unlike the line above: an empty `detail` is a real
			// answer (the backend-shaped fallback has none), and skipping the write would
			// leave the previous poll's phase and estimate on screen after the walk moved on.
			if ( detail ) {
				detail.textContent = data.detail || '';
			}

			if ( count ) {
				count.textContent = data.countText || '';
			}
		}

		function poll() {
			polls += 1;

			post( 'wcai_wizard_indexing' ).then( function ( payload ) {
				if ( ! payload || ! payload.success || ! payload.data ) {
					// A refused or malformed answer is not worth retrying twenty times.
					if ( line ) {
						line.textContent = wcaiWizard.i18n.indexOffline;
					}
					stop();
					return;
				}

				render( payload.data );

				if ( isSettled( payload.data.state, payload.data.total ) ) {
					stop();
					return;
				}

				if ( polls >= MAX_POLLS ) {
					// The observation window is a courtesy, not the job's lifetime: the
					// sync carries on server-side after it. Stopping without saying so
					// would leave the last line reading as the final state of the index.
					if ( line ) {
						line.textContent = wcaiWizard.i18n.indexBackground;
					}
					stop();
					return;
				}

				timer = window.setTimeout( poll, INTERVAL );
			} ).catch( function () {
				// One dropped request is not a failed index — the work is server-side and
				// carries on regardless — so this reports the *reading* as unavailable and
				// stops, rather than implying the indexing itself broke.
				if ( line ) {
					line.textContent = wcaiWizard.i18n.indexOffline;
				}
				stop();
			} );
		}

		poll();

		// Leaving the page mid-poll would otherwise leave a timer holding a closure over
		// detached nodes until the browser tears the document down.
		window.addEventListener( 'beforeunload', stop );
	}() );

	/* ---------------------------------------------------------------------------------
	 * Step 5 — publish below the quality bar
	 * ------------------------------------------------------------------------------- */

	( function overrideStep() {
		var button = document.querySelector( '[data-wcai-wizard-override]' );

		if ( ! button ) {
			return;
		}

		var box = document.querySelector( '[data-wcai-override-box]' );
		var status = document.querySelector( '[data-wcai-override-status]' );

		function say( message ) {
			if ( status ) {
				status.textContent = message;
			}
		}

		button.addEventListener( 'click', function () {
			// Latched immediately: this records a decision on the backend, and a
			// double-click is two writes of the same one.
			button.disabled = true;
			say( wcaiWizard.i18n.overrideWorking );

			post( 'wcai_wizard_override' ).then( function ( payload ) {
				if ( payload && payload.success && payload.data && payload.data.message ) {
					// The button is gone rather than re-enabled — the decision is made,
					// and offering it again would invite a merchant to wonder whether the
					// first press worked.
					button.remove();

					if ( box ) {
						box.classList.add( 'is-done' );
					}

					say( payload.data.message );
					return;
				}

				// A failure has to leave the button usable. The backend answers 503 rather
				// than a false 200 precisely so this state is recoverable by retrying.
				button.disabled = false;
				say(
					( payload && payload.data && payload.data.message ) ||
						wcaiWizard.i18n.overrideFailed
				);
			} ).catch( function () {
				button.disabled = false;
				say( wcaiWizard.i18n.overrideFailed );
			} );
		} );
	}() );

	/* ---------------------------------------------------------------------------------
	 * Step 6 — widget colour
	 * ------------------------------------------------------------------------------- */

	( function colourStep() {
		var input = document.querySelector( '[data-wcai-colour-input]' );

		if ( ! input ) {
			return;
		}

		var auto = document.querySelector( '[data-wcai-colour-auto]' );
		var swatch = document.querySelector( '[data-wcai-colour-swatch]' );
		var fields = input.closest( '.wcai-colour-fields' );

		/**
		 * Show what the save will actually store.
		 *
		 * While "match my theme" is ticked the picker's value is about to be discarded, so
		 * the swatch keeps the server-rendered theme accent rather than following a
		 * control whose value will not be used. The class dims the picker to say the same
		 * thing visually.
		 *
		 * The preview cannot apply AX-002's contrast darkening — that lives in PHP, and
		 * duplicating the algorithm here would be a second implementation to keep in step.
		 * The saved result re-renders through `accent()`, which is where the darkening and
		 * its explanatory line come from.
		 */
		function sync() {
			var isAuto = !! ( auto && auto.checked );

			if ( fields ) {
				fields.classList.toggle( 'is-auto', isAuto );
			}

			if ( swatch && ! isAuto ) {
				swatch.style.background = input.value;
			}
		}

		input.addEventListener( 'input', sync );

		if ( auto ) {
			auto.addEventListener( 'change', sync );
		}

		sync();
	}() );
}() );
