<?php
/**
 * Uninstall routine (`add-foundation-onboarding §1.5`, NFR-039).
 *
 * Gated by `WP_UNINSTALL_PLUGIN` — WordPress only fires this when the merchant clicks
 * "Delete" in the plugins admin, after the plugin has already been deactivated. A
 * request that loads `uninstall.php` outside the WP-uninstall flow stops at that
 * check.
 *
 * Local purge + backend erasure request, in that order — the spec calls out that
 * "WooCommerce data untouched" (NFR-039). The plugin does NOT drop custom tables (none
 * exist; state lives in `wp_options`), and does NOT touch WooCommerce's own data. The
 * `Lifecycle::uninstall()` call itself is the entire purge; this file's own job is to
 * re-declare the `WAI_*` constants that call reads — WordPress includes `uninstall.php`
 * directly and never loads the main plugin file, so nothing else defines them here.
 *
 * No autoloader is required, deliberately (see `Lifecycle::uninstall()`'s docblock): a
 * missing class would fatal the uninstall exactly like the missing constants did before
 * this file defined them.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! defined( 'WAI_PLUGIN_DIR' ) ) {
	// Loaded standalone outside the plugin root — re-declare what's safe.
	define( 'WAI_PLUGIN_DIR', plugin_dir_path( __DIR__ . '/woocommerce-ai-chat.php' ) );
}

// The `wai_*` option/transient keys `Lifecycle::uninstall()` reads and deletes. Kept in
// sync with the `define()` block in `woocommerce-ai-chat.php` — that file is never
// loaded on this request, so its constants do not exist unless re-declared here.
if ( ! defined( 'WAI_OPTION_STORE_TOKEN' ) ) {
	define( 'WAI_OPTION_STORE_TOKEN', 'wai_store_token' );
}
if ( ! defined( 'WAI_OPTION_WIDGET_TOKEN' ) ) {
	define( 'WAI_OPTION_WIDGET_TOKEN', 'wai_widget_token' );
}
if ( ! defined( 'WAI_OPTION_STORE_ID' ) ) {
	define( 'WAI_OPTION_STORE_ID', 'wai_store_id' );
}
if ( ! defined( 'WAI_OPTION_SITE_FINGERPRINT' ) ) {
	define( 'WAI_OPTION_SITE_FINGERPRINT', 'wai_site_fingerprint' );
}
if ( ! defined( 'WAI_OPTION_LICENSE_KEY_HASH' ) ) {
	define( 'WAI_OPTION_LICENSE_KEY_HASH', 'wai_license_key_hash' );
}
if ( ! defined( 'WAI_OPTION_CONSENT' ) ) {
	define( 'WAI_OPTION_CONSENT', 'wai_consent_recorded' );
}
if ( ! defined( 'WAI_OPTION_SUBSCRIPTION_CACHE' ) ) {
	define( 'WAI_OPTION_SUBSCRIPTION_CACHE', 'wai_subscription_state' );
}
if ( ! defined( 'WAI_TRANSIENT_SUBSCRIPTION_STATE' ) ) {
	define( 'WAI_TRANSIENT_SUBSCRIPTION_STATE', 'wai_subscription_state_transient' );
}
if ( ! defined( 'WAI_ACTION_SCHEDULER_GROUP' ) ) {
	define( 'WAI_ACTION_SCHEDULER_GROUP', 'wc_ai_agent' );
}

require_once WAI_PLUGIN_DIR . 'src/Compatibility.php';
// `Encryption` decrypts the stored store-token blob so the backend erasure request can
// send the actual Bearer token — the encrypted blob is a guaranteed 401.
require_once WAI_PLUGIN_DIR . 'src/Encryption.php';
require_once WAI_PLUGIN_DIR . 'src/Lifecycle.php';

\WooAIChat\Lifecycle::uninstall();
