<?php
/**
 * Storefront widget enqueue (`add-shopper-chat` §4.2/§4.7, FR-005/019/026).
 *
 * `wp_enqueue_scripts` is the only hook this class touches: it decides whether the
 * bundled widget (`assets/js/widget.js`, `add-build-rails §3.3`) loads on the current
 * page at all, and if so, localizes exactly what `widget/src/index.ts`'s `WidgetConfig`
 * reads from `window.wcaiWidgetConfig` — the backend origin, the public widget token,
 * the chrome locale, and the contact-link fallback. This class only decides *whether*
 * and *with what config* the bundle boots; the bundle itself is `add-shopper-chat` §4.1.
 *
 * **FR-026 is a partial implementation, honestly.** The requirement names five reasons
 * to hide the widget: subscription inactive, indexing incomplete, content quality below
 * threshold, quota exhausted, merchant-disabled. Only the first has a real backend
 * signal today — `SubscriptionGate::is_widget_available()`, reading `/v1/auth/status`
 * (a real, implemented endpoint). The other four all depend on `/v1/merchant/overview`'s
 * composite `WidgetState`, which is still an unimplemented stub on the backend
 * (`app/api/v1/generated/routers.py` — no real handler registered; confirmed by grep) —
 * that field belongs to indexing/quality/quota epics that haven't shipped it yet. Wiring
 * against a stub would mean gating on data that doesn't exist, so this only consumes the
 * one condition with a real signal; the rest is `add-merchant-insight-ops`'s job to wire
 * once `/v1/merchant/overview` is real.
 *
 * @package WooAIChat
 *
 * @invariant Same invariant `Widget\NamespaceMarker` documents: the store token is
 *   never localized. This class only ever reads `TokenStore::get_widget_token()`; see
 *   `StoreTokenLeakAuditTest` for the machine-checked half of that rule.
 */

declare(strict_types=1);

namespace WooAIChat\Widget;

use WooAIChat\Admin\WidgetSettings;
use WooAIChat\Auth\BackendUrl;
use WooAIChat\Auth\SubscriptionGate;
use WooAIChat\Auth\TokenStore;

/**
 * Registers the front-end enqueue for the storefront widget bundle.
 */
final class Enqueue {

	private const HANDLE = 'wcai-widget';

	private TokenStore $tokens;
	private SubscriptionGate $gate;
	private string $backend_url;

	/**
	 * Resolves the merchant's widget configuration (FR-012).
	 *
	 * A callable rather than a `WidgetSettings` instance because that class is `final` —
	 * sealing it is right (its accent resolution is a security-relevant invariant, not an
	 * extension point), but it means a test cannot double it. Taking the resolver as a
	 * seam keeps the class sealed *and* lets this one be tested without theme mods, an
	 * options table, or a live WordPress.
	 *
	 * Production always passes the panel's own instance, so the values the Settings form
	 * writes are the values the storefront ships.
	 *
	 * @var callable(): array<string, mixed>
	 */
	private $resolve_config;

	/**
	 * @param TokenStore       $tokens      Read access to the widget token.
	 * @param SubscriptionGate $gate        FR-026's (partial — see class docblock)
	 *                                      availability gate.
	 * @param string|null      $backend_url The `apiBase` localized to the widget. Same
	 *                                      override pattern as `BackendClient::__construct`
	 *                                      — defaults to `WAI_BACKEND_URL` (deployer-defined,
	 *                                      no default), overridable so tests never need the
	 *                                      constant defined.
	 * @param callable|null    $resolve_config Returns the resolved widget configuration;
	 *                                      defaults to a fresh `WidgetSettings`.
	 */
	public function __construct(
		TokenStore $tokens,
		SubscriptionGate $gate,
		?string $backend_url = null,
		?callable $resolve_config = null
	) {
		$this->tokens = $tokens;
		$this->gate   = $gate;
		// The widget runs in the shopper's browser, so its `apiBase` must be a URL the
		// browser can reach — which is `WAI_BACKEND_URL`, the canonical public base URL,
		// and never `WAI_INTERNAL_BACKEND_URL`. There is deliberately no second value to
		// fall back to here: an internal URL in `apiBase` cannot work, so guessing one
		// would only choose *which* way to be wrong. See `Auth\BackendUrl`.
		$this->backend_url    = $backend_url ?? BackendUrl::canonical();
		$this->resolve_config = $resolve_config ?? static function (): array {
			return ( new WidgetSettings() )->widget_config();
		};
	}

	/** Register the front-end enqueue hook. */
	public function register(): void {
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue' ) );
	}

	/**
	 * Enqueue the widget bundle unless the current page is excluded, the backend gate
	 * (subscription state only — see class docblock) says the widget isn't available,
	 * or the store has no widget token yet (not onboarded, or a 401 cleared the store
	 * token and the merchant has not re-activated).
	 */
	public function maybe_enqueue(): void {
		if ( $this->is_excluded_page() ) {
			return;
		}

		if ( ! $this->gate->is_widget_available() ) {
			return;
		}

		$widget_token = $this->tokens->get_widget_token();
		if ( '' === $widget_token ) {
			return;
		}

		// An `apiBase` the browser cannot safely use is not worth shipping the bundle for.
		// Loading it anyway costs the shopper a request and then fails one of two ways:
		// `readConfig()` returns null on an empty value and the widget silently does not
		// exist, or the fetch dies at DNS on a container hostname and the panel sits on
		// "Warming up — reconnecting…" forever. Neither leaves a trace in the backend logs,
		// which is what made this class of misconfiguration so expensive to diagnose
		// (`docs/LOCAL-TESTING-ISSUES-2026-08-01.md` §6.1). The merchant is told instead —
		// see `Admin\HealthCheckPage`'s storefront row, which reports the same verdict with
		// the resolved URL printed next to it.
		if ( ! self::api_base_usable( $this->backend_url ) ) {
			return;
		}

		// FR-012: the merchant's own off switch. Checked after the gate rather than before
		// it because the gate answers "may this store serve chat at all" and this answers
		// "does this merchant want it shown" — a lapsed store must stay off regardless of
		// what the toggle says, and only this order gives that.
		$config = ( $this->resolve_config )();
		if ( ! $config['enabled'] ) {
			return;
		}

		wp_enqueue_script(
			self::HANDLE,
			WAI_PLUGIN_URL . 'assets/js/widget.js',
			array(),
			WAI_VERSION,
			true
		);

		wp_localize_script(
			self::HANDLE,
			'wcaiWidgetConfig',
			array(
				'apiBase'       => $this->backend_url,
				'widgetToken'   => $widget_token,
				// The merchant's locale override wins when set; the site language is the
				// fallback. `WidgetSettings` resolves the override to '' when the merchant
				// chose "follow the page", which is exactly when `get_bloginfo` is right.
				'locale'        => '' !== $config['locale'] ? $config['locale'] : get_bloginfo( 'language' ),
				// FR-021/FR-024's merchant-configured contact link. Falls back to the site
				// home so the deflection link is never dead on a store that never set one.
				'contactUrl'    => '' !== $config['fallbackUrl'] ? $config['fallbackUrl'] : home_url( '/' ),
				'position'      => $config['position'],
				// Already AX-002-corrected by `WidgetSettings::accent()` — the raw
				// pre-darkening colour never reaches this array.
				'accentColor'   => $config['accentColor'],
				'title'         => $config['title'],
				'placeholder'   => $config['placeholder'],
				'triggerDelay'  => $config['triggerDelay'],
				'triggerScroll' => $config['triggerScroll'],
				'disclaimer'    => $config['disclaimer'],
				'childAudience' => $config['childAudience'],
			)
		);
	}

	/**
	 * Cart, checkout, and My Account pages are excluded (FR-005) — a shopper mid-
	 * purchase or managing their account is not the widget's audience. `is_cart()`/
	 * `is_checkout()`/`is_account_page()` are always defined by the time
	 * `wp_enqueue_scripts` fires — WooCommerce is a hard dependency
	 * (`Requires Plugins: woocommerce`) already loaded before this hook.
	 */
	private function is_excluded_page(): bool {
		return is_cart() || is_checkout() || is_account_page();
	}

	/**
	 * Whether an `apiBase` is worth shipping to a shopper's browser.
	 *
	 * Three ways it is not, and they are the three that have actually happened:
	 *
	 *   - **empty** — the constant is undefined, or defined blank. `readConfig()` bails and
	 *     the widget silently does not exist.
	 *   - **a container hostname** — `http://backend:8000`. Public DNS cannot contain a
	 *     dotless name, so the shopper's fetch dies at resolution and nothing reaches the
	 *     backend. This is §6.1 verbatim.
	 *   - **insecure transport** — plain `http` to a public host. The widget token and every
	 *     shopper message cross that connection; it gets the same rule as the store token's
	 *     (NFR-014), which is the rule it never had while `apiBase` was resolved from its
	 *     own unvalidated constant.
	 *
	 * Public so `HealthCheckPage` can render the same verdict rather than reimplement it —
	 * a second opinion on whether the storefront works is exactly the contradiction D-3
	 * rules out.
	 *
	 * @param string $api_base The resolved `apiBase`.
	 */
	public static function api_base_usable( string $api_base ): bool {
		if ( '' === $api_base ) {
			return false;
		}
		if ( BackendUrl::is_container_hostname( (string) wp_parse_url( $api_base, PHP_URL_HOST ) ) ) {
			return false;
		}

		return BackendUrl::is_transport_safe( $api_base );
	}
}
