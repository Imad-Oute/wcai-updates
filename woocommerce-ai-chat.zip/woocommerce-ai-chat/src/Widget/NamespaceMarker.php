<?php
/**
 * Stub marking the `WooAIChat\Widget` sub-namespace (`add-foundation-onboarding §1.2`).
 *
 * Owned by `add-shopper-chat` — the storefront widget (vanilla-JS, <30KB gz, defer/
 * async) is enqueued from here. The §3.3 "store token never localized to JS"
 * invariant lands now (below) and is the standing rule the shopper-chat widget
 * inherits: the *widget* token (non-secret, scoped to chat for one store) is the
 * only value ever carried across `wp_localize_script`; the *store* token stays
 * server-side by construction.
 *
 * @package WooAIChat
 *
 * @invariant The store token (`WAI_OPTION_STORE_TOKEN`, AES-256-CBC-decrypted) is
 *   never passed through `wp_localize_script`, never written to an enqueued script's
 *   `before`/`after` inline, and never echoed into the DOM. The widget token alone
 *   crosses the server↔client boundary, and even it is exchanged for a short-lived
 *   session token before the storefront issues a chat request.
 */

declare(strict_types=1);

namespace WooAIChat\Widget;

final class NamespaceMarker {
}
