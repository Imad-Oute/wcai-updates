<?php
/**
 * At-rest encryption for the store token (`add-foundation-onboarding` §3.2).
 *
 * The store token is a bearer secret: anything holding it can perform this store's
 * authenticated backend operations until the token is rotated (D17). It lives on someone
 * else's server — a shared-hosting WordPress the Client does not control and cannot patch —
 * so the realistic threat is not a compromised backend but a `wp_options` dump: a leaked
 * database backup, a SQL-injection in an unrelated plugin, a support export. NFR-018
 * answers that by requiring the token be ciphertext in the options table, decryptable only
 * by code running on that site.
 *
 * Design D-2 fixes the shape: **AES-256-CBC keyed from `wp_salt('auth')`, fresh IV per
 * write.** Each half of that is load-bearing, and each is pinned by a test in
 * `tests/unit/EncryptionTest.php`:
 *
 * - **The key never appears in the database.** `wp_salt('auth')` lives in `wp-config.php`
 *   (or the salt table), not in `wp_options`, so an attacker holding only an options dump
 *   holds only ciphertext. The salt is a passphrase of arbitrary length, not a 32-byte key,
 *   so it is run through SHA-256 to derive one — the standard way to turn a WordPress salt
 *   into an AES-256 key without truncating or padding it.
 * - **A fresh IV per write is mandatory, not hygiene.** CBC with a fixed IV is
 *   deterministic: the same plaintext yields the same ciphertext, so an observer of two
 *   dumps learns whether the token changed, and identical leading blocks leak equality
 *   across stores sharing a key. Worse, a reused IV under the same key leaks the XOR of the
 *   first plaintext blocks. `random_bytes()` supplies a CSPRNG IV per call, and the IV is
 *   prepended to the ciphertext because it is public by design — it must be recoverable to
 *   decrypt, and its secrecy was never what protected anything.
 * - **The ciphertext is authenticated.** CBC alone is malleable: an attacker with write
 *   access to `wp_options` can flip plaintext bits by flipping ciphertext bits, and CBC
 *   padding errors are a classic padding-oracle. Since the contract names CBC (not GCM),
 *   authentication is added explicitly as encrypt-then-MAC — HMAC-SHA256 over `iv || ct`
 *   with a *separate* derived key — and verified in constant time before any decrypt is
 *   attempted. A tampered value fails closed (returns null) rather than decrypting into
 *   attacker-chosen bytes.
 *
 * `decrypt()` returns `null` rather than throwing on every failure path — wrong salt (the
 * merchant regenerated `wp-config.php` salts, which is a documented WordPress operation),
 * truncated value, tampered value, or `openssl` missing. A null store token is a re-auth
 * prompt (§3.4), which is a recoverable state; an uncaught exception in `admin_init` is a
 * white screen on a merchant's store, which is not.
 *
 * This class is deliberately free of any `get_option`/`update_option` call. It transforms
 * strings. `TokenManager` owns persistence, which keeps the crypto testable under WP_Mock
 * with a single mocked function (`wp_salt`) and keeps the "what is stored where" decision
 * in one place.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat;

/**
 * AES-256-CBC encrypt-then-MAC over a WordPress-salt-derived key, with a fresh IV per write.
 */
final class Encryption {

	/**
	 * The cipher design D-2 names. Not negotiable here: the contract, the architecture
	 * document, and NFR-018 all say AES-256-CBC, and a value encrypted under one cipher
	 * cannot be read back under another after an upgrade.
	 */
	public const CIPHER = 'aes-256-cbc';

	/** Bytes of IV AES-CBC takes. Asserted against `openssl_cipher_iv_length()` at runtime. */
	private const IV_LENGTH = 16;

	/** Bytes of HMAC-SHA256 output prepended as the authentication tag. */
	private const MAC_LENGTH = 32;

	/**
	 * Domain-separation labels for the two derived keys.
	 *
	 * Encryption and authentication must not share key material — reusing one key for both
	 * is the mistake encrypt-then-MAC exists to avoid. Hashing the same salt under two
	 * distinct labels yields two independent keys from one WordPress secret.
	 */
	private const KEY_LABEL_ENCRYPT = 'wai:store-token:enc:v1';
	private const KEY_LABEL_AUTH    = 'wai:store-token:mac:v1';

	/**
	 * Whether the PHP runtime can do this at all.
	 *
	 * `openssl` is effectively universal on WordPress hosts but is not guaranteed, and a
	 * shared host can disable functions. Callers check this to surface "your host cannot
	 * store the token securely" as a plain-language activation error (NFR-011's sibling
	 * case), instead of discovering it as a fatal inside an Action Scheduler job.
	 */
	public static function is_available(): bool {
		return function_exists( 'openssl_encrypt' )
			&& function_exists( 'openssl_decrypt' )
			&& in_array( self::CIPHER, openssl_get_cipher_methods(), true );
	}

	/**
	 * Encrypt a secret for storage in `wp_options`.
	 *
	 * Returns base64 of `mac || iv || ciphertext`. Base64 because `wp_options.option_value`
	 * is a text column and raw AES output is arbitrary bytes: passing those through
	 * `update_option()` risks charset mangling on a `latin1` install, which would corrupt
	 * the token silently. Base64 costs a third more storage and removes that entire class
	 * of bug.
	 *
	 * @param string $plaintext The secret to protect. An empty string is not encrypted —
	 *                          "no token" is represented as the empty option, not as a
	 *                          ciphertext of nothing.
	 * @return string The storable ciphertext, or '' when the input is empty or the runtime
	 *                cannot encrypt.
	 */
	public static function encrypt( string $plaintext ): string {
		if ( '' === $plaintext || ! self::is_available() ) {
			return '';
		}

		$iv_length = openssl_cipher_iv_length( self::CIPHER );
		if ( false === $iv_length || $iv_length <= 0 ) {
			return '';
		}

		// A CSPRNG IV per call. This is the line design D-2 is about: with a constant IV,
		// AES-CBC becomes deterministic and two dumps of the options table reveal whether
		// the token changed. `random_bytes()` throws on an unusable entropy source rather
		// than returning weak bytes, which is the behaviour we want — refusing to store is
		// better than storing something predictably encrypted.
		try {
			$iv = random_bytes( $iv_length );
		} catch ( \Exception $e ) {
			return '';
		}

		$ciphertext = openssl_encrypt( $plaintext, self::CIPHER, self::encryption_key(), OPENSSL_RAW_DATA, $iv );
		if ( false === $ciphertext ) {
			return '';
		}

		// Encrypt-then-MAC over the IV as well as the ciphertext: authenticating the
		// ciphertext alone would leave the IV attacker-controlled, which lets them flip
		// bits in the first plaintext block undetected.
		$mac = hash_hmac( 'sha256', $iv . $ciphertext, self::authentication_key(), true );

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Binary-safe transport into a text column, not obfuscation; see this method's docblock.
		return base64_encode( $mac . $iv . $ciphertext );
	}

	/**
	 * Decrypt a value produced by `encrypt()`.
	 *
	 * Fails closed and quietly: every unhappy path returns `null`, because the only
	 * recoverable response to "we cannot read the stored token" is the same in all of them —
	 * treat the store as unauthenticated and prompt for re-auth (§3.4). Distinguishing
	 * "tampered" from "salts rotated" would tell an attacker with options-write access
	 * whether their forgery had the right shape, and tells the merchant nothing actionable.
	 *
	 * @param string $stored The base64 value read from `wp_options`.
	 * @return string|null The plaintext secret, or null if it cannot be authenticated and
	 *                     decrypted.
	 */
	public static function decrypt( string $stored ): ?string {
		if ( '' === $stored || ! self::is_available() ) {
			return null;
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Reverses this class's own encrypt(); strict mode rejects malformed input.
		$raw = base64_decode( $stored, true );
		if ( false === $raw ) {
			return null;
		}

		$iv_length = openssl_cipher_iv_length( self::CIPHER );
		if ( false === $iv_length || $iv_length <= 0 ) {
			return null;
		}

		// Reject anything too short to contain a MAC, an IV, and at least one AES block
		// before touching it — a length check is not a security boundary but it keeps
		// `substr()` from producing surprising slices of a truncated value.
		if ( strlen( $raw ) <= self::MAC_LENGTH + $iv_length ) {
			return null;
		}

		$mac        = substr( $raw, 0, self::MAC_LENGTH );
		$iv         = substr( $raw, self::MAC_LENGTH, $iv_length );
		$ciphertext = substr( $raw, self::MAC_LENGTH + $iv_length );

		$expected = hash_hmac( 'sha256', $iv . $ciphertext, self::authentication_key(), true );

		// Verify before decrypting, in constant time. `hash_equals()` rather than `===`
		// because a byte-at-a-time comparison leaks, through timing, how much of a forged
		// MAC was correct — which is enough to forge one given enough attempts. Verifying
		// *before* `openssl_decrypt()` is what closes the CBC padding oracle: an attacker
		// never learns whether their modified ciphertext produced valid padding.
		if ( ! hash_equals( $expected, $mac ) ) {
			return null;
		}

		$plaintext = openssl_decrypt( $ciphertext, self::CIPHER, self::encryption_key(), OPENSSL_RAW_DATA, $iv );

		return false === $plaintext ? null : $plaintext;
	}

	/**
	 * The 32-byte AES key, derived from `wp_salt('auth')`.
	 *
	 * `wp_salt()` returns a long random passphrase, not key material of a fixed size.
	 * SHA-256 over it (with a domain-separation label) produces exactly the 256 bits
	 * AES-256 needs without truncating the salt — truncation would silently discard entropy
	 * and make two differently-salted sites collide if their salts shared a prefix.
	 *
	 * Raw binary output (`true`) so the full 256 bits are used; the hex form would be 64
	 * bytes and openssl would silently truncate it back to 32, throwing away half the
	 * derivation for no reason.
	 */
	private static function encryption_key(): string {
		return hash( 'sha256', self::KEY_LABEL_ENCRYPT . self::salt(), true );
	}

	/** The independent HMAC key. Same derivation, different label — see the label constants. */
	private static function authentication_key(): string {
		return hash( 'sha256', self::KEY_LABEL_AUTH . self::salt(), true );
	}

	/**
	 * The WordPress `auth` salt, or an empty string outside WordPress.
	 *
	 * `wp_salt()` is guarded by `function_exists()` so this class can be unit-tested and
	 * so a CLI context that loaded the autoloader without WordPress degrades to a
	 * consistent (if useless) key rather than a fatal. An empty salt is never a security
	 * position we rely on — inside WordPress `wp_salt('auth')` is always populated, since
	 * WordPress generates salts on install and synthesises them when `wp-config.php` omits
	 * them.
	 */
	private static function salt(): string {
		if ( ! function_exists( 'wp_salt' ) ) {
			return '';
		}

		return (string) wp_salt( 'auth' );
	}
}
