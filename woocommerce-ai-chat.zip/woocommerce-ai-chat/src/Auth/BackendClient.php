<?php
/**
 * Backend API client (`add-foundation-onboarding §3.1`).
 *
 * The plugin's only outbound HTTP path: `wp_remote_post` to the SaaS backend with
 * `sslverify: true` (NFR-014). No WooCommerce, no WordPress REST API, no plugins folder
 * — the plugin is a thin client by design (D1), and this class is the seam that
 * enforces the boundary. Every other outbound call in the plugin goes through here.
 *
 * The contract lives in `contracts/openapi.yaml`; the generated `FakeBackend` (Lane B
 * tests drive it) is the contract-shaped stand-in for unit tests, so this class'
 * tests do not call out over the wire — see `FakeBackendTest` for the harness.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Auth;

use WooAIChat\Ops\ApiVersion;

/**
 * The HTTP client that talks to the backend. Singleton-ish: methods are pure
 * transforms around `wp_remote_post` so a test mocks `wp_remote_post` once and the
 * class itself stays free of state.
 */
final class BackendClient implements BackendApi {

	/** The base URL of the SaaS backend. Defaults per ADR-006; overridable in `wp-config.php`. */
	private string $base_url;

	/**
	 * @param string|null $base_url Overrides the resolved URL; tests pass one so they
	 *                              never need the constants defined.
	 */
	public function __construct( ?string $base_url = null ) {
		// `BackendUrl::server()`, not `canonical()`: this is the server→server path, so a
		// deployer who set `WAI_INTERNAL_BACKEND_URL` gets their shortcut. See that class
		// on why the *optional* constant is the internal one and not the public one.
		$this->base_url = $base_url ?? BackendUrl::server();
	}

	/**
	 * Activate a license against the backend.
	 *
	 * @param string $license_key    Raw license key entered by the merchant.
	 * @param string $site_fingerprint The site's pre-generated fingerprint (D16).
	 * @param string $site_url       The store's siteurl.
	 * @param string $plugin_version The plugin version (WAI_VERSION).
	 * @param string $store_token    The store token already held, if any. Sent so the
	 *     backend can authorise a migration rebind: moving a license to a new site
	 *     fingerprint rotates both tokens and repoints the license, so the backend asks
	 *     for proof the caller holds the binding already on file, and the license key is
	 *     not that proof. On a first activation there is nothing to send and the field is
	 *     omitted. Empty rather than nullable so every caller passes something explicit.
	 *
	 * @return array{status: int, body: array<string, mixed>} The parsed response in
	 *     the same shape the FakeBackend produces (`status`, `body`), so callers can
	 *     branch uniformly across the live + fake paths.
	 *
	 * @throws \RuntimeException When the backend URL is not configured.
	 */
	public function activate( string $license_key, string $site_fingerprint, string $site_url, string $plugin_version, string $store_token = '' ): array {
		$this->require_base_url();

		$payload = array(
			'license_key'      => $license_key,
			'site_fingerprint' => $site_fingerprint,
			'site_url'         => $site_url,
			'plugin_version'   => $plugin_version,
		);
		// Omitted rather than sent empty: the contract gives `store_token` `minLength: 1`,
		// so `''` is a 422 on a first activation — the one case where having no token is
		// entirely normal.
		if ( '' !== $store_token ) {
			$payload['store_token'] = $store_token;
		}

		$response = wp_remote_post(
			rtrim( $this->base_url, '/' ) . '/v1/auth/activate',
			array(
				'timeout'   => 15,
				'sslverify' => true,
				'headers'   => array(
					'accept'       => 'application/json',
					'content-type' => 'application/json',
				),
				'body'      => wp_json_encode( $payload ),
			)
		);

		return $this->decode( $response );
	}

	/**
	 * Read subscription state from the backend (`GET /v1/auth/status`).
	 *
	 * @param string $store_token The decrypted store token.
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function subscription_status( string $store_token ): array {
		$this->require_base_url();

		$response = wp_remote_get(
			rtrim( $this->base_url, '/' ) . '/v1/auth/status',
			array(
				'timeout'   => 5,
				'sslverify' => true,
				'headers'   => array(
					'accept'        => 'application/json',
					'authorization' => 'Bearer ' . $store_token,
				),
			)
		);

		return $this->decode( $response );
	}

	/**
	 * Mint a chat session token from a widget token (`POST /v1/auth/session`).
	 *
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function mint_session_token( string $widget_token, string $origin ): array {
		$this->require_base_url();

		$response = wp_remote_post(
			rtrim( $this->base_url, '/' ) . '/v1/auth/session',
			array(
				'timeout'   => 8,
				'sslverify' => true,
				'headers'   => array(
					'accept'       => 'application/json',
					'content-type' => 'application/json',
				),
				'body'      => wp_json_encode(
					array(
						'widget_token' => $widget_token,
						'origin'       => $origin,
					)
				),
			)
		);

		return $this->decode( $response );
	}

	/**
	 * Push collected content items to the Indexing Service
	 * (`add-content-ingestion-kb §1.4`, `POST /v1/index/push`).
	 *
	 * The timeout is larger than the auth calls': the backend chunks and embeds inside
	 * the request, so a 50-item batch legitimately takes longer than a token check. It
	 * still has to stay under a shared host's `max_execution_time`, so 30s is the ceiling
	 * — the caller is an Action Scheduler job that retries, not a page load (NFR-030).
	 *
	 * @param string                           $store_token The decrypted store token.
	 * @param array<int, array<string, mixed>> $items       `PushItem`-shaped rows (≤ 500).
	 *
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function push_index_items( string $store_token, array $items ): array {
		$this->require_base_url();

		$response = wp_remote_post(
			rtrim( $this->base_url, '/' ) . '/v1/index/push',
			array(
				'timeout'   => 30,
				'sslverify' => true,
				'headers'   => array(
					'accept'        => 'application/json',
					'content-type'  => 'application/json',
					'authorization' => 'Bearer ' . $store_token,
				),
				'body'      => wp_json_encode( array( 'items' => $items ) ),
			)
		);

		return $this->decode( $response );
	}

	/**
	 * Delete indexed items (`add-content-ingestion-kb §2.4`, `POST /v1/index/delete`).
	 *
	 * Carries a version stamp so the backend can apply the tombstone under last-writer-wins
	 * (D-3): a delete that arrives out of order behind a newer re-create is ignored.
	 *
	 * @param string                           $store_token The decrypted store token.
	 * @param array<int, array<string, mixed>> $items       `DeleteItem`-shaped rows.
	 *
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function delete_index_items( string $store_token, array $items ): array {
		$this->require_base_url();

		$response = wp_remote_post(
			rtrim( $this->base_url, '/' ) . '/v1/index/delete',
			array(
				'timeout'   => 15,
				'sslverify' => true,
				'headers'   => array(
					'accept'        => 'application/json',
					'content-type'  => 'application/json',
					'authorization' => 'Bearer ' . $store_token,
				),
				'body'      => wp_json_encode( array( 'items' => $items ) ),
			)
		);

		return $this->decode( $response );
	}

	/**
	 * Push the nightly reconciliation manifest
	 * (`add-content-ingestion-kb §2.6`, `POST /v1/index/manifest`).
	 *
	 * The body carries no content — only `[{object_id, content_hash, version}]` — so the
	 * request is small even for a large catalogue (TR-017c). The backend replies with the
	 * ids it wants a full push for, which the caller then feeds back through `push`.
	 *
	 * @param string                           $store_token The decrypted store token.
	 * @param array<int, array<string, mixed>> $items       `ManifestItem`-shaped rows.
	 *
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function push_manifest( string $store_token, array $items ): array {
		$this->require_base_url();

		$response = wp_remote_post(
			rtrim( $this->base_url, '/' ) . '/v1/index/manifest',
			array(
				'timeout'   => 30,
				'sslverify' => true,
				'headers'   => array(
					'accept'        => 'application/json',
					'content-type'  => 'application/json',
					'authorization' => 'Bearer ' . $store_token,
				),
				'body'      => wp_json_encode( array( 'items' => $items ) ),
			)
		);

		return $this->decode( $response );
	}

	/**
	 * Read the dashboard's header state and headline counters
	 * (`add-merchant-insight-ops §1.2`, `GET /v1/merchant/overview`).
	 *
	 * The timeout matches `subscription_status`' rather than the push calls': this runs
	 * while a merchant waits on `/wp-admin`, and NFR-005 gives the whole page 2 seconds.
	 * A backend that has not answered in 5s will not answer inside the budget either, and
	 * the panel's loading/empty states (§1.3) are the honest thing to show instead.
	 *
	 * @param string $store_token The decrypted store token.
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function merchant_overview( string $store_token ): array {
		return $this->merchant_get( '/v1/merchant/overview', $store_token );
	}

	/**
	 * Read conversation analytics, the deflection breakdowns, and the unanswered log
	 * (`add-merchant-insight-ops §2.2–2.4`, `GET /v1/merchant/analytics`).
	 *
	 * @param string $store_token The decrypted store token.
	 * @param int    $window_days Rolling window for the rates; the contract bounds it to
	 *                            1–90 and rejects anything outside, so it is clamped here
	 *                            rather than sent as typed — a merchant-supplied query arg
	 *                            should narrow the window, never 422 the dashboard.
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function merchant_analytics( string $store_token, int $window_days = 30 ): array {
		$window = max( 1, min( 90, $window_days ) );
		return $this->merchant_get( '/v1/merchant/analytics?window_days=' . $window, $store_token );
	}

	/**
	 * Read the indexed-item inventory and the content-quality score
	 * (`add-content-ingestion-kb §5.1–5.2`, `GET /v1/merchant/knowledge`).
	 *
	 * `limit`/`offset` are clamped for the same reason `merchant_analytics()` clamps its
	 * window: both arrive from a merchant-supplied query arg, and the contract 422s outside
	 * its bounds. A paging control that overshoots should land on the last page, not blank
	 * the Knowledge Base with a validation error.
	 *
	 * @param string $store_token The decrypted store token.
	 * @param int    $limit       Page size; the contract bounds it to 1–200.
	 * @param int    $offset      Row offset into the store's inventory.
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function merchant_knowledge( string $store_token, int $limit = 50, int $offset = 0 ): array {
		$page = max( 1, min( 200, $limit ) );
		return $this->merchant_get(
			'/v1/merchant/knowledge?limit=' . $page . '&offset=' . max( 0, $offset ),
			$store_token
		);
	}

	/**
	 * Read the six per-store health checks and indexing-queue progress
	 * (`add-merchant-insight-ops §4.1`, `GET /v1/merchant/health`).
	 *
	 * Same 5s budget as the other merchant reads — this page is also where a merchant
	 * lands *because* something looks wrong, so it must not itself be slow to answer.
	 *
	 * @param string $store_token The decrypted store token.
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function merchant_health( string $store_token ): array {
		return $this->merchant_get( '/v1/merchant/health', $store_token );
	}

	/**
	 * Record the merchant's go-live-below-threshold decision
	 * (`POST /v1/merchant/knowledge/override`, D9/FR-014).
	 *
	 * A POST with no body: the decision *is* the request. The contract declares no request
	 * schema for this operation, so sending `{}` would be inventing one — and the endpoint
	 * derives everything it records from the store token.
	 *
	 * 8s rather than the 5s the merchant reads use. This is a write the merchant is watching
	 * (they have just pressed a button and are waiting to be told their widget is live), and
	 * it does a database write plus a quality recompute over the store's whole inventory
	 * before answering. Still far below the 30s push ceiling — nothing here embeds anything.
	 *
	 * @param string $store_token The decrypted store token.
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function override_quality_gate( string $store_token ): array {
		$this->require_base_url();

		$response = wp_remote_post(
			rtrim( $this->base_url, '/' ) . '/v1/merchant/knowledge/override',
			array(
				'timeout'   => 8,
				'sslverify' => true,
				'headers'   => array(
					'accept'        => 'application/json',
					'authorization' => 'Bearer ' . $store_token,
				),
			)
		);

		return $this->decode( $response );
	}

	/**
	 * The shared `GET /v1/merchant/*` read.
	 *
	 * Every merchant surface is a store-token GET with the same envelope and the same
	 * latency budget, so the shape lives once here — a new panel page adds a one-line
	 * method above rather than another copy of the request options.
	 *
	 * @param string $path        Path with any query string already appended.
	 * @param string $store_token The decrypted store token.
	 * @return array{status: int, body: array<string, mixed>}
	 */
	private function merchant_get( string $path, string $store_token ): array {
		$this->require_base_url();

		$response = wp_remote_get(
			rtrim( $this->base_url, '/' ) . $path,
			array(
				'timeout'   => 5,
				'sslverify' => true,
				'headers'   => array(
					'accept'        => 'application/json',
					'authorization' => 'Bearer ' . $store_token,
				),
			)
		);

		return $this->decode( $response );
	}

	/**
	 * Send a backend erasure request from `uninstall.php`. Best-effort: a 401 or
	 * timeout is acceptable as the metering epic's grace-end schedule will fire later
	 * — we only need to attempt it now (NFR-039).
	 *
	 * @return array{status: int, body: array<string, mixed>}
	 */
	public function request_erasure( string $store_token ): array {
		$this->require_base_url();

		$response = wp_remote_post(
			rtrim( $this->base_url, '/' ) . '/v1/auth/erasure',
			array(
				'timeout'   => 8,
				'sslverify' => true,
				'headers'   => array(
					'accept'        => 'application/json',
					'content-type'  => 'application/json',
					'authorization' => 'Bearer ' . $store_token,
				),
				'body'      => wp_json_encode( array( 'reason' => 'merchant_uninstall' ) ),
			)
		);

		return $this->decode( $response );
	}

	public function get_base_url(): string {
		return $this->base_url;
	}

	private function require_base_url(): void {
		if ( '' === $this->base_url ) {
			throw new \RuntimeException(
				'WAI_BACKEND_URL resolved to an empty value. Since it defaults to the production backend, this means wp-config.php defines it blank — remove that define() to use the default, or set it to the SaaS backend base URL (e.g. "https://api.wcai.example.invalid").'
			);
		}

		// NFR-014's transport rule, now shared with the widget's `apiBase` — see
		// `BackendUrl::is_transport_safe()` for why `sslverify: true` is not this guard.
		// The dev compose stack talks to `http://backend:8000` over the container network,
		// and the loopback carve-out covers it.
		if ( BackendUrl::is_transport_safe( $this->base_url ) ) {
			return;
		}

		throw new \RuntimeException(
			esc_html(
				sprintf(
					/* translators: %s: the URL scheme found in the backend URL, e.g. "http". */
					__( 'The backend URL must use https (got %s). The store token and license key are sent over this connection; http exposes them to anyone on the network path. Only loopback and private-network hosts may use http, for local development.', 'woocommerce-ai-chat' ),
					BackendUrl::scheme_of( $this->base_url )
				)
			)
		);
	}

	/**
	 * Seconds to wait when the backend rate-limits us but names no `Retry-After`.
	 *
	 * The backend always sends the header (`app.ratelimit.http.enforce`), so this is for the
	 * proxy or WAF that returns a bare 429 in front of it. One rate-limit window.
	 */
	private const DEFAULT_RETRY_AFTER = 60;

	/** Never wait longer than this on one caller's say-so. See `retry_after_of()`. */
	private const MAX_RETRY_AFTER = 3600;

	/**
	 * Decode a `wp_remote_*` response into a FakeBackend-shaped result, so every
	 * caller can branch on the same envelope regardless of which lane produced the
	 * answer.
	 *
	 * @param array<string, mixed>|\WP_Error $response
	 * @return array{status: int, body: array<string, mixed>, retry_after?: int}
	 */
	private function decode( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'status' => 0,
				'body'   => array(
					'code'    => 'wp_http_error',
					'message' => $response->get_error_message(),
				),
			);
		}
		$code = is_array( $response ) && isset( $response['response']['code'] )
			? (int) $response['response']['code']
			: 0;
		$body = is_array( $response ) && isset( $response['body'] )
			? json_decode( (string) $response['body'], true )
			: null;
		if ( ! is_array( $body ) ) {
			$body = array(
				'code'    => 'parse_error',
				'message' => 'Backend returned a non-JSON body.',
			);
		}
		$result = array(
			'status' => $code,
			'body'   => $body,
		);

		// Observe the seam version the backend advertises. Recorded here because this is the
		// one funnel every backend call returns through, so skew detection costs no extra
		// request and no scheduled job — it is a side effect of traffic the plugin was
		// making anyway.
		//
		// Deliberately outside the status check above: the header rides on 401s, 429s, and
		// 503s too (`backend/app/main.py`), and those are exactly the responses a merchant is
		// staring at when the real cause is that this plugin is a major version behind.
		ApiVersion::record( self::header_of( $response, ApiVersion::HEADER ) );

		// A 429 is the one status whose *headers* carry information the caller needs. Every
		// other failure is fully described by the status and the body; this one says "come
		// back in N seconds", and a caller that ignores N either gives up too early (losing
		// the content it was pushing) or retries too soon (spending its attempt budget on
		// refusals). Attached only on a 429 so no other branch has to reason about it.
		if ( 429 === $code ) {
			$result['retry_after'] = self::retry_after_of( $response );
		}

		return $result;
	}

	/**
	 * One response header as a string, or '' when absent.
	 *
	 * Extracted from `retry_after_of()`'s first three lines, which did the same thing for
	 * `Retry-After` — a second copy for the version header would be the same WordPress
	 * quirk handled twice. The quirk being: `wp_remote_retrieve_header` returns an ARRAY
	 * when a header appears more than once, and the naive `(string)` cast on that yields
	 * "Array" plus a PHP notice.
	 *
	 * @param array<string, mixed>|\WP_Error $response
	 */
	private static function header_of( $response, string $name ): string {
		if ( ! is_array( $response ) || ! function_exists( 'wp_remote_retrieve_header' ) ) {
			return '';
		}
		$raw = wp_remote_retrieve_header( $response, $name );

		return is_array( $raw ) ? (string) reset( $raw ) : (string) $raw;
	}

	/**
	 * The `Retry-After` delay in seconds, clamped, with a sane default.
	 *
	 * Only the delta-seconds form is read, not the HTTP-date form: the backend emits
	 * seconds, and parsing a date here would mean trusting the merchant's server clock to
	 * agree with ours — a store whose clock is a day fast would compute a negative delay and
	 * retry immediately, which is the opposite of what the header asked for.
	 *
	 * Clamped at both ends. A zero or negative value reads to a client as "retry now", which
	 * is the one instruction a rate-limited caller must not follow; the ceiling stops a
	 * misconfigured proxy from parking a store's content sync for a week.
	 *
	 * @param array<string, mixed> $response
	 */
	private static function retry_after_of( $response ): int {
		$header = self::header_of( $response, 'retry-after' );

		$seconds = is_numeric( trim( $header ) ) ? (int) trim( $header ) : 0;
		if ( $seconds <= 0 ) {
			return self::DEFAULT_RETRY_AFTER;
		}

		return min( self::MAX_RETRY_AFTER, $seconds );
	}
}
