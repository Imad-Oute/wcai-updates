<?php
/**
 * Activation with rebind proof.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Auth;

/**
 * Calls `POST /v1/auth/activate`, supplying the store token already held as proof that
 * this install owns the binding on file.
 *
 * ## Why this is its own class rather than three lines in `OnboardingWizard`
 *
 * The backend refuses to move a license onto a new site fingerprint unless the caller
 * proves it holds the existing binding — a rebind rotates both tokens and repoints the
 * license, so the license key alone is not a good enough credential for it. The proof a
 * legitimately migrated store can offer is the store token it carried across in
 * `wp_options`, so activation has to read the decrypted token and send it.
 *
 * `OnboardingWizard` is where that call used to live, and it is also the class that
 * enqueues the wizard's JavaScript and builds its `wp_localize_script` payload. Reading
 * the decrypted store token into a variable in that file is exactly the adjacency
 * NFR-019 exists to prevent, and `StoreTokenLeakAuditTest` fails the build for it — the
 * audit is a co-occurrence check precisely because "the token is only passed to the
 * *other* call in this file" is not a property a reviewer can verify at a glance.
 *
 * So the token never enters the wizard. It is read here, in a class that has no enqueue
 * path and no reason to grow one, and handed straight to the HTTP client.
 */
final class LicenseActivator {

	private TokenStore $tokens;

	private BackendApi $backend;

	public function __construct( TokenStore $tokens, BackendApi $backend ) {
		$this->tokens  = $tokens;
		$this->backend = $backend;
	}

	/**
	 * Activate, presenting the currently-held store token when there is one.
	 *
	 * On a first activation `get_store_token()` returns `''` and the field is omitted
	 * from the request — the backend treats an activation with no prior binding as a new
	 * store, which needs no proof.
	 *
	 * @param string $license_key      The merchant's key, as typed into the wizard.
	 * @param string $site_fingerprint The D16 activation fingerprint.
	 * @param string $site_url         The store's `siteurl`.
	 * @param string $plugin_version   The activating plugin's version.
	 * @return array{status:int, body:mixed}
	 */
	public function activate( string $license_key, string $site_fingerprint, string $site_url, string $plugin_version ): array {
		return $this->backend->activate(
			$license_key,
			$site_fingerprint,
			$site_url,
			$plugin_version,
			$this->tokens->get_store_token()
		);
	}
}
