<?php
/**
 * Token storage (`add-foundation-onboarding §3.2`).
 *
 * The store token is a bearer secret the plugin holds; it must survive a database
 * exfiltration attempt on the merchant server. Plain `wp_options` storage would expose
 * it. So the store token is encrypted at rest with AES-256-CBC.
 *
 * The cipher itself lives in `WooAIChat\Encryption`, which does AES-256-CBC
 * **encrypt-then-MAC**: a fresh CSPRNG IV per write, and an HMAC-SHA256 over `iv ‖ ct`
 * under a separately-derived key, verified in constant time *before* any decrypt is
 * attempted. Unauthenticated CBC — which this class used to do inline — is malleable:
 * anything with `wp_options` write access can flip plaintext bits by flipping ciphertext
 * bits, and CBC padding failures are a textbook padding oracle. Worse for correctness,
 * a wrong key only *usually* fails padding, so a rotated salt could decrypt to garbage
 * instead of to nothing — returning a wrong token rather than no token.
 *
 * This class keeps the persistence decisions (which option holds what, and the `''`
 * "no token" convention the rest of the plugin is written against) and delegates the
 * crypto. `Encryption` signals failure with `null`; the empty string is this layer's
 * vocabulary, so the two are translated at the boundary below.
 *
 * The widget token is **not** encrypted: it is non-secret by design (it reaches the
 * storefront browser, NFR-018), and encrypting it is security theater that adds an
 * unlock path on the merchant's server for a token that already leaks by being sent
 * to every visitor. Storing it plaintext closes the asymmetry the spec records.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Auth;

use WooAIChat\Encryption;

/**
 * Encrypted persistence of the store token and plaintext persistence of the widget
 * token. The class is the only place in the plugin that touches AES-256-CBC or the
 * `wai_*` token options — keeping the touch-point narrow makes the audit boundary the
 * spec cares about (NFR-018) trivial: phpcs and a grep for `openssl_encrypt` find the
 * entire surface.
 */
final class TokenStorage implements TokenStore {

	/**
	 * Encrypt a store token for storage in `wp_options`.
	 *
	 * @param string $plaintext The raw store token returned by `/v1/auth/activate`.
	 * @return string The value to write to `wp_options`, or '' when the input is empty
	 *                or the runtime cannot encrypt. Never a plaintext fallback: storing
	 *                the token in the clear would violate every property this class
	 *                exists to enforce, and '' is read downstream as "no token stored",
	 *                which forces a re-activation — the safe failure.
	 */
	public function encrypt( string $plaintext ): string {
		return Encryption::encrypt( $plaintext );
	}

	/**
	 * Decrypt a stored store token.
	 *
	 * @param string $stored The stored value from `wp_options`.
	 * @return string The raw token, or '' on any failure — a tampered value, a truncated
	 *                option, a host without openssl, or a rotated `wp_salt('auth')`.
	 *                Callers treat '' as "no token, need re-onboarding".
	 */
	public function decrypt( string $stored ): string {
		return Encryption::decrypt( $stored ) ?? '';
	}

	/**
	 * Persist the store + widget tokens and the store id, all atomically.
	 *
	 * @param string      $store_token  Raw store token (will be encrypted).
	 * @param string      $widget_token Raw widget token (plaintext storage; NFR-018).
	 * @param string      $store_id     The tenant id the backend resolved.
	 * @param string|null $license_key_raw Raw license key (will be hashed; only the
	 *                                     hash is persisted).
	 */
	public function persist( string $store_token, string $widget_token, string $store_id, ?string $license_key_raw = null ): void {
		update_option( WAI_OPTION_STORE_TOKEN, $this->encrypt( $store_token ) );
		update_option( WAI_OPTION_WIDGET_TOKEN, $widget_token );
		update_option( WAI_OPTION_STORE_ID, $store_id );
		if ( null !== $license_key_raw && '' !== $license_key_raw ) {
			update_option( WAI_OPTION_LICENSE_KEY_HASH, hash( 'sha256', $license_key_raw ) );
		}
	}

	/** Read the raw store token back from `wp_options`, decrypting on the way. */
	public function get_store_token(): string {
		$stored = get_option( WAI_OPTION_STORE_TOKEN );
		if ( ! is_string( $stored ) ) {
			return '';
		}
		return $this->decrypt( $stored );
	}

	/** Plaintext widget token from `wp_options`. */
	public function get_widget_token(): string {
		$token = get_option( WAI_OPTION_WIDGET_TOKEN );
		return is_string( $token ) ? $token : '';
	}

	/** The backend-assigned store id, plaintext. */
	public function get_store_id(): string {
		$id = get_option( WAI_OPTION_STORE_ID );
		return is_string( $id ) ? $id : '';
	}

	/**
	 * Whether a complete set of activation material is present locally.
	 *
	 * Deliberately keyed on the two tokens only. `ActivateResponse` returns
	 * `store_token` + `widget_token` and *not* a store id, so requiring a non-empty
	 * store id here would make activation permanently incomplete — the wizard would
	 * bounce a successfully-activated merchant back to step 1 forever. The store id
	 * is backfilled from a later `/v1/auth/status` call and is not activation material.
	 */
	public function has_activation(): bool {
		return $this->get_store_token() !== '' && $this->get_widget_token() !== '';
	}

	/** Clear the token options. Used by the 401 path on a revoked/rotated token. */
	public function clear_store_token(): void {
		delete_option( WAI_OPTION_STORE_TOKEN );
	}
}
