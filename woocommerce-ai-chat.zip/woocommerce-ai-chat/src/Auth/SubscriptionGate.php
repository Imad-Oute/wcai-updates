<?php
/**
 * Subscription gate (`add-foundation-onboarding §5.1–§5.4`).
 *
 * The single source of truth for "is the widget available" — the spec calls this out
 * as **the** gate (FR-047: "Subscription state is the single source of truth for widget
 * availability"). It is cached, refreshed on a daily Action Scheduler job and on
 * activation, and falls back to the last-known state when the backend is briefly
 * unreachable (NFR-037).
 *
 * Three properties the rest of the plugin relies on:
 *
 * - `is_widget_available()` is non-blocking — every call answers immediately from the
 *   cache, transient, or `last-known` row. The refresh is fire-and-forget; nothing in
 *   the call path exceeds the §2s NFR-037 deadline.
 * - 401 from the backend invalidates the local store token (FR-046, D17 rotation) and
 *   flips the gate to "re-auth required". The wizard's next visit re-runs license
 *   activation; the gate remains closed until a fresh `activate` succeeds.
 * - Lapsed / cancelled / past-due / grace all degrade the widget **gracefully**:
 *   the widget hides itself rather than throwing (FR-047) and the admin panel stays
 *   accessible with a renewal prompt (FR-039). That second part is the merchant's
 *   `wp-admin` — never impacted by a subscription change.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Auth;

use WooAIChat\Ops\FailureClass;
use WooAIChat\Ops\OutageProbe;
use WooAIChat\Ops\StatusSurface;

/**
 * Cached subscription state + the gate that reads it.
 *
 * Singleton: holds the last-known state in `wp_options` so a transient eviction does
 * not blank the gate. Installed by `Plugin.php`; read by the wizard before deciding
 * whether to fire a refresh, by the widget queue hook (§FR-005), and by the admin
 * panels via their status-pill rendering (later epics).
 */
final class SubscriptionGate {

	public const STATE_INACTIVE  = 'inactive';
	public const STATE_ACTIVE    = 'active';
	public const STATE_GRACE     = 'grace';
	public const STATE_PAST_DUE  = 'past_due';
	public const STATE_CANCELLED = 'cancelled';

	/** The set of states that allow the widget to serve (FR-047). */
	public const SERVING_STATES = array( self::STATE_ACTIVE, self::STATE_GRACE, self::STATE_PAST_DUE );

	/** Transient cache TTL — 24h (NFR-037). */
	public const CACHE_TTL = DAY_IN_SECONDS;

	/** Never refresh more often than this in-process (NFR-037's 2s cap). */
	public const REFRESH_MIN_INTERVAL = 120;

	private TokenStore $tokens;
	private BackendApi $backend;

	/**
	 * The outage-disambiguation surface (`add-platform-ops-surfaces` §2.4, D15).
	 *
	 * The gate is where the plugin already learns that the backend did not answer, so it is
	 * where the failure streak is kept. Counting reachability anywhere else would give the
	 * merchant-facing surfaces a second, independently-drifting opinion of whether the
	 * platform is up — the contradiction design D-3 rules out.
	 */
	private OutageProbe $status_surface;

	/** In-process refresh throttle — fewer `wp_remote_*` calls in hot loops. */
	private ?float $last_refresh_at = null;

	public function __construct( TokenStore $tokens, ?BackendApi $backend = null, ?OutageProbe $status_surface = null ) {
		$this->tokens         = $tokens;
		$this->backend        = $backend ?? new BackendClient();
		$this->status_surface = $status_surface ?? new StatusSurface();
	}

	/**
	 * The failure class to show the merchant, derived from the status surface rather than
	 * decided here (§2.4, SR-005).
	 *
	 * Returns `FailureClass::none()` unless the FR-038 threshold has been crossed, and
	 * makes no HTTP call in that case — so the Health Check page and the dashboard notice
	 * can both call this freely on render.
	 */
	public function failure_class(): FailureClass {
		// Checked before the status surface, because it is the stronger evidence. Being
		// rate-limited means the backend answered us; the surface can only ever tell us
		// whether the *platform* is healthy, which during a rate limit it is — and that
		// answer resolves to `SITE_LOCAL`, "your host is blocking outbound HTTPS", which is
		// both wrong and expensive for the merchant to act on.
		if ( $this->is_rate_limited() ) {
			return FailureClass::rate_limited();
		}
		return $this->status_surface->classify();
	}

	/**
	 * Whether the backend has recently told this store to slow down.
	 *
	 * Read from the transient rather than an in-process flag: the refresh that saw the 429
	 * and the admin page render that reports it are different PHP requests, so an instance
	 * property would be gone by the time anything asked.
	 */
	public function is_rate_limited(): bool {
		$until = get_transient( WAI_TRANSIENT_RATE_LIMITED );
		return is_numeric( $until ) && (int) $until > $this->now();
	}

	/**
	 * Remember that we are rate-limited until `$seconds` from now.
	 *
	 * The TTL is the window itself, so the record cannot outlive the condition it describes
	 * — a merchant must never be looking at "we are limiting your requests" for a limit that
	 * lapsed an hour ago. The stored value is the deadline as well, because a transient's
	 * expiry is best-effort on hosts with no object cache and the explicit comparison in
	 * `is_rate_limited()` is what actually decides.
	 */
	private function note_rate_limited( int $seconds ): void {
		$seconds = max( 1, $seconds );
		set_transient( WAI_TRANSIENT_RATE_LIMITED, $this->now() + $seconds, $seconds );
	}

	/**
	 * The backend's `Retry-After`, in seconds, defaulting to one rate-limit window.
	 *
	 * `BackendClient` attaches this on a 429 and clamps it; the default here covers a stub
	 * or an intermediary that produced a 429 without one.
	 *
	 * @param array{status:int, body:mixed, retry_after?:int} $result
	 */
	private function retry_after_of( array $result ): int {
		$retry_after = $result['retry_after'] ?? 0;
		return is_numeric( $retry_after ) && (int) $retry_after > 0 ? (int) $retry_after : 60;
	}

	/**
	 * Whether the widget should appear on the storefront (FR-026/FR-047).
	 *
	 * Reads the cached state directly; never blocks. The cache is populated by
	 * `refresh()` or, in the wizard / §5.1 daily job, by the next page load after a
	 * cache miss. A merchant who just installed hits the wizard first, which forces
	 * a refresh — so a real call to `/v1/auth/status` happens once during onboarding,
	 * not once on every page render.
	 */
	public function is_widget_available(): bool {
		$state = $this->cached_state();
		return in_array( $state['status'], self::SERVING_STATES, true );
	}

	/**
	 * Force a refresh of the cached state from the backend.
	 *
	 * Used by the daily Action Scheduler job (`SubscriptionCheckJob`) and by the
	 * wizard after activation. Honour the refresh-throttle when called in-process
	 * to avoid re-fetching on every admin page render.
	 *
	 * @param bool $force Ignore the minimum refresh interval when true. Used by the
	 *                    daily job and the wizard activation handler.
	 * @return array{status: string, checked_at: int|null, subscription: array<string, mixed>|null, fetched_from: string}
	 */
	public function refresh( bool $force = false ): array {
		$now = $this->now();
		if ( ! $force && null !== $this->last_refresh_at && ( $now - $this->last_refresh_at ) < self::REFRESH_MIN_INTERVAL ) {
			return $this->cached_state();
		}
		$this->last_refresh_at = $now;

		$store_token = $this->tokens->get_store_token();
		if ( '' === $store_token ) {
			// No local activation material. The gate is closed and the wizard is the
			// next step; nothing to refresh against.
			return $this->set_state(
				array(
					'status'       => self::STATE_INACTIVE,
					'checked_at'   => $now,
					'subscription' => null,
					'fetched_from' => 'local_no_token',
				)
			);
		}

		$result = $this->backend->subscription_status( $store_token );

		if ( 401 === $result['status'] ) {
			return $this->record_unauthorized( 'backend_401' );
		}

		if ( 429 === $result['status'] ) {
			// Rate-limited. Like the 401 above, this is the backend *answering*, so it must
			// clear the reachability streak rather than feed it.
			//
			// Counting it was actively misleading. Three refusals in a row crossed the
			// FR-038 threshold, `failure_class()` then consulted the status surface, the
			// surface — correctly — reported `operational`, and the merchant was told
			// "this site cannot reach the AI service; ask your hosting provider to allow
			// outbound HTTPS". They would open a ticket with a host who reports nothing is
			// blocked, about a condition that cleared itself inside a minute.
			//
			// The last-known state is served for the same reason a 5xx serves it: the
			// subscription has not changed, we simply were not told about it this minute,
			// and blanking a paying store's widget over a rate limit would be a far worse
			// answer than a slightly stale one (NFR-037).
			$this->status_surface->record_success();
			$this->note_rate_limited( $this->retry_after_of( $result ) );
			return $this->last_known_or_inactive( $now, 'rate_limited' );
		}

		if ( $result['status'] < 200 || $result['status'] >= 300 ) {
			// Backend briefly unreachable (5xx, network, parse error). Fall back to the
			// last-known state up to the grace window; never blank to inactive.
			//
			// This is also the FR-038 counter: three of these in a row is a *suspected*
			// outage, at which point `failure_class()` consults the status surface to
			// decide what the merchant is told (§2.1).
			$this->status_surface->record_failure();
			return $this->last_known_or_inactive( $now, 'last_known' );
		}

		// The backend answered. Clear the streak so a store that recovers stops showing an
		// outage message immediately rather than waiting out the verdict cache.
		$this->status_surface->record_success();

		$body   = is_array( $result['body'] ) ? $result['body'] : array();
		$sub    = is_array( $body['subscription'] ?? null ) ? $body['subscription'] : array();
		$status = is_string( $sub['status'] ?? null ) ? (string) $sub['status'] : self::STATE_INACTIVE;
		return $this->set_state(
			array(
				'status'       => $status,
				'checked_at'   => $now,
				'subscription' => $sub,
				'fetched_from' => 'backend',
			)
		);
	}

	/**
	 * Read the cached state (transient → `wp_options` → defaults). No HTTP.
	 *
	 * @return array{status: string, checked_at: int|null, subscription: array<string, mixed>|null, fetched_from: string}
	 */
	public function cached_state(): array {
		$cached = get_transient( WAI_TRANSIENT_SUBSCRIPTION_STATE );
		if ( is_array( $cached ) && isset( $cached['status'] ) ) {
			return $cached;
		}
		$persisted = get_option( WAI_OPTION_SUBSCRIPTION_CACHE );
		if ( is_array( $persisted ) && isset( $persisted['status'] ) ) {
			set_transient( WAI_TRANSIENT_SUBSCRIPTION_STATE, $persisted, self::CACHE_TTL );
			return $persisted;
		}
		return array(
			'status'       => self::STATE_INACTIVE,
			'checked_at'   => null,
			'subscription' => null,
			'fetched_from' => 'defaults',
		);
	}

	/**
	 * Record that the backend rejected this store's token, from wherever that was learnt.
	 *
	 * `refresh()`'s own 401 branch is one caller; the panel's merchant reads are the other.
	 * A 401 on `GET /v1/merchant/*` is the same fact as a 401 on `/v1/auth/status` — the
	 * store token is dead — and for a while only the gate acted on it. The panel merely
	 * rendered its "no longer authorised" banner, so a store whose tokens had been rotated
	 * kept a live-looking local state: `has_activation()` still true, the cached
	 * subscription still `active`, the header pill still reading **Live** directly above a
	 * banner saying the store was not authorised, and the widget still enqueued against a
	 * token the backend would reject. Two surfaces publishing contradicting diagnoses is
	 * exactly what D-3 rules out, so the invalidation lives here, once, and both callers
	 * funnel through it.
	 *
	 * Clearing the token is also what unsticks the wizard: `has_activation()` goes false,
	 * so the wizard re-offers the license form instead of the "your store is connected"
	 * screen — see `OnboardingWizard::render_page()`, which additionally accepts an
	 * explicit reconnect request so the recovery does not *depend* on this side effect
	 * having already run.
	 *
	 * Idempotent: calling it on an already-invalidated store rewrites the same state.
	 *
	 * @param string $fetched_from Provenance recorded on the cached state, for support.
	 * @return array{status: string, checked_at: int|null, subscription: array<string, mixed>|null, fetched_from: string}
	 */
	public function record_unauthorized( string $fetched_from = 'backend_401' ): array {
		// D17 rotation: the backend has revoked the token. Clear it locally; the wizard
		// re-onboarding path is the recovery, gated from `is_widget_available` returning
		// false.
		//
		// A 401 is the backend *answering*, so it clears the reachability streak. Left
		// counting, a revoked token would accumulate failures and eventually tell the
		// merchant the platform is down — sending them to a status page that says
		// "operational" while their real problem is re-activation.
		$this->status_surface->record_success();
		$this->tokens->clear_store_token();

		return $this->set_state(
			array(
				'status'       => self::STATE_CANCELLED,
				'checked_at'   => $this->now(),
				'subscription' => null,
				'fetched_from' => $fetched_from,
			)
		);
	}

	/**
	 * Whether a re-auth prompt should show — i.e. the gate is closed **and** the local
	 * activation material was once present but is now revoked. Returns false for an
	 * uninitialised store (which should see the wizard, not a re-auth prompt).
	 */
	public function needs_reauth(): bool {
		$state    = $this->cached_state();
		$store_id = $this->tokens->get_store_id();
		$widget   = $this->tokens->get_widget_token();
		$store    = $this->tokens->get_store_token();

		return self::STATE_CANCELLED === $state['status']
			&& '' === $store
			&& ( '' !== $widget || '' !== $store_id );
	}

	/** Reset local state to inactive + last-known-preserved. Used by tests. */
	public function clear(): void {
		delete_transient( WAI_TRANSIENT_SUBSCRIPTION_STATE );
		delete_option( WAI_OPTION_SUBSCRIPTION_CACHE );
	}

	/**
	 * Persist the state through both the transient (for the hot path) and
	 * `wp_options` (for the cold-cache / last-known path).
	 */
	private function set_state( array $state ): array {
		set_transient( WAI_TRANSIENT_SUBSCRIPTION_STATE, $state, self::CACHE_TTL );
		update_option( WAI_OPTION_SUBSCRIPTION_CACHE, $state );
		return $state;
	}

	private function last_known_or_inactive( int $now, string $fetched_from ): array {
		$last_known                 = $this->cached_state();
		$last_known['checked_at']   = $now;
		$last_known['fetched_from'] = $fetched_from;
		// If we never had a known state, mark inactive rather than surfacing a default-
		// "active" that would lie. The merchant's last_activation is the truth that this
		// fallback protects, not "always-on".
		if ( ! isset( $last_known['status'] ) ) {
			$last_known['status'] = self::STATE_INACTIVE;
		}
		$this->set_state( $last_known );
		return $last_known;
	}

	private function now(): int {
		return time();
	}
}
