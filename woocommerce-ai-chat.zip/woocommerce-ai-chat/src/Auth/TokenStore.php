<?php
/**
 * The token-reading seam (`add-foundation-onboarding §3.2`).
 *
 * `TokenStorage` is `final` on purpose: it is the only class that reaches the store
 * token's ciphertext, and keeping it unextendable is what makes the NFR-018 audit
 * boundary a grep rather than a class-hierarchy walk. That decision is worth keeping,
 * but it also means collaborators typed against the concrete class cannot be given a
 * test double — and `SubscriptionGate` has a behaviour that must be asserted directly:
 * a 401 from the backend has to *clear* the stored token (D17, §3.4).
 *
 * So the consumers depend on this interface instead. It names the methods anything outside
 * `Auth\` actually calls, which also documents the surface.
 *
 * That claim used to read "only the four methods … the rest of the plugin reads tokens and
 * clears them, and never writes or encrypts", and it was not true: `OnboardingWizard` is
 * typed against this interface and calls both `has_activation()` and `persist()` — the
 * activation path writes, and encrypts. Neither was declared here, so the calls resolved
 * only because the concrete `TokenStorage` is what gets injected in production. Any other
 * implementation — including a test double written against this interface — is a fatal
 * waiting for the first merchant to open the wizard. Static analysis is what surfaced it.
 *
 * `TokenStorage` remains the sole implementation, and remains final.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Auth;

/**
 * Read access to the persisted activation material.
 */
interface TokenStore {

	/** The decrypted store token, or '' when absent or unreadable. */
	public function get_store_token(): string;

	/** The plaintext widget token, or '' when absent. */
	public function get_widget_token(): string;

	/** The backend-assigned store id, or '' before the first `/v1/auth/status`. */
	public function get_store_id(): string;

	/** Forget the store token — the 401 path on a revoked or rotated token. */
	public function clear_store_token(): void;

	/** Whether a complete set of activation material is present locally. */
	public function has_activation(): bool;

	/**
	 * Write the activation material, encrypting the store token on the way.
	 *
	 * @param string  $store_token     The backend-issued store token, plaintext.
	 * @param string  $widget_token    The public widget token.
	 * @param string  $store_id        Backfilled from `/v1/auth/status`; '' at activation.
	 * @param ?string $license_key_raw Hashed for later comparison when present.
	 */
	public function persist( string $store_token, string $widget_token, string $store_id, ?string $license_key_raw = null ): void;
}
