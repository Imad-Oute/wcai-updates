<?php
/**
 * The backend-call seam (`add-foundation-onboarding §3.1`).
 *
 * `BackendClient` is `final` for the same reason `TokenStorage` is: it is the single
 * place the plugin performs outbound HTTP to the SaaS, so keeping it unextendable makes
 * "what can talk to the backend" a grep rather than a class-hierarchy walk (NFR-014).
 *
 * Collaborators therefore depend on this interface, which names the endpoints they call.
 * That makes `SubscriptionGate`'s failure-path behaviour — 401 clears the token, 5xx
 * falls back to last-known rather than blanking to inactive (NFR-037) — assertable
 * against a stub, without a live HTTP call and without relaxing `final`.
 *
 * Each method returns the same shape `BackendClient` returns:
 * `array{status:int, body:mixed, retry_after?:int}`, where `status` is 0 when the request
 * never reached the backend.
 *
 * `retry_after` is present only on a `429`, carrying the seconds the backend's own
 * `Retry-After` header asked for. Optional rather than always-present because a caller that
 * does not branch on 429 has no use for it, and because the test stubs in `tests/unit`
 * implement this interface without needing to invent a value for every other status.
 *
 * `BackendClient` remains the sole implementation, and remains final.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Auth;

/**
 * The subset of backend endpoints consumed outside `BackendClient` itself.
 */
interface BackendApi {

	/**
	 * `POST /v1/auth/activate` — exchange a license key for the store + widget tokens.
	 *
	 * @param string $license_key      The merchant's key, as typed into the wizard.
	 * @param string $site_fingerprint The D16 activation fingerprint.
	 * @param string $site_url         The store's `siteurl`.
	 * @param string $plugin_version   The activating plugin's version.
	 * @param string $store_token      The store token already held, or `''` on a first
	 *     activation. The backend requires it to authorise a rebind onto a new site
	 *     fingerprint — see `BackendClient::activate()`.
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function activate( string $license_key, string $site_fingerprint, string $site_url, string $plugin_version, string $store_token = '' ): array;

	/**
	 * `GET /v1/auth/status` — the subscription state behind a store token.
	 *
	 * @param string $store_token The decrypted store token.
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function subscription_status( string $store_token ): array;

	/**
	 * `POST /v1/index/push` — idempotent content push.
	 *
	 * @param string                     $store_token The decrypted store token.
	 * @param array<int, array<string, mixed>> $items  The batch to index.
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function push_index_items( string $store_token, array $items ): array;

	/**
	 * `POST /v1/index/delete` — remove vectors for the given items (§2.4).
	 *
	 * @param string                           $store_token The decrypted store token.
	 * @param array<int, array<string, mixed>> $items       `DeleteItem`-shaped rows.
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function delete_index_items( string $store_token, array $items ): array;

	/**
	 * `POST /v1/index/manifest` — nightly manifest-diff reconciliation (§2.6).
	 *
	 * @param string                           $store_token The decrypted store token.
	 * @param array<int, array<string, mixed>> $items       `ManifestItem`-shaped rows.
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function push_manifest( string $store_token, array $items ): array;

	/**
	 * `GET /v1/merchant/overview` — the dashboard header state and headline counters
	 * (`add-merchant-insight-ops §1.2`, §2.1).
	 *
	 * @param string $store_token The decrypted store token.
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function merchant_overview( string $store_token ): array;

	/**
	 * `GET /v1/merchant/analytics` — conversation counts, deflection, unanswered log
	 * (`add-merchant-insight-ops §2.2–2.4`).
	 *
	 * @param string $store_token The decrypted store token.
	 * @param int    $window_days The rolling window the rates are computed over (1–90).
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function merchant_analytics( string $store_token, int $window_days = 30 ): array;

	/**
	 * `GET /v1/merchant/knowledge` — the indexed-item inventory and the content-quality
	 * score with its breakdown and improvement checklist
	 * (`add-content-ingestion-kb §5.1–5.2`, FR-013/014).
	 *
	 * @param string $store_token The decrypted store token.
	 * @param int    $limit       Page size; the contract bounds it to 1–200.
	 * @param int    $offset      Row offset into the store's inventory.
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function merchant_knowledge( string $store_token, int $limit = 50, int $offset = 0 ): array;

	/**
	 * `POST /v1/merchant/knowledge/override` — record the merchant's explicit decision to
	 * go live with a content-quality score below the threshold (D9, FR-014).
	 *
	 * The contract has defined this operation and the backend has implemented it since
	 * `add-content-ingestion-kb`, but nothing in the plugin called it — so a merchant whose
	 * score sat under the bar had no way to reach the decision the gate was waiting for,
	 * and the widget stayed dark with the checklist as the only thing on screen. That is the
	 * gap this method closes.
	 *
	 * Idempotent on the backend (`TenantRepo::mark_quality_gate_overridden` writes once), so
	 * a double-click or a retry cannot lose the original timestamp.
	 *
	 * A 503 here is meaningful and must not be smoothed over: it means no database was
	 * reachable to record the decision. Reporting success for that would tell a merchant
	 * their widget is live while the gate is still shut.
	 *
	 * @param string $store_token The decrypted store token.
	 * @return array{status:int, body:mixed, retry_after?:int} The store's `QualityScore`,
	 *     now carrying `overridden: true` and therefore `passed: true`.
	 */
	public function override_quality_gate( string $store_token ): array;

	/**
	 * `GET /v1/merchant/health` — the six per-store checks and indexing-queue progress
	 * (`add-merchant-insight-ops §4.1`, FR-018, SR-005).
	 *
	 * @param string $store_token The decrypted store token.
	 * @return array{status:int, body:mixed, retry_after?:int}
	 */
	public function merchant_health( string $store_token ): array;

	/** The resolved backend base URL — surfaced in the wizard's diagnostics. */
	public function get_base_url(): string;
}
