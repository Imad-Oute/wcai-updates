<?php
/**
 * Where the backend lives, resolved once for both paths that reach it.
 *
 * Two network paths leave a merchant's WordPress toward the SaaS, and they are not the
 * same path:
 *
 *   - **server→server** — `BackendClient`, running in the merchant's PHP process. Carries
 *     the license key, the store token, and catalogue content.
 *   - **browser→server** — `Widget\Enqueue`'s `apiBase`, running in the *shopper's*
 *     browser. Carries the widget token and every shopper message.
 *
 * `WAI_BACKEND_URL` is the canonical, public base URL and serves **both**.
 * `WAI_INTERNAL_BACKEND_URL` is an optional shortcut for the server path only, for
 * deployments where PHP has a shorter or private route to the same service (a compose
 * network, a VPC peering link, split-horizon DNS).
 *
 * ## Why that direction, and not the other one
 *
 * This pair used to point the other way: `WAI_BACKEND_URL` was the server URL, and an
 * optional `WAI_PUBLIC_BACKEND_URL` overrode it for the browser. That defaulted in the
 * unsafe direction, and the asymmetry is not a matter of taste:
 *
 *   - a **public** URL used from the server always works — the server already requires
 *     public egress to the backend for activation, sync, and every merchant read;
 *   - an **internal** URL used from a browser *never* works. `http://backend:8000` is not
 *     a name a shopper's browser can resolve, by construction.
 *
 * So the value safe to share is the public one, and the shared constant now carries it.
 * The optional constant's failure mode is now the *loud* one: mis-set
 * `WAI_INTERNAL_BACKEND_URL` and the server path breaks, which throws from
 * `require_base_url()`, banners in the panel, and fails Health Check. Mis-set the optional
 * constant under the old direction and the *storefront* broke, silently — dead widget,
 * empty backend logs, six green Health Check rows, no notice anywhere. That cost an
 * afternoon of live debugging (`docs/LOCAL-TESTING-ISSUES-2026-08-01.md` §6.1) and would
 * have reached production for any deployment whose two paths differ.
 *
 * Optional configuration should fail toward the diagnosable path.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Auth;

/**
 * Resolution and classification for the backend's base URL. All static: this holds no
 * state, and both callers want the same answer from the same constants.
 */
final class BackendUrl {

	/**
	 * The canonical, public base URL of the SaaS backend (NFR-011).
	 *
	 * Deployer-defined in `wp-config.php`, with no default — a stale default would point a
	 * mis-configured store at the wrong box, which is worse than refusing. `''` when
	 * undefined *or* defined blank; `Compatibility::backend_url_ok()` turns that into an
	 * explicit admin notice rather than a mystery.
	 */
	public static function canonical(): string {
		return defined( 'WAI_BACKEND_URL' ) ? trim( (string) WAI_BACKEND_URL ) : '';
	}

	/**
	 * The base URL server-side callers should dial.
	 *
	 * The internal shortcut when a deployer set one, the canonical URL otherwise. The
	 * emptiness test is explicit, and deliberately not the `??` the old chain used: `??`
	 * tests for *null*, so a constant defined as `''` won the chain and resolved the base
	 * URL to empty. That exact trap is why a blank `WAI_PUBLIC_BACKEND_URL` used to
	 * silently delete the storefront widget rather than falling through to a working value.
	 */
	public static function server(): string {
		$internal = defined( 'WAI_INTERNAL_BACKEND_URL' ) ? trim( (string) WAI_INTERNAL_BACKEND_URL ) : '';

		return '' !== $internal ? $internal : self::canonical();
	}

	/**
	 * Whether credentials may cross this URL (NFR-014).
	 *
	 * `sslverify: true` on a `wp_remote_*` call governs certificate *validation*, not
	 * whether TLS is used at all — against an `http://` base URL it is simply inert, and
	 * the license key, the store token, the widget token, and every shopper message cross
	 * the wire in the clear. Nothing checked the scheme until this existed, so a one-word
	 * mistake in a merchant's `wp-config.php` silently downgraded the transport with no
	 * error and no visible symptom.
	 *
	 * The loopback/private carve-out is the same one browsers make for secure contexts:
	 * traffic that never leaves the host or a private network is not the exposure this
	 * guard is about. Anything reachable from the public internet is.
	 *
	 * @param string $url A base URL.
	 */
	public static function is_transport_safe( string $url ): bool {
		$scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
		if ( 'https' === $scheme ) {
			return true;
		}

		return 'http' === $scheme && self::is_local_host( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	}

	/** The scheme of a base URL, or `(no scheme)` when it has none — for error messages. */
	public static function scheme_of( string $url ): string {
		$scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );

		return '' === $scheme ? '(no scheme)' : $scheme;
	}

	/**
	 * Whether a host is loopback, private, or container-internal — i.e. not reachable
	 * from the public internet, so plain http is acceptable for local development.
	 *
	 * A dotless name (`backend`, `wcai-backend-1`) is a container or LAN hostname: it
	 * cannot be a public DNS name, which needs at least one dot. The reserved TLDs are
	 * the ones RFC 6761/2606 set aside precisely so they can never resolve publicly.
	 *
	 * @param string $host Host portion of the base URL.
	 */
	public static function is_local_host( string $host ): bool {
		$host = strtolower( trim( $host, '[]' ) );
		if ( '' === $host ) {
			return false;
		}
		if ( 'localhost' === $host || '::1' === $host ) {
			return true;
		}
		if ( false === strpos( $host, '.' ) ) {
			return true;
		}
		foreach ( array( '.localhost', '.local', '.test', '.invalid', '.internal' ) as $suffix ) {
			if ( substr( $host, -strlen( $suffix ) ) === $suffix ) {
				return true;
			}
		}
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			// Public-range validation inverted: a host that is *not* a public IP is a
			// private/loopback/link-local one.
			return ! filter_var(
				$host,
				FILTER_VALIDATE_IP,
				FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
			);
		}
		return false;
	}

	/**
	 * Whether a host is a *container* name — resolvable only inside the deployment's own
	 * network, and therefore never by a shopper's browser.
	 *
	 * Narrower than `is_local_host()`, and the difference is the whole point.
	 * `is_local_host()` answers "is plain http acceptable here", which is true of
	 * `localhost` and of `backend` alike. This answers "can the browser that loaded the
	 * storefront resolve this name", which is true of `localhost` (it means the shopper's
	 * own machine, so it is at least *reachable*) and false of `backend`.
	 *
	 * A dotless name that is neither `localhost` nor an IP literal cannot exist in public
	 * DNS, which requires at least one dot. Putting one in `apiBase` is the §6.1 failure
	 * exactly: the fetch dies at DNS resolution, so the widget shows "Warming up —
	 * reconnecting…" forever and the backend logs stay empty, because no request was ever
	 * made.
	 *
	 * @param string $host Host portion of the base URL.
	 */
	public static function is_container_hostname( string $host ): bool {
		$host = strtolower( trim( $host, '[]' ) );
		if ( '' === $host || 'localhost' === $host ) {
			return false;
		}
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		return false === strpos( $host, '.' );
	}
}
