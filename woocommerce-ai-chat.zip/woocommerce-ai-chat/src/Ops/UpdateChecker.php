<?php
/**
 * Plugin update-checker wiring (`add-platform-ops-surfaces §3.2`, NFR-036, design D-4).
 *
 * The plugin is privately distributed — it is not on wordpress.org, so WordPress core's
 * own update machinery has nothing to poll. `yahnis-elsts/plugin-update-checker`
 * (vendored via composer, `require`, not `require-dev` — it has to ship in the
 * production zip) fills that gap by polling a static JSON manifest and offering the
 * update through the normal `/wp-admin/plugins.php` flow when it names a newer version.
 *
 * That manifest — `updates.<base>/plugin-info.json` — is built and published by
 * `updates/build.sh` / `updates/deploy.sh` from this same repository (§3.1), on static
 * infrastructure separate from the backend VPS. The point, same as `StatusSurface`'s
 * (D15), is that a fix for whatever is broken on the backend still has to be reachable
 * when the backend is what's broken.
 *
 * `$builder` is the seam this class exists to add. `PucFactory::buildUpdateChecker()`
 * needs a live WordPress to do anything useful — its constructor hooks straight into the
 * update-transient machinery — so it cannot be exercised under WP_Mock without stubbing
 * out a third-party library's internals, which is exactly the kind of test that breaks on
 * the library's next release rather than on a real regression here. Defaulting `$builder`
 * to the real factory call and letting a test substitute a recording closure is what makes
 * *our* wiring — which URL, which file, which slug — assertable without any of that.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Ops;

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

/**
 * Resolves the update-checker's configuration and hooks it into WordPress.
 */
final class UpdateChecker {

	private string $manifest_url;
	private string $plugin_file;
	private string $slug;

	/** @var callable(string, string, string): void */
	private $builder;

	/**
	 * All four arguments are optional so production can construct this with no
	 * parameters (reading the hard-defaulted constants, same shape `StatusSurface` uses,
	 * and the real `PucFactory` call) while a test injects its own values and a spy.
	 *
	 * @param callable(string, string, string): void|null $builder See the class docblock.
	 */
	public function __construct(
		?string $manifest_url = null,
		?string $plugin_file = null,
		?string $slug = null,
		?callable $builder = null
	) {
		$this->manifest_url = $manifest_url ?? ( defined( 'WAI_UPDATES_MANIFEST_URL' ) ? WAI_UPDATES_MANIFEST_URL : '' );
		$this->plugin_file  = $plugin_file ?? ( defined( 'WAI_PLUGIN_FILE' ) ? WAI_PLUGIN_FILE : '' );
		$this->slug         = $slug ?? ( defined( 'WAI_SLUG' ) ? WAI_SLUG : '' );
		$this->builder      = $builder ?? static function ( string $url, string $file, string $slug ): void {
			PucFactory::buildUpdateChecker( $url, $file, $slug );
		};
	}

	/** The manifest URL this instance polls. Exposed for tests, not used at runtime. */
	public function manifest_url(): string {
		return $this->manifest_url;
	}

	/** The slug passed to `plugin-update-checker`. Exposed for tests. */
	public function slug(): string {
		return $this->slug;
	}

	/**
	 * Hook `plugin-update-checker` into WordPress's update machinery.
	 *
	 * A no-op when the manifest URL or plugin file is unresolved — the same "degrade,
	 * don't fatal" posture `StatusSurface::fetch()` takes on its own URL. In production
	 * both constants are hard-defaulted in `woocommerce-ai-chat.php`, so this branch is
	 * unreachable there; it exists so an unconfigured instance is inert rather than
	 * erroring, and so a test can assert exactly that.
	 */
	public function register(): void {
		if ( '' === $this->manifest_url || '' === $this->plugin_file ) {
			return;
		}

		( $this->builder )( $this->manifest_url, $this->plugin_file, $this->slug );
	}
}
