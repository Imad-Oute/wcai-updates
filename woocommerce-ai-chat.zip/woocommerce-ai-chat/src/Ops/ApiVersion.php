<?php
/**
 * Plugin ↔ backend seam-version skew detection.
 *
 * The backend returns the contract's `info.version` on every response as
 * `X-WCAI-API-Version` (`backend/app/main.py`). This class is the plugin's half: it records
 * what the backend last reported and compares it against `WAI_CONTRACT_VERSION` — the seam
 * version *this build of the plugin was written against*.
 *
 * ## Why this is not the same question as "is the plugin up to date"
 *
 * `UpdateChecker` already tells a merchant a newer plugin release exists. That is a
 * different fact and a weaker one: plugin releases happen for reasons that have nothing to
 * do with the seam, and a merchant three releases behind may be talking to the backend
 * perfectly well. What breaks a store is the *seam* moving — a field the backend now
 * requires, a response shape this build cannot parse — and nothing before this could
 * observe that at all. The first signal was a merchant reporting that indexing had stopped.
 *
 * ## Why the major version is the only part that raises a notice
 *
 * The contract is versioned semantically. A minor or patch bump is additive by definition —
 * a new optional field, a widened description — and an older plugin keeps working, because
 * both sides ignore fields they do not know about (pydantic's default posture on the
 * backend, and this plugin reads named keys rather than asserting on the whole body). Only
 * a major bump means "something you relied on is gone".
 *
 * Warning on every minor difference would put a permanent notice in wp-admin on a store
 * where nothing is wrong, which trains merchants to dismiss the one that matters.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Ops;

/**
 * Records the backend's advertised seam version and reports whether it has drifted.
 */
final class ApiVersion {

	/**
	 * Where the last-seen backend version is kept.
	 *
	 * An option rather than a transient: this is not a cache of something re-derivable on
	 * demand — it is the last observation, and it must survive a cache flush so a store
	 * whose object cache was cleared does not silently drop the warning.
	 */
	public const OPTION = 'wcai_backend_api_version';

	/** The response header the backend stamps on every response. */
	public const HEADER = 'x-wcai-api-version';

	/** No usable comparison — nothing recorded yet, or an unparseable value. */
	public const SKEW_UNKNOWN = 'unknown';

	/** Same major version. Minor/patch differences land here deliberately. */
	public const SKEW_NONE = 'none';

	/** The backend has moved past this plugin. The merchant must update. */
	public const SKEW_PLUGIN_OLD = 'plugin_old';

	/**
	 * The plugin expects a newer seam than the backend serves — a rolled-back backend, or
	 * a merchant who installed a plugin build before the matching deploy went out.
	 * Reported separately because the resolution is ours, not the merchant's.
	 */
	public const SKEW_BACKEND_OLD = 'backend_old';

	/**
	 * The seam version this build was written against.
	 *
	 * Declared in `woocommerce-ai-chat.php` and asserted equal to the contract's
	 * `info.version` by `contracts/check_plugin_calls.py` in CI — so it cannot drift from
	 * the contract without failing the build, which is the only thing that makes the
	 * comparison below trustworthy.
	 */
	public static function expected(): string {
		return defined( 'WAI_CONTRACT_VERSION' ) ? (string) WAI_CONTRACT_VERSION : '';
	}

	/**
	 * Record the version seen on a backend response.
	 *
	 * Called from `BackendClient::decode()`, which every backend call funnels through, so
	 * this needs no scheduling of its own — the observation is a side effect of ordinary
	 * traffic. Writes only on change: `update_option` on every single API call would be a
	 * database write per request on a store's admin screens for a value that changes about
	 * once a year.
	 *
	 * @param string $seen The raw header value, or '' when the response carried none.
	 */
	public static function record( string $seen ): void {
		$seen = trim( $seen );
		if ( '' === $seen || ! self::is_version( $seen ) ) {
			// A response without the header is not evidence of anything. It is an older
			// backend, or a proxy that stripped it, or an error page from something that is
			// not the backend at all — and clearing the recorded value on those would let a
			// single blip erase a real warning.
			return;
		}
		if ( get_option( self::OPTION ) === $seen ) {
			return;
		}
		update_option( self::OPTION, $seen, false );
	}

	/** The last version the backend advertised, or '' if none has been seen. */
	public static function last_seen(): string {
		$stored = get_option( self::OPTION );

		return is_string( $stored ) ? $stored : '';
	}

	/**
	 * Compare the last-seen backend version against this build's expectation.
	 *
	 * @return string One of the SKEW_* constants.
	 */
	public static function skew(): string {
		$seen     = self::last_seen();
		$expected = self::expected();
		if ( '' === $seen || '' === $expected ) {
			return self::SKEW_UNKNOWN;
		}
		if ( ! self::is_version( $seen ) || ! self::is_version( $expected ) ) {
			return self::SKEW_UNKNOWN;
		}

		$seen_major     = self::major( $seen );
		$expected_major = self::major( $expected );
		if ( $seen_major === $expected_major ) {
			return self::SKEW_NONE;
		}

		return $seen_major > $expected_major ? self::SKEW_PLUGIN_OLD : self::SKEW_BACKEND_OLD;
	}

	/**
	 * A dotted numeric version, loosely — `1`, `1.0`, and `1.0.0` all pass.
	 *
	 * Deliberately not a full semver regex. What this guards against is a proxy or an error
	 * page putting arbitrary text in the header and that text being compared as a version;
	 * rejecting a legitimate pre-release tag would only turn a working comparison into
	 * `SKEW_UNKNOWN`, which is the safe direction either way.
	 */
	private static function is_version( string $value ): bool {
		return 1 === preg_match( '/^\d+(\.\d+)*(?:[-+].*)?$/', $value );
	}

	/** The leading integer of a dotted version. */
	private static function major( string $value ): int {
		$parts = explode( '.', $value );

		return (int) $parts[0];
	}

	/**
	 * Hook the admin notice. Called from `Plugin::boot()`.
	 */
	public function register(): void {
		add_action( 'admin_notices', array( $this, 'maybe_render' ) );
	}

	/**
	 * Warn a merchant only when the seam has genuinely moved under them.
	 *
	 * Silent for `SKEW_NONE` and `SKEW_UNKNOWN`. Silent on a *backend* rollback too, as far
	 * as the merchant is concerned: `SKEW_BACKEND_OLD` means our deploy is behind the plugin
	 * we shipped, which is ours to fix and not something a store owner can act on — telling
	 * them to "update the plugin" there would be advice that cannot work.
	 */
	public function maybe_render(): void {
		if ( self::SKEW_PLUGIN_OLD !== self::skew() ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error wcai-api-version-notice"><p><strong>%1$s</strong></p><p>%2$s</p></div>',
			esc_html__( 'AI Chat: this plugin is out of date', 'woocommerce-ai-chat' ),
			esc_html(
				sprintf(
					/* translators: 1: seam version the AI service speaks, 2: seam version this plugin was built for. */
					__( 'The AI service has moved to version %1$s of its interface and this plugin was built for %2$s. Chat and content sync may stop working until you update the plugin.', 'woocommerce-ai-chat' ),
					self::last_seen(),
					self::expected()
				)
			)
		);
	}
}
