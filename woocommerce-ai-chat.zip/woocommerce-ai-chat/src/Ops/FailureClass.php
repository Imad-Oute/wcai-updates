<?php
/**
 * The merchant-facing failure class (`add-platform-ops-surfaces §2.2–2.4`, SR-005).
 *
 * When the backend is unreachable the plugin cannot locally tell a platform outage from a
 * firewall rule, a DNS failure, or blocked outbound HTTPS on the merchant's host — and
 * those have *opposite* remedies. Telling a merchant to wait when their host is blocking
 * outbound HTTPS costs them the outage plus however long they wait; telling them to check
 * their firewall during a platform outage sends them debugging a system that is fine.
 *
 * So the class is derived from the independent status surface (D15, design D-2), never
 * guessed, and every class carries its own fix. SR-005 forbids the generic-error pattern —
 * "temporarily unavailable, contact support" is exactly the message this type exists to
 * make unrepresentable, which is why `fix()` has no empty case and there is no
 * `UNKNOWN`-with-no-advice variant: the unreachable-surface path resolves to
 * `SITE_LOCAL`, which is both actionable and the more likely truth (see `Ops\StatusSurface`).
 *
 * The strings live here rather than in the admin views so the Health Check page, the
 * dashboard notice, and any later surface render one statement instead of three that drift
 * (design D-3). Rendering belongs to `add-merchant-insight-ops`; this is the source it reads.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Ops;

/**
 * A resolved failure class plus the plain-language fix that goes with it.
 *
 * Immutable value object: built by `StatusSurface::classify()`, read by whatever renders
 * the merchant-facing message.
 */
final class FailureClass {

	/** The platform is down or impaired fleet-wide. The merchant waits; nothing to fix. */
	public const PLATFORM_OUTAGE = 'platform_outage';

	/** The platform is healthy but this store cannot reach it. The merchant has a fix. */
	public const SITE_LOCAL = 'site_local';

	/**
	 * The backend answered, and answered `429`. Not an outage at all — the opposite of one:
	 * a reachable, healthy service declining to do more work for this store right now.
	 *
	 * Its own class rather than a variant of `SITE_LOCAL`, because it was landing there and
	 * the resulting advice was actively wrong. A rate-limited store was told "ask your
	 * hosting provider to allow outbound HTTPS" — a merchant who follows that opens a
	 * support ticket with a host who correctly reports nothing is blocked, while the real
	 * condition clears itself in under a minute. The two classes are also opposites
	 * evidentially: `SITE_LOCAL` is inferred from the backend *not* answering, and this is
	 * proved by it answering.
	 */
	public const RATE_LIMITED = 'rate_limited';

	/** The backend is reachable and serving — no failure to report. */
	public const NONE = 'none';

	private string $failure_class;

	/** Whether the verdict came from the surface or from its unavailability (D-2). */
	private bool $confirmed;

	private function __construct( string $failure_class, bool $confirmed ) {
		$this->failure_class = $failure_class;
		$this->confirmed     = $confirmed;
	}

	public static function platform_outage( bool $confirmed = true ): self {
		return new self( self::PLATFORM_OUTAGE, $confirmed );
	}

	public static function site_local( bool $confirmed = true ): self {
		return new self( self::SITE_LOCAL, $confirmed );
	}

	/**
	 * Always confirmed: this class is only ever built from a `429` we received, never
	 * inferred from an absence. There is no unconfirmed variant to construct.
	 */
	public static function rate_limited(): self {
		return new self( self::RATE_LIMITED, true );
	}

	public static function none(): self {
		return new self( self::NONE, true );
	}

	public function value(): string {
		return $this->failure_class;
	}

	public function is_platform_outage(): bool {
		return self::PLATFORM_OUTAGE === $this->failure_class;
	}

	public function is_site_local(): bool {
		return self::SITE_LOCAL === $this->failure_class;
	}

	public function is_rate_limited(): bool {
		return self::RATE_LIMITED === $this->failure_class;
	}

	public function is_failing(): bool {
		return self::NONE !== $this->failure_class;
	}

	/**
	 * Whether the status surface actually answered. When it did not, the class is a
	 * reasoned default rather than a reading, and the message says so instead of
	 * asserting a cause it cannot know.
	 */
	public function is_confirmed(): bool {
		return $this->confirmed;
	}

	/** The headline: what is wrong. */
	public function headline(): string {
		switch ( $this->failure_class ) {
			case self::PLATFORM_OUTAGE:
				return __( 'The AI service is temporarily down', 'woocommerce-ai-chat' );
			case self::SITE_LOCAL:
				return __( 'This site cannot reach the AI service', 'woocommerce-ai-chat' );
			case self::RATE_LIMITED:
				return __( 'Your store is sending requests faster than we accept them', 'woocommerce-ai-chat' );
			default:
				return __( 'The AI service is reachable', 'woocommerce-ai-chat' );
		}
	}

	/**
	 * The fix: what the merchant should do. Never empty for a failing class — that
	 * emptiness is the generic-error pattern SR-005 rules out.
	 *
	 * The platform-outage text explicitly tells the merchant *not* to reconfigure, because
	 * the natural response to a broken integration is to start changing settings, and doing
	 * that during a platform outage leaves a store misconfigured after recovery.
	 */
	public function fix(): string {
		switch ( $this->failure_class ) {
			case self::PLATFORM_OUTAGE:
				return $this->confirmed
					? __( 'This is an outage on our side, not a problem with your store. No changes are needed — your settings are fine and the chat widget will return on its own once service is restored. Live status: status.microhardtech.com', 'woocommerce-ai-chat' )
					: __( 'Our status page is also unreachable from your site, which usually means a network problem between your host and the internet. Check with your hosting provider before changing any settings here. Live status: status.microhardtech.com', 'woocommerce-ai-chat' );
			case self::SITE_LOCAL:
				return __( 'Our service is running normally, so the problem is between your site and us. Ask your hosting provider to allow outbound HTTPS (port 443) from your server — some shared hosts block it by default. Firewall and security plugins can block it too.', 'woocommerce-ai-chat' );
			case self::RATE_LIMITED:
				return __( 'Nothing is broken and nothing needs changing — your connection to us is working, and we are limiting how fast this store sends requests. Content syncing pauses and resumes on its own, usually within a minute. If you keep seeing this, contact support: it usually means another plugin is re-saving your products in a loop.', 'woocommerce-ai-chat' );
			default:
				return __( 'No action needed.', 'woocommerce-ai-chat' );
		}
	}

	/**
	 * Whether the merchant should change configuration.
	 *
	 * True for exactly one class. During a platform outage "try fixing it" leaves a store
	 * misconfigured after recovery; when rate-limited there is nothing to configure at all,
	 * and the condition clears itself while the merchant is still reading the message.
	 */
	public function advises_reconfiguration(): bool {
		return self::SITE_LOCAL === $this->failure_class;
	}

	/**
	 * The shape the admin surfaces render (`add-merchant-insight-ops`), so the Health
	 * Check page and the dashboard notice cannot word the same state differently.
	 *
	 * @return array{class: string, confirmed: bool, headline: string, fix: string, advises_reconfiguration: bool}
	 */
	public function to_array(): array {
		return array(
			'class'                   => $this->failure_class,
			'confirmed'               => $this->confirmed,
			'headline'                => $this->headline(),
			'fix'                     => $this->fix(),
			'advises_reconfiguration' => $this->advises_reconfiguration(),
		);
	}
}
