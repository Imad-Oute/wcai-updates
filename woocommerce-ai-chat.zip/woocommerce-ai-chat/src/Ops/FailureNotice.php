<?php
/**
 * The merchant-facing backend-unreachable alert (`add-merchant-insight-ops §4.2`, FR-038).
 *
 * FR-038's "the merchant SHALL be alerted after 3 consecutive failures" needed a push
 * surface — nothing before this pulled `SubscriptionGate::failure_class()` anywhere except
 * the Health Check page (§4.1), which a merchant only sees if they already went looking.
 * `admin_notices` is the plugin's existing precedent for a push-style alert
 * (`Compatibility::notice()`, the version-mismatch guard); this follows the same shape.
 *
 * No new reachability tracking lives here. `SubscriptionGate` is the single place a failed
 * backend call is counted (design D-3 — "the contradiction... rules out" a second opinion),
 * so this class only reads `classify()`; it is a renderer, not a prober.
 *
 * Depends on `OutageProbe` rather than `SubscriptionGate` itself — `failure_class()` is a
 * one-line forward to `classify()` on exactly this interface (see `SubscriptionGate`), and
 * `SubscriptionGate` is `final`, so typing against it here would leave this class unable to
 * take a test double the way every other collaborator in the plugin does.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Ops;

/**
 * Renders the `admin_notices` alert when the failure streak is past FR-038's threshold.
 */
final class FailureNotice {

	/**
	 * The Health Check page's `?page=` slug — the canonical copy. `Admin\Panel::HEALTH_CHECK_SLUG`
	 * aliases this rather than declaring its own copy, so the two files cannot drift apart
	 * silently (previously two independent string literals with nothing enforcing agreement).
	 */
	public const HEALTH_CHECK_SLUG = 'wcai-health';

	private OutageProbe $status_surface;

	public function __construct( OutageProbe $status_surface ) {
		$this->status_surface = $status_surface;
	}

	public function register(): void {
		add_action( 'admin_notices', array( $this, 'maybe_render' ) );
	}

	/**
	 * Show the alert on every `wp-admin` screen except Health Check, which already renders
	 * the same verdict as its `connectivity` row (§4.1) — showing it twice on that one page
	 * would read as two different problems instead of one.
	 */
	public function maybe_render(): void {
		if ( $this->on_health_check_page() ) {
			return;
		}

		$failure = $this->status_surface->classify();
		if ( ! $failure->is_failing() ) {
			return;
		}

		printf(
			'<div class="notice notice-error wcai-failure-notice"><p><strong>%1$s</strong></p><p>%2$s</p></div>',
			esc_html( $failure->headline() ),
			esc_html( $failure->fix() )
		);
	}

	/**
	 * phpcs:ignore reasoning: `$_GET['page']` only selects which notice to suppress; it is
	 * read, never written or trusted for anything security-relevant (NFR-019 is about the
	 * AJAX write paths, not this).
	 */
	private function on_health_check_page(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only page-identity check, not a state change.
		$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		return self::HEALTH_CHECK_SLUG === $page;
	}
}
