<?php
/**
 * The outage-classification seam (`add-platform-ops-surfaces §2.4`).
 *
 * `StatusSurface` is `final` for the same reason `TokenStorage` is: it is the one class
 * that decides what a merchant is told during an outage, and keeping it unextendable makes
 * that decision a grep rather than a class-hierarchy walk. But `SubscriptionGate` has to
 * record reachability against it, and its tests assert the gate's *own* option writes —
 * which a real probe would add to.
 *
 * So the gate depends on this interface. It names only what a collaborator calls: record
 * the outcome of a backend call, and ask what class of failure that adds up to.
 *
 * `StatusSurface` remains the sole implementation, and remains final.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Ops;

/**
 * Records backend reachability and classifies the resulting failure.
 */
interface OutageProbe {

	/** Record a failed backend call; true once the FR-038 threshold is crossed. */
	public function record_failure(): bool;

	/** Record a reachable backend, clearing the streak and any cached verdict. */
	public function record_success(): void;

	/** Whether the failure streak has reached the FR-038 threshold. */
	public function outage_suspected(): bool;

	/** The failure class to surface, derived from the status surface (SR-005). */
	public function classify(): FailureClass;
}
