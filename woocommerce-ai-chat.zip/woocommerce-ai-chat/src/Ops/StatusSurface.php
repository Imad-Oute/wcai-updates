<?php
/**
 * The outage-disambiguation ping (`add-platform-ops-surfaces §2.1, §2.5`, D15, design D-2).
 *
 * Reads the independent status surface — `status.<base>/state.json`, hosted off the VPS so
 * it survives the outage it reports (design D-1) — and turns "the backend did not answer"
 * into a specific `FailureClass` with a fix.
 *
 * Three disciplines govern the call, all of them about *not* making it:
 *
 * - **It fires only on a suspected outage.** `record_failure()` counts consecutive
 *   failures; nothing pings until the FR-038 threshold of 3 is crossed. A healthy store
 *   never touches the surface, so the normal cost of this feature is zero requests.
 * - **The verdict is cached.** A fleet-wide outage means every store crosses the threshold
 *   at once; without a TTL that is a fleet-sized thundering herd against the one host that
 *   has to stay up. GitHub Pages would survive it, but the merchant gains nothing from a
 *   second reading 10 seconds after the first.
 * - **Retries are jittered and backed off** (D15), matching `Sync\IngestionScheduler`'s
 *   discipline, so a failed ping does not become a tight loop during degraded conditions.
 *
 * The timeout is deliberately short. This runs while the merchant is already waiting on a
 * failed backend call, and a slow diagnostic is worse than an unconfirmed one — an
 * unreachable surface still yields an actionable class (see `classify()`).
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Ops;

/**
 * Pings the status surface and classifies the failure.
 *
 * Stateless apart from the `wp_options` streak row and the transient verdict cache, so a
 * test constructs it with an injected URL and mocks `wp_remote_get` — the same shape the
 * rest of the plugin's outbound paths are tested in.
 */
final class StatusSurface implements OutageProbe {

	/** Consecutive backend failures before the surface is consulted (FR-038). */
	public const FAILURE_THRESHOLD = 3;

	/**
	 * How long a verdict is trusted. Short enough that a merchant refreshing after a
	 * recovery sees the change quickly; long enough that a fleet-wide outage produces one
	 * ping per store per interval rather than one per page load.
	 */
	public const VERDICT_TTL = 300;

	/** Seconds before giving up. See the class note on why this is short. */
	private const TIMEOUT = 5;

	/** Minimum gap between ping attempts after a failed one, before jitter. */
	private const RETRY_BASE = 60;

	/** Ceiling on the backoff, so a long outage still re-checks every few minutes. */
	private const RETRY_MAX = 600;

	/** The three states the surface publishes (`status-page/build.sh`). */
	private const STATE_OPERATIONAL = 'operational';
	private const STATE_DEGRADED    = 'degraded';
	private const STATE_OUTAGE      = 'outage';

	private string $url;

	public function __construct( ?string $url = null ) {
		$this->url = $url ?? ( defined( 'WAI_STATUS_SURFACE_URL' ) ? WAI_STATUS_SURFACE_URL : '' );
	}

	/**
	 * Record a failed backend call and report whether the outage is now *suspected* —
	 * i.e. whether the FR-038 threshold has been crossed.
	 */
	public function record_failure(): bool {
		$streak = $this->read_streak();
		++$streak['count'];
		$streak['last_failure_at'] = time();
		$this->write_streak( $streak );

		return $streak['count'] >= self::FAILURE_THRESHOLD;
	}

	/**
	 * Record a successful backend call. Resets the streak and drops any cached verdict,
	 * so a store that recovers stops showing an outage message immediately rather than
	 * waiting out the TTL — a stale "we are down" after recovery is the failure mode that
	 * teaches merchants to ignore the notice.
	 */
	public function record_success(): void {
		$streak = $this->read_streak();
		if ( 0 === $streak['count'] ) {
			return; // Nothing to clear; avoid a write on every healthy call.
		}
		$this->write_streak(
			array(
				'count'           => 0,
				'last_failure_at' => 0,
				'next_ping_at'    => 0,
			)
		);
		delete_transient( WAI_TRANSIENT_STATUS_SURFACE );
	}

	/** Whether the failure streak has reached the threshold (FR-038). */
	public function outage_suspected(): bool {
		return $this->read_streak()['count'] >= self::FAILURE_THRESHOLD;
	}

	/**
	 * Resolve the current failure class.
	 *
	 * Returns `NONE` while the backend is healthy — and, critically, without pinging
	 * (§2.1). The surface is consulted only past the threshold.
	 */
	public function classify(): FailureClass {
		if ( ! $this->outage_suspected() ) {
			return FailureClass::none();
		}

		$state = $this->state();

		if ( null === $state ) {
			// The surface did not answer either. Two independent hosts failing at once is
			// far less likely than one site's egress being blocked, so site-local is the
			// better inference — and unlike "unknown" it hands the merchant something to
			// check. `confirmed: false` keeps the message honest about which it is.
			return FailureClass::site_local( false );
		}

		switch ( $state ) {
			case self::STATE_OUTAGE:
			case self::STATE_DEGRADED:
				// Degraded counts as platform-side: the backend is impaired on our end, so
				// the merchant reconfiguring their host would be chasing the wrong system.
				return FailureClass::platform_outage();
			case self::STATE_OPERATIONAL:
				// The platform is fine but this store cannot reach it — the site-local
				// class, and the one case where there is a configuration fix to give.
				return FailureClass::site_local();
			default:
				// An unrecognised state means the surface published something this plugin
				// version predates. Treat it as platform-side but unconfirmed: a newer
				// state is far more likely to be a platform condition than a claim this
				// store's egress is broken.
				return FailureClass::platform_outage( false );
		}
	}

	/**
	 * The surface's current state string, or null if it could not be read.
	 *
	 * Cached for `VERDICT_TTL`; a failed read schedules the next attempt with jittered
	 * backoff rather than retrying on the next call (D15).
	 */
	public function state(): ?string {
		$cached = get_transient( WAI_TRANSIENT_STATUS_SURFACE );
		if ( is_string( $cached ) && self::is_known_state( $cached ) ) {
			return $cached;
		}

		if ( ! $this->may_ping() ) {
			return null;
		}

		$state = $this->fetch();

		if ( null === $state ) {
			$this->back_off();
			return null;
		}

		set_transient( WAI_TRANSIENT_STATUS_SURFACE, $state, self::VERDICT_TTL );
		$this->clear_backoff();

		return $state;
	}

	/**
	 * Fetch and parse `state.json`.
	 *
	 * `sslverify` stays on (NFR-014) — the surface is the input to a security-relevant
	 * decision, and an unverified read of it could be spoofed into telling every merchant
	 * on a hostile network that their own site is at fault.
	 */
	private function fetch(): ?string {
		if ( '' === $this->url ) {
			return null;
		}

		$response = wp_remote_get(
			$this->url,
			array(
				'timeout'   => self::TIMEOUT,
				'sslverify' => true,
				'headers'   => array( 'accept' => 'application/json' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return null;
		}

		$code = is_array( $response ) && isset( $response['response']['code'] )
			? (int) $response['response']['code']
			: 0;
		if ( 200 !== $code ) {
			return null;
		}

		$body = is_array( $response ) && isset( $response['body'] )
			? json_decode( (string) $response['body'], true )
			: null;
		if ( ! is_array( $body ) || ! isset( $body['state'] ) || ! is_string( $body['state'] ) ) {
			return null;
		}

		return $body['state'];
	}

	/**
	 * Whether `$state` is one of the three states the surface publishes.
	 *
	 * `fetch()` itself does not use this — an unrecognised state there still flows into
	 * `classify()`'s `default` branch, which is the deliberately forward-compatible path for
	 * a status page published by a newer plugin version. This guard exists only for the
	 * transient cache read in `state()`, so a value some other code wrote into that transient
	 * (accidentally, or by a stale plugin version) cannot be replayed as if it were a state
	 * this class fetched and validated itself.
	 */
	private static function is_known_state( string $state ): bool {
		return in_array(
			$state,
			array( self::STATE_OPERATIONAL, self::STATE_DEGRADED, self::STATE_OUTAGE ),
			true
		);
	}

	/** Whether the backoff window has elapsed. */
	private function may_ping(): bool {
		$next = $this->read_streak()['next_ping_at'];
		return 0 === $next || time() >= $next;
	}

	/**
	 * Push the next attempt out with jittered exponential backoff (D15).
	 *
	 * The jitter matters more than the backoff here: a fleet-wide outage synchronises
	 * every store's failure streak, so without a random spread they would retry in lockstep.
	 */
	private function back_off(): void {
		$streak = $this->read_streak();
		$misses = max( 1, $streak['count'] - self::FAILURE_THRESHOLD + 1 );
		$delay  = min( self::RETRY_MAX, self::RETRY_BASE * ( 2 ** ( $misses - 1 ) ) );
		$delay += function_exists( 'wp_rand' ) ? (int) wp_rand( 0, 30 ) : 0;

		$streak['next_ping_at'] = time() + $delay;
		$this->write_streak( $streak );
	}

	private function clear_backoff(): void {
		$streak = $this->read_streak();
		if ( 0 === $streak['next_ping_at'] ) {
			return;
		}
		$streak['next_ping_at'] = 0;
		$this->write_streak( $streak );
	}

	/**
	 * @return array{count: int, last_failure_at: int, next_ping_at: int}
	 */
	private function read_streak(): array {
		$raw = get_option( WAI_OPTION_FAILURE_STREAK, array() );
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		return array(
			'count'           => isset( $raw['count'] ) ? (int) $raw['count'] : 0,
			'last_failure_at' => isset( $raw['last_failure_at'] ) ? (int) $raw['last_failure_at'] : 0,
			'next_ping_at'    => isset( $raw['next_ping_at'] ) ? (int) $raw['next_ping_at'] : 0,
		);
	}

	/**
	 * @param array{count: int, last_failure_at: int, next_ping_at: int} $streak
	 */
	private function write_streak( array $streak ): void {
		update_option( WAI_OPTION_FAILURE_STREAK, $streak, false );
	}
}
