<?php
/**
 * Compatibility guards (`add-foundation-onboarding §1.3`).
 *
 * The plugin runs on WordPress 6.3+, WooCommerce 8.0+ with HPOS enabled, PHP 8.0+.
 * Anything older is refused with a blocking admin notice (NFR-007/008) — the failure
 * mode the spec calls out is a plugin that activates on an unsupported environment and
 * then breaks the admin on the next page load; refusing at activation is the safe
 * version of the same gate.
 *
 * HPOS compatibility is declared on `before_woocommerce_init` (TR-019): declaring it
 * does **not** turn HPOS on (that is the merchant's choice in `WC → Settings →
 * Advanced → Features`) but it does tell WooCommerce "I am safe to load when HPOS is
 * active". Without it, WooCommerce 8+ raises a deprecation warning and refuses to
 * create orders from the plugin's hooks.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat;

use WooAIChat\Auth\BackendUrl;
use WooAIChat\Widget\Enqueue;

final class Compatibility {
	/** Minimum WordPress version the plugin supports (NFR-006). */
	public const MIN_WP = '6.3';

	/** Minimum WooCommerce version (NFR-007). */
	public const MIN_WC = '8.0';

	/** Minimum PHP version (NFR-008). */
	public const MIN_PHP = '8.0';

	/**
	 * Run all three version guards and surface a blocking notice per failed guard.
	 * Called from the activation hook and again from the plugin bootstrap.
	 *
	 * The notice is plain-language ("this plugin needs WooCommerce 8.0 or later; you
	 * have X.Y") rather than a fatal — a merchant who activates the plugin on their
	 * store is not also a developer reading a stack trace, and deactivating-by-hand
	 * is a real follow-up they can do.
	 */
	public static function check_and_notice(): void {
		if ( ! self::php_ok() ) {
			self::notice(
				sprintf(
					/* translators: 1: required PHP version, 2: current PHP version. */
					__(
						'Upsellix needs PHP %1$s or later (you have %2$s). Upgrade PHP before activating the plugin.',
						'woocommerce-ai-chat'
					),
					self::MIN_PHP,
					PHP_VERSION
				)
			);
		}

		if ( ! self::wp_ok() ) {
			global $wp_version;
			self::notice(
				sprintf(
					/* translators: 1: required WP version, 2: current WP version. */
					__(
						'Upsellix needs WordPress %1$s or later (you have %2$s).',
						'woocommerce-ai-chat'
					),
					self::MIN_WP,
					$wp_version ?? 'unknown'
				)
			);
		}

		if ( ! self::wc_ok() ) {
			$wc_version = defined( 'WC_VERSION' ) ? WC_VERSION : 'unknown';
			self::notice(
				sprintf(
					/* translators: 1: required WC version, 2: current WC version (or "missing"). */
					__(
						'Upsellix needs WooCommerce %1$s or later (you have %2$s). Install or upgrade WooCommerce first.',
						'woocommerce-ai-chat'
					),
					self::MIN_WC,
					$wc_version
				)
			);
		}

		if ( ! self::backend_url_ok() ) {
			// Reachable only when a deployment has explicitly defined `WAI_BACKEND_URL`
			// blank — since ADR-006 an *absent* constant falls back to the shipped default,
			// so "the merchant never added the line" is no longer a way to get here. The
			// copy says "remove or correct" rather than "add", because the line already
			// exists and telling someone to add what is in front of them reads as a bug.
			self::notice(
				sprintf(
					/* translators: %s: the wp-config.php line to remove or correct. */
					__(
						'Upsellix\'s backend URL is defined but empty, so it cannot reach the AI service. Remove the line below from your wp-config.php to use the default, or set it to your backend\'s public https address: %s',
						'woocommerce-ai-chat'
					),
					"define( 'WAI_BACKEND_URL', '' );"
				)
			);
		} elseif ( ! self::storefront_url_ok() ) {
			// `elseif`: a store with no URL at all has already been told, and two notices
			// about the same missing line read as two problems.
			//
			// This one is about a URL that is defined and *wrong for the browser*, which
			// used to have no surface anywhere. `WAI_BACKEND_URL` feeds both the server
			// path and the storefront widget's `apiBase`, and only the server path
			// validated it — so an internal hostname or a plain-http address left the
			// storefront chat silently dead while every admin surface stayed green.
			self::notice(
				sprintf(
					/* translators: %s: the value currently in WAI_BACKEND_URL. */
					__(
						'Upsellix\'s backend URL (%s) is not one a shopper\'s browser can use, so the storefront chat widget will not load. WAI_BACKEND_URL must be the public https address of the AI service. If this server reaches it by a shorter private route, put that in WAI_INTERNAL_BACKEND_URL and leave WAI_BACKEND_URL public.',
						'woocommerce-ai-chat'
					),
					BackendUrl::canonical()
				)
			);
		}
	}

	/**
	 * Whether the backend base URL resolves to anything usable (NFR-011).
	 *
	 * Since ADR-006 `WAI_BACKEND_URL` has a default, so this no longer fires for a merchant
	 * who simply never edited `wp-config.php` — that path now resolves to
	 * `WAI_DEFAULT_BACKEND_URL` and activates. What still reaches here is a deployment that
	 * defined the constant *blank*, which `canonical()` deliberately does not treat as
	 * "unset": a blank value is a statement, and silently overruling it with the default
	 * would be the same class of bug as the `??` trap on `BackendUrl::server()`.
	 *
	 * The guard stays for the reason it was written. Before it existed, an unusable value
	 * surfaced as a `RuntimeException` thrown deep inside `BackendClient`, on a request the
	 * merchant never saw, and the plugin simply appeared to do nothing. This turns that into
	 * the same blocking notice the version guards use.
	 */
	public static function backend_url_ok(): bool {
		return '' !== BackendUrl::canonical();
	}

	/**
	 * Whether the canonical URL is one a *shopper's browser* can actually use.
	 *
	 * Separate from `backend_url_ok()` because the two answer different questions and
	 * carry different consequences. That one asks "can this store talk to the backend at
	 * all", and its failure is loud — activation refuses. This asks "can the storefront
	 * widget talk to the backend", and its failure was, until this existed, completely
	 * silent: `Enqueue` skips the bundle, no request is made, the backend logs nothing, and
	 * the six backend-reported Health Check rows all come back green.
	 *
	 * Deliberately delegated to `Widget\Enqueue::api_base_usable()` — the same predicate
	 * that decides whether the widget ships — so this notice cannot promise a working
	 * storefront the enqueue path then refuses to provide.
	 */
	public static function storefront_url_ok(): bool {
		return Enqueue::api_base_usable( BackendUrl::canonical() );
	}

	/** PHP version guard. */
	public static function php_ok(): bool {
		return version_compare( PHP_VERSION, self::MIN_PHP, '>=' );
	}

	/** WordPress version guard. */
	public static function wp_ok(): bool {
		global $wp_version;
		return null !== $wp_version && version_compare( $wp_version, self::MIN_WP, '>=' );
	}

	/** WooCommerce version guard. Returns false if WooCommerce is not loaded at all. */
	public static function wc_ok(): bool {
		return defined( 'WC_VERSION' ) && version_compare( WC_VERSION, self::MIN_WC, '>=' );
	}

	/**
	 * Declare HPOS compatibility on `before_woocommerce_init` (TR-019, NFR-007).
	 *
	 * Hooked by `Plugin::instance()`. Stays a static method so the hook registration
	 * in `Plugin` is one readable line — the alternative (registering the closure in
	 * `Plugin`) hides the wiring from someone reading the class looking for "where's
	 * HPOS declared".
	 */
	public static function declare_hpos_compatibility(): void {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WAI_PLUGIN_FILE );
		}
		// If the class is missing (the user is on a WC below the FeaturesUtil), the
		// version guard above already refused the activation, so this branch is
		// unreachable in practice — kept as the soft fail rather than crashing on a
		// plugin that handles activation conditionally and gets called on load.
	}

	/**
	 * Check whether outbound HTTPS to the backend is permitted (NFR-011).
	 *
	 * A store behind a firewall that blocks outbound HTTPS will get a failed activation
	 * with a generic TLS error otherwise — the notice we surface is the
	 * plain-language version the spec asks for, naming the host and the firewall fix.
	 *
	 * Returns `array{ok: bool, host: string, error: string|null}` rather than a bool
	 * so the caller can show the **specific** reason in the activation page (the
	 * alternative — `false` plus a generic "couldn't reach backend" — leaves the
	 * merchant guessing whether to fix their firewall, the backend URL define, or
	 * their hosting provider).
	 *
	 * @return array{ok: bool, host: string, error: string|null}
	 */
	public static function check_outbound_https( string $backend_url ): array {
		$host = (string) wp_parse_url( $backend_url, PHP_URL_HOST );
		if ( '' === $host ) {
			return array(
				'ok'    => false,
				'host'  => '',
				'error' => __( 'Backend URL is not set or is malformed.', 'woocommerce-ai-chat' ),
			);
		}

		$response = wp_remote_head(
			$backend_url,
			array(
				'timeout'   => 5,
				'sslverify' => true,
				'headers'   => array( 'accept' => 'application/json' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return array(
				'ok'    => false,
				'host'  => $host,
				'error' => $response->get_error_message(),
			);
		}
		// The pinger answers 200; anything else is at least reachable, which is the
		// property NFR-011 names — a "backend says no" is for the onboarding flow
		// to handle, not the activation guard.
		return array(
			'ok'    => true,
			'host'  => $host,
			'error' => null,
		);
	}

	/**
	 * Surface a blocking admin notice. Used by all three version guards.
	 *
	 * Hooked on `admin_notices` so the merchant sees the version mismatch on their
	 * dashboard. The error class is `notice-error` (red), so the merchant knows the
	 * plugin is not running — at this point activation has already been refused, so
	 * the worst a glanced-over notice does is repeat what the activation page said.
	 */
	private static function notice( string $message ): void {
		add_action(
			'admin_notices',
			static function () use ( $message ): void {
				echo '<div class="notice notice-error"><p>' . esc_html( $message ) . '</p></div>';
			}
		);
	}
}
