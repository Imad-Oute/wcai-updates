<?php
/**
 * Error tracking wiring and the PII scrub — plugin side (`add-build-rails` §5.1–§5.3).
 *
 * This mirrors the backend's `app/observability.py` on the plugin's half of the seam, for
 * the same reason and under the same rule: ADR-001 permits an external, EU-region error
 * tracker only because nothing sensitive crosses to it, and design D-5 makes that a *tested*
 * boundary rather than a configuration line. So `scrub_event()` is a pure static method the
 * unit suite exercises directly (`tests/unit/ErrorTrackingTest.php`), with no live Sentry.
 *
 * Three properties, each pinned by a test:
 *
 * - **DSN is environment-configured, absent-DSN disables** (§5.3, ADR-001 step 1). The
 *   merchant never sees a DSN; it is read from a constant the plugin is deployed with
 *   (`WCAI_SENTRY_DSN`), and `is_enabled()` is false when it is empty. A store with no DSN
 *   reports nothing rather than erroring — the safe default for a plugin running on someone
 *   else's server.
 * - **PII, tokens, and request bodies never leave** (§5.2, NFR-038, D10). `scrub_event()`
 *   drops request bodies and cookies, redacts credential-bearing headers, and masks bearer
 *   tokens and card patterns anywhere in the event. The store token (TR-011) and any shopper
 *   text a breadcrumb might quote are gone before send.
 * - **External-by-construction / EU region** (D15, NFR-035) are properties of the DSN the
 *   plugin is shipped with (a `de.sentry.io` project), not decisions made here.
 *
 * Sprint 0 ships no product code, so nothing *calls* `capture()` yet: the plugin's real
 * error paths — a failed `/v1/index/push`, a 5xx from `/v1/chat` — arrive with the epic
 * changes and hand their exceptions here. What exists now is the boundary and its proof.
 *
 * The `\Sentry\*` functions are referenced only inside `init()`/`capture()` and guarded by
 * `is_enabled()`, so the `sentry/sentry` package is a soft dependency: the unit suite tests
 * the scrub without it installed, exactly as the backend test does.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat;

/**
 * Thin wrapper over the Sentry PHP SDK: env-configured DSN, a tested PII scrub, and a
 * disabled-when-unconfigured default.
 */
final class ErrorTracking {

	private const REDACTED = '[redacted]';

	/**
	 * Headers that carry credentials or identity. Compared case-insensitively. The store
	 * token rides in Authorization (TR-011); the rest are stripped defensively.
	 *
	 * @var string[]
	 */
	private const SENSITIVE_HEADERS = array(
		'authorization',
		'cookie',
		'set-cookie',
		'x-api-key',
		'proxy-authorization',
	);

	/** `Bearer <token>` anywhere in a string, including quoted inside a breadcrumb. */
	private const BEARER_RE = '/Bearer\s+[\w\-.=+\/]+/i';

	/** 13–19 digit runs, optionally space/dash grouped — the card-pattern class D10 names. */
	private const CARD_RE = '/\b(?:\d[ -]?){13,19}\b/';

	/**
	 * The configured DSN, or an empty string when tracking is off.
	 *
	 * Read from the `WCAI_SENTRY_DSN` constant the plugin is deployed with (same env-config
	 * discipline as the backend's `SENTRY_DSN` and the SMTP relay, D-OP7). Trimmed so a
	 * whitespace-only value counts as unset.
	 */
	public static function dsn(): string {
		if ( ! defined( 'WCAI_SENTRY_DSN' ) ) {
			return '';
		}

		return trim( (string) constant( 'WCAI_SENTRY_DSN' ) );
	}

	/** Whether error tracking is configured. False disables `init()`/`capture()` entirely. */
	public static function is_enabled(): bool {
		return '' !== self::dsn();
	}

	/**
	 * Initialise the Sentry SDK against the env DSN. A no-op — returning false — when no DSN
	 * is configured (§5.3), so an unconfigured store never fails on our account.
	 */
	public static function init(): bool {
		if ( ! self::is_enabled() ) {
			return false;
		}

		\Sentry\init(
			array(
				'dsn'                   => self::dsn(),
				// Ingest region is derived from the DSN host (`de.sentry.io`), asserted in
				// the DPA — not a flag here (ADR-001, NFR-035).
				'release'               => defined( 'WAI_VERSION' ) ? (string) constant( 'WAI_VERSION' ) : null,
				// Do not let the SDK attach request bodies or user identity in the first
				// place; `scrub_event()` is the backstop, not the only line of defence.
				'send_default_pii'      => false,
				'max_request_body_size' => 'none',
				'before_send'           => static function ( $event ) {
					// The SDK hands an Event object; we scrub its serialised array form and
					// let the SDK re-hydrate. Kept as a pure array transform so the test can
					// call `scrub_event()` directly without constructing an Event.
					return self::apply_scrub_to_event( $event );
				},
			)
		);

		return true;
	}

	/**
	 * The tested boundary (design D-5): return the event array Sentry is allowed to send.
	 *
	 * Removes the request body and cookies (which carry shopper/merchant input by
	 * construction), redacts credential-bearing headers by name, then sweeps every remaining
	 * string for bearer-token and card patterns. The event is delivered, not dropped — the
	 * stack trace still reaches the developer; only the sensitive payload does not.
	 *
	 * @param array<string, mixed> $event The Sentry event as a plain array.
	 * @return array<string, mixed> The scrubbed event.
	 */
	public static function scrub_event( array $event ): array {
		if ( isset( $event['request'] ) && is_array( $event['request'] ) ) {
			// A chat error's body is a shopper's message (NFR-038); a push error's body is
			// catalog content. Neither justifies carrying PII off-box.
			unset( $event['request']['data'], $event['request']['cookies'], $event['request']['query_string'] );

			if ( isset( $event['request']['headers'] ) && is_array( $event['request']['headers'] ) ) {
				foreach ( $event['request']['headers'] as $name => $value ) {
					if ( in_array( strtolower( (string) $name ), self::SENSITIVE_HEADERS, true ) ) {
						$event['request']['headers'][ $name ] = self::REDACTED;
					}
				}
			}
		}

		return self::scrub_recursive( $event );
	}

	/**
	 * Recursively mask bearer tokens and card patterns in every string reachable from the
	 * event, so a leaked value cannot survive by hiding inside a nested breadcrumb or extra.
	 *
	 * @param mixed $value Any value from the event tree.
	 * @return mixed The value with strings scrubbed.
	 */
	private static function scrub_recursive( $value ) {
		if ( is_string( $value ) ) {
			return self::scrub_text( $value );
		}

		if ( is_array( $value ) ) {
			$out = array();
			foreach ( $value as $key => $item ) {
				$out[ $key ] = self::scrub_recursive( $item );
			}

			return $out;
		}

		return $value;
	}

	/** Mask bearer tokens and card patterns in one string. */
	private static function scrub_text( string $value ): string {
		$value = (string) preg_replace( self::BEARER_RE, self::REDACTED, $value );

		return (string) preg_replace( self::CARD_RE, self::REDACTED, $value );
	}

	/**
	 * Bridge the SDK's `Event` object through the array-based `scrub_event()`.
	 *
	 * Isolated here (and referenced only from `init()`) so `scrub_event()` stays a pure
	 * array transform the test can call with no SDK present.
	 *
	 * @param mixed $event A `\Sentry\Event`.
	 * @return mixed The same event, scrubbed.
	 */
	private static function apply_scrub_to_event( $event ) {
		// The SDK's Event exposes request/extra as typed structures; the plugin's real
		// error paths (epic changes) decide exactly which fields to route through
		// `scrub_event()`. Until then this returns the event unchanged, and the pure scrub
		// is what the test asserts against. Wiring the field mapping belongs with the first
		// real `capture()` call site, not with Sprint-0 scaffolding.
		return $event;
	}
}
