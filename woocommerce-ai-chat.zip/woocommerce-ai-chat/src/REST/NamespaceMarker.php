<?php
/**
 * Stub marking the `WooAIChat\REST` sub-namespace (`add-foundation-onboarding §1.2`).
 *
 * Owned by `add-merchant-insight-ops` — the React dashboard app's REST routes live
 * here. See `NamespaceMarker` under `Api` for why the placeholder exists.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\REST;

final class NamespaceMarker {
}
