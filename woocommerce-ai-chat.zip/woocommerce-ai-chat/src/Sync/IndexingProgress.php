<?php
/**
 * The re-index progress record the Knowledge Base page reports from (§5.5, FR-016).
 *
 * ## Why this is local
 *
 * The contract puts an `IndexingProgress` block on `MerchantHealthResponse`, and the
 * backend answers it `idle/0/0` — honestly, because it has no queue of its own to relay.
 * The queue that actually exists is the *plugin's*: `IngestionScheduler` walks products,
 * then categories, then pages, one Action Scheduler job per page of 50, and it is the only
 * component that knows how far that walk has got.
 *
 * So progress is recorded here, next to the walk, rather than asked of a backend that
 * cannot answer. When the backend grows a real job queue this becomes the fallback rather
 * than the source — the shape (`state`/`processed`/`total`) is deliberately the contract's,
 * so `KnowledgePage::progress()` can prefer whichever is authoritative without the page
 * learning a second vocabulary.
 *
 * ## What it is not
 *
 * Not a count of what the *backend* has indexed. It counts what this site has pushed, which
 * is the honest thing to report while a job is running and the only thing knowable without
 * a round trip per batch. The Knowledge Base table remains the record of what actually
 * landed — the bar says "we are 60% through sending your catalogue", not "60% of it is
 * searchable", and the merchant-facing copy in `KnowledgePage` says so.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

/**
 * Reads and writes the single option the re-index walk reports its position through.
 */
final class IndexingProgress {

	/**
	 * Where the record lives.
	 *
	 * Autoloaded `no`: it is read by one AJAX endpoint and the Knowledge Base page, not on
	 * every request, and it changes on every batch — an autoloaded row that churns is the
	 * shape that makes `alloptions` cache invalidation expensive.
	 */
	public const OPTION = 'wai_indexing_progress';

	/** No walk has been queued, or the last one finished. */
	public const STATE_IDLE = 'idle';

	/** Queued, but no batch has reported in yet. */
	public const STATE_QUEUED = 'queued';

	/** At least one batch has completed and the cursor is advancing. */
	public const STATE_RUNNING = 'running';

	/** The walk drained every phase. */
	public const STATE_DONE = 'done';

	/**
	 * How long a `queued`/`running` record is believed before it is read as stalled.
	 *
	 * A walk that dies between batches — a fatal in a job, Action Scheduler stopping, the
	 * site going quiet with no traffic to drive WP-Cron — leaves its last record behind
	 * with nothing to clear it. Without an expiry the page would show "Indexing…" forever
	 * for a job that is never coming back, which is the exact failure this whole change
	 * exists to remove. Fifteen minutes is well past the jittered gap between batches.
	 */
	private const STALE_AFTER = 900;

	/**
	 * Start a record for a walk that has just been queued.
	 *
	 * @param array{product: int, category: int, page: int, total: int} $counts Phase totals.
	 */
	public function start( array $counts ): void {
		update_option(
			self::OPTION,
			array(
				'state'      => self::STATE_QUEUED,
				'processed'  => 0,
				'total'      => (int) ( $counts['total'] ?? 0 ),
				'phase'      => '',
				'counts'     => array(
					'product'  => (int) ( $counts['product'] ?? 0 ),
					'category' => (int) ( $counts['category'] ?? 0 ),
					'page'     => (int) ( $counts['page'] ?? 0 ),
				),
				'started_at' => time(),
				'updated_at' => time(),
			),
			false
		);
	}

	/**
	 * Record that the walk has advanced.
	 *
	 * `$processed` is the cursor's absolute position across all phases, not a delta, so a
	 * batch that runs twice (Action Scheduler re-running a claimed action after a crash)
	 * cannot double-count. It is clamped to `total` because the counts were taken when the
	 * walk was queued: a merchant who publishes ten products mid-walk would otherwise push
	 * the bar past 100%.
	 */
	public function advance( int $processed, string $phase ): void {
		$current = $this->read();
		if ( array() === $current ) {
			// Nothing started this walk — a nightly manifest re-push, or a record cleared
			// mid-flight. Recording progress against a total nobody established would
			// render a bar out of a denominator of zero.
			return;
		}

		$total = (int) ( $current['total'] ?? 0 );

		$current['state']      = self::STATE_RUNNING;
		$current['processed']  = $total > 0 ? min( $processed, $total ) : $processed;
		$current['phase']      = $phase;
		$current['updated_at'] = time();

		update_option( self::OPTION, $current, false );
	}

	/**
	 * Accumulate a batch's accepted/rejected counts.
	 *
	 * Kept separately from the cursor (`advance()`) because they answer different
	 * questions: the cursor says how far the *walk* has got, these say what the *backend
	 * did* with what arrived. A zero-quota plan produces a walk that completes perfectly
	 * while accepting nothing — the pair is what lets the completion copy distinguish
	 * "your catalogue is indexed" from "your catalogue was refused".
	 */
	public function tally( int $accepted, int $rejected ): void {
		$current = $this->read();
		if ( array() === $current ) {
			return;
		}

		$current['accepted']   = max( 0, (int) ( $current['accepted'] ?? 0 ) ) + max( 0, $accepted );
		$current['rejected']   = max( 0, (int) ( $current['rejected'] ?? 0 ) ) + max( 0, $rejected );
		$current['updated_at'] = time();

		update_option( self::OPTION, $current, false );
	}

	/** Mark the walk complete; the bar reads full and the page stops polling. */
	public function finish(): void {
		$current = $this->read();
		if ( array() === $current ) {
			return;
		}

		$current['state']      = self::STATE_DONE;
		$current['processed']  = (int) ( $current['total'] ?? 0 );
		$current['updated_at'] = time();

		update_option( self::OPTION, $current, false );
	}

	/** Drop the record entirely — used by uninstall and by a fresh start. */
	public function clear(): void {
		delete_option( self::OPTION );
	}

	/**
	 * The current record, or `array()` when there is none.
	 *
	 * A `queued`/`running` record older than `STALE_AFTER` is reported as `idle` rather
	 * than relayed: see that constant for why a stalled walk must not read as a live one.
	 *
	 * @return array<string, mixed>
	 */
	public function read(): array {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) || array() === $stored ) {
			return array();
		}

		$state   = is_string( $stored['state'] ?? null ) ? (string) $stored['state'] : self::STATE_IDLE;
		$updated = (int) ( $stored['updated_at'] ?? 0 );
		$live    = in_array( $state, array( self::STATE_QUEUED, self::STATE_RUNNING ), true );

		if ( $live && $updated > 0 && ( time() - $updated ) > self::STALE_AFTER ) {
			$stored['state'] = self::STATE_IDLE;
			$stored['stale'] = true;
		}

		return $stored;
	}

	/**
	 * The absolute cursor position for a phase/offset pair.
	 *
	 * The walk's own cursor is per-phase (`offset` restarts at zero each phase), so the
	 * phases before the current one have to be added back to get a number that only ever
	 * increases — which is what a progress bar needs.
	 *
	 * @param array{product: int, category: int, page: int} $counts Phase totals.
	 * @param string                                        $phase  The phase now running.
	 * @param int                                           $offset The cursor within it.
	 */
	public static function absolute( array $counts, string $phase, int $offset ): int {
		$done = 0;
		foreach ( array( 'product', 'category', 'page' ) as $name ) {
			if ( $name === $phase ) {
				break;
			}
			$done += (int) ( $counts[ $name ] ?? 0 );
		}
		return $done + $offset;
	}
}
