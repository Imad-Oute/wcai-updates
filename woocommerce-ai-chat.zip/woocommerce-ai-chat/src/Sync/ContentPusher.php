<?php
/**
 * Content push (`add-content-ingestion-kb §1.4`).
 *
 * Serializes collected items and pushes them to `/v1/index/push` over HTTPS with the
 * bearer store token (FR-004, NFR-027). The transport itself lives in
 * `Auth\BackendClient` — the plugin's single outbound HTTP seam (D1) — so this class is
 * batching, contract-shaping, and result interpretation only.
 *
 * Two contract constraints drive the batching:
 *
 * - `PushRequest.items` is `min_length=1, max_length=500`. An empty push is a 422, not a
 *   no-op, so an empty collection must not be sent at all; and a 25k-item catalogue must
 *   be split. The batch size here is **50**, matching the `push_batch` job (§2.3) — well
 *   under the contract cap, and small enough that a shared-hosting PHP process finishes a
 *   batch inside its execution limit.
 * - The endpoint is idempotent (NFR-027): re-pushing an identical batch is safe, which is
 *   what makes the Action Scheduler retry in §2.3 correct rather than duplicating content.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

use WooAIChat\Auth\BackendApi;
use WooAIChat\Auth\BackendClient;
use WooAIChat\Auth\TokenStore;

final class ContentPusher {

	/**
	 * Items per request. The contract allows 500; 50 matches the `push_batch` job size
	 * and keeps a single request well inside shared-hosting time and memory limits.
	 */
	public const BATCH_SIZE = 50;

	/**
	 * The `error` value a rate-limited push reports, and the status that produces it.
	 *
	 * A constant rather than a literal because `IngestionScheduler` matches on it to choose
	 * a retry schedule; a typo on either side would silently downgrade the rate-limit path
	 * back to the generic one, which is the behaviour being fixed.
	 */
	public const ERROR_RATE_LIMITED = 'rate_limited';

	private const ERROR_RATE_LIMITED_STATUS = 429;

	private TokenStore $tokens;
	private BackendApi $backend;

	public function __construct( TokenStore $tokens, ?BackendApi $backend = null ) {
		$this->tokens  = $tokens;
		$this->backend = $backend ?? new BackendClient();
	}

	/**
	 * Push a set of collected items, batching to `BATCH_SIZE`.
	 *
	 * @param array<int, array<string, mixed>> $items `PushItem`-shaped rows.
	 * @return array{ok: bool, accepted: int, skipped: int, rejected: int, batches: int, memory_limit_reached: bool, error: string, retry_after: int}
	 */
	public function push( array $items ): array {
		$result = array(
			'ok'                   => true,
			'accepted'             => 0,
			'skipped'              => 0,
			'rejected'             => 0,
			'batches'              => 0,
			'memory_limit_reached' => false,
			'error'                => '',
			// Non-zero only when `error` is `rate_limited`: the seconds the backend asked
			// us to wait. The caller schedules against this rather than its own backoff
			// ladder, which is guessing at a number the server already knows.
			'retry_after'          => 0,
		);

		// An empty collection is a legitimate state (a brand-new store), and the contract
		// rejects a zero-item body. Succeed without a request rather than 422.
		if ( array() === $items ) {
			return $result;
		}

		$store_token = $this->tokens->get_store_token();
		if ( '' === $store_token ) {
			$result['ok']    = false;
			$result['error'] = 'no_store_token';
			return $result;
		}

		foreach ( array_chunk( $items, self::BATCH_SIZE ) as $batch ) {
			$response = $this->backend->push_index_items( $store_token, array_values( $batch ) );
			++$result['batches'];

			$body = is_array( $response['body'] ?? null ) ? $response['body'] : array();

			if ( $response['status'] < 200 || $response['status'] >= 300 ) {
				$result['ok']          = false;
				$result['error']       = $this->error_message( $response['status'], $body );
				$result['retry_after'] = $this->retry_after_of( $response );
				// Stop on first failure: the caller (an Action Scheduler job, §2.3) retries
				// from its cursor, and hammering a failing backend with the remaining
				// batches would only deepen the outage. That reasoning is strongest of all
				// for a 429, where the remaining batches are guaranteed refusals.
				return $result;
			}

			$result['accepted'] += (int) ( $body['accepted'] ?? 0 );
			$result['skipped']  += (int) ( $body['skipped_unchanged'] ?? 0 );
			$result['rejected'] += (int) ( $body['rejected'] ?? 0 );

			// The plan's memory cap is enforced backend-side (§3.6); it reports the cap
			// rather than erroring, so detect it here and stop pushing. Continuing would
			// send batches the backend can only reject.
			$limit = (int) ( $body['memory_limit'] ?? 0 );
			$used  = (int) ( $body['memory_used'] ?? 0 );
			if ( $limit > 0 && $used >= $limit ) {
				$result['memory_limit_reached'] = true;
				break;
			}
		}

		return $result;
	}

	/**
	 * Push a set of delete events (§2.4).
	 *
	 * `DeleteRequest.items` is `min_length=1`, so an empty set succeeds without a request,
	 * mirroring `push`. The endpoint is idempotent — deleting an already-absent item is a
	 * no-op that reports `deleted: 0` — which is what makes the Action Scheduler retry safe.
	 *
	 * @param array<int, array<string, mixed>> $items `DeleteItem`-shaped rows.
	 * @return array{ok: bool, deleted: int, error: string, retry_after: int}
	 */
	public function delete( array $items ): array {
		$result = array(
			'ok'          => true,
			'deleted'     => 0,
			'error'       => '',
			'retry_after' => 0,
		);
		if ( array() === $items ) {
			return $result;
		}

		$store_token = $this->tokens->get_store_token();
		if ( '' === $store_token ) {
			$result['ok']    = false;
			$result['error'] = 'no_store_token';
			return $result;
		}

		foreach ( array_chunk( $items, self::BATCH_SIZE ) as $batch ) {
			$response = $this->backend->delete_index_items( $store_token, array_values( $batch ) );
			$body     = is_array( $response['body'] ?? null ) ? $response['body'] : array();

			if ( $response['status'] < 200 || $response['status'] >= 300 ) {
				$result['ok']          = false;
				$result['error']       = $this->error_message( $response['status'], $body );
				$result['retry_after'] = $this->retry_after_of( $response );
				return $result;
			}
			$result['deleted'] += (int) ( $body['deleted'] ?? 0 );
		}

		return $result;
	}

	/**
	 * Push the nightly reconciliation manifest (§2.6).
	 *
	 * Returns the backend's diff verdict: how many stale items it tombstoned, how many were
	 * unchanged, and `request_full` — the `object_id`s it holds no current copy of and wants
	 * a full push for. The nightly job (§2.6) reads `request_full` and re-pushes exactly
	 * those, which is how a missed create self-heals within 24h (D-7).
	 *
	 * @param array<int, array<string, mixed>> $items `ManifestItem`-shaped rows.
	 * @return array{ok: bool, deleted: int, unchanged: int, request_full: array<int, int>, error: string, retry_after: int}
	 */
	public function push_manifest( array $items ): array {
		$result = array(
			'ok'           => true,
			'deleted'      => 0,
			'unchanged'    => 0,
			'request_full' => array(),
			'error'        => '',
			'retry_after'  => 0,
		);

		$store_token = $this->tokens->get_store_token();
		if ( '' === $store_token ) {
			$result['ok']    = false;
			$result['error'] = 'no_store_token';
			return $result;
		}

		$response = $this->backend->push_manifest( $store_token, array_values( $items ) );
		$body     = is_array( $response['body'] ?? null ) ? $response['body'] : array();

		if ( $response['status'] < 200 || $response['status'] >= 300 ) {
			$result['ok']          = false;
			$result['error']       = $this->error_message( $response['status'], $body );
			$result['retry_after'] = $this->retry_after_of( $response );
			return $result;
		}

		$result['deleted']   = (int) ( $body['deleted'] ?? 0 );
		$result['unchanged'] = (int) ( $body['unchanged'] ?? 0 );

		$request_full = $body['request_full'] ?? array();
		if ( is_array( $request_full ) ) {
			foreach ( $request_full as $object_id ) {
				if ( is_numeric( $object_id ) ) {
					$result['request_full'][] = (int) $object_id;
				}
			}
		}

		return $result;
	}

	/**
	 * The `Retry-After` the backend attached, or 0 when it attached none.
	 *
	 * `BackendClient` sets this only on a 429 and clamps it there, so a non-zero value here
	 * is both a rate-limit signal and a usable delay.
	 *
	 * @param array{status:int, body:mixed, retry_after?:int} $response
	 */
	private function retry_after_of( array $response ): int {
		$retry_after = $response['retry_after'] ?? 0;
		return is_numeric( $retry_after ) ? max( 0, (int) $retry_after ) : 0;
	}

	/**
	 * Turn a non-2xx push response into a short, loggable reason.
	 *
	 * Deliberately terse: this string ends up in a job log and an admin notice, and the
	 * merchant-facing wording belongs to the Knowledge Base page (§5), not here.
	 *
	 * @param array<string, mixed> $body
	 */
	private function error_message( int $status, array $body ): string {
		if ( 401 === $status ) {
			return 'unauthorized';
		}
		if ( 402 === $status || 403 === $status ) {
			return 'subscription_or_plan_denied';
		}
		if ( self::ERROR_RATE_LIMITED_STATUS === $status ) {
			// Named rather than folded into the generic `http_429` below, because the caller
			// has to treat it differently: it is the one failure that is neither the store's
			// fault nor the backend being unhealthy, and it carries its own retry schedule.
			// `IngestionScheduler` branches on exactly this string.
			return self::ERROR_RATE_LIMITED;
		}
		if ( 0 === $status ) {
			return 'transport_error';
		}
		$message = $body['message'] ?? $body['detail'] ?? '';
		return is_string( $message ) && '' !== $message
			? 'http_' . $status . ': ' . $message
			: 'http_' . $status;
	}
}
