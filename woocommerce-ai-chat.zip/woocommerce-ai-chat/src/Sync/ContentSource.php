<?php
/**
 * The collection seam (`add-content-ingestion-kb §2.3, §6.4`).
 *
 * `ContentCollector` is `final` — it is the one class that reads WooCommerce CRUD, and its
 * own behaviour (hashing, exclusions, id namespacing) is tested directly in
 * `ContentCollectorTest` against that concrete class.
 *
 * `IngestionScheduler` needs something else: its job bodies must be provable *without* a
 * WooCommerce install — that a failed page retries the same cursor rather than advancing
 * past it, that the walk resumes from `{phase, offset}` after an interruption (§6.4). Those
 * are properties of the scheduler, not of collection, so the scheduler depends on this
 * interface and the tests drive it with a scripted catalogue.
 *
 * `ContentCollector` remains the sole implementation, and remains final.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

/**
 * Read access to the collectable catalogue.
 */
interface ContentSource {

	/**
	 * Collect one item by type and source id, or null when it is no longer indexable
	 * (deleted, unpublished, or now excluded) — which the caller turns into a delete.
	 *
	 * @return array<string, mixed>|null
	 */
	public function collect_by_type( string $object_type, int $source_id ): ?array;

	/**
	 * One page of a phase's rows, plus whether more raw rows remain behind it.
	 *
	 * @return array{items: array<int, array<string, mixed>>, has_more: bool}
	 */
	public function collect_slice( string $phase, int $offset, int $limit ): array;

	/**
	 * The store-identity item (name, currency, policies), pushed alongside the catalogue.
	 *
	 * @return array<string, mixed>
	 */
	public function collect_store_identity(): array;

	/**
	 * How many raw rows each phase will walk, for the re-index progress report (§5.5).
	 *
	 * Part of the seam rather than of `ContentCollector` alone because the scheduler calls
	 * it when opening a progress record, and §6.4's point is that the scheduler's job
	 * bodies stay provable without a WooCommerce install behind them.
	 *
	 * @return array{product: int, category: int, page: int, total: int}
	 */
	public function count_all(): array;
}
