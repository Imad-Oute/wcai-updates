<?php
/**
 * Local registry of pushed manual knowledge entries (`add-content-ingestion-kb §5.4`).
 *
 * Manual entries are the one content type with no WordPress object behind them: a product
 * can always be re-collected from WooCommerce, but a manual answer exists only as what was
 * pushed. Without a local record of that push, two things break:
 *
 *   - the nightly manifest (`ManifestBuilder::build()`) cannot list the entry, so the
 *     backend's tombstone pass — which deletes every id absent from the manifest — silently
 *     erases every manual entry within 24h of it being saved;
 *   - the Knowledge Base include toggle cannot re-push the entry, because
 *     `ContentCollector::collect_by_type()` has nothing to re-collect it from, and its null
 *     is read as "gone → delete".
 *
 * So every successful manual push is recorded here, in one option row, and removed when the
 * merchant deletes/excludes the entry. The stored `content_hash` is the hash of the exact
 * body that was pushed, byte-for-byte — the manifest's unchanged-check is hash equality
 * against what the backend holds, so re-hashing a reconstructed body at manifest time would
 * risk a needless `request_full` if reconstruction ever drifted from the push.
 *
 * ## The reserved id band
 *
 * The manifest contract keys on `object_id` alone (no `object_type`), so manual ids must
 * not collide with the namespaced catalogue ids: products own `< 1e9`, pages own
 * `1e9 – 2e9`, categories own `2e9 + term_id` (see `ContentCollector::ID_OFFSET_*`).
 * Manual entries take the top of what remains: the backend's `indexed_items.object_id`
 * column is a signed 32-bit `Integer`, so the band must stay below 2,147,483,647 — it runs
 * `2,100,000,000 – 2,146,999,999`, leaving categories 100M term ids of headroom below it.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

final class ManualEntryRegistry {

	/**
	 * The option row holding the registry.
	 *
	 * A raw literal rather than a `WAI_OPTION_*` constant because `Lifecycle`'s uninstall
	 * purge names it as a literal too — the two must agree on the exact string, and a
	 * constant defined in the plugin bootstrap would not exist in the uninstall context.
	 */
	public const OPTION = 'wai_manual_entries';

	/**
	 * First id of the manual band. Above the category namespace's plausible range, below
	 * the backend column's signed 32-bit ceiling — see the class header.
	 */
	public const ID_BAND_START = 2100000000;

	/** Band width; the last manual id is `ID_BAND_START + ID_BAND_SIZE - 1` = 2,146,999,999. */
	public const ID_BAND_SIZE = 47000000;

	/**
	 * Every recorded entry, keyed by `object_id`.
	 *
	 * @return array<int, array{title: string, content: string, content_hash: string, version: int}>
	 */
	public function all(): array {
		$entries = get_option( self::OPTION );
		if ( ! is_array( $entries ) ) {
			return array();
		}

		$valid = array();
		foreach ( $entries as $object_id => $entry ) {
			// A malformed row (a manual DB edit, a partial write) is dropped rather than
			// propagated: a registry row without title+content cannot be re-pushed, and a
			// row without a hash would poison the manifest's unchanged-check.
			if ( ! is_array( $entry )
				|| ! is_string( $entry['title'] ?? null ) || '' === $entry['title']
				|| ! is_string( $entry['content'] ?? null )
				|| ! is_string( $entry['content_hash'] ?? null ) || '' === $entry['content_hash']
			) {
				continue;
			}
			$valid[ (int) $object_id ] = array(
				'title'        => $entry['title'],
				'content'      => $entry['content'],
				'content_hash' => $entry['content_hash'],
				'version'      => (int) ( $entry['version'] ?? 0 ),
			);
		}
		return $valid;
	}

	/**
	 * One entry, or null when the id was never recorded (or was removed).
	 *
	 * @return array{title: string, content: string, content_hash: string, version: int}|null
	 */
	public function get( int $object_id ): ?array {
		return $this->all()[ $object_id ] ?? null;
	}

	/**
	 * Record a successful push. Called *after* the backend accepted it, so the registry
	 * only ever describes entries the backend actually holds — an entry recorded before a
	 * failed push would make the nightly manifest list an id the backend never had.
	 */
	public function remember( int $object_id, string $title, string $content, string $content_hash, int $version ): void {
		$entries               = $this->all();
		$entries[ $object_id ] = array(
			'title'        => $title,
			'content'      => $content,
			'content_hash' => $content_hash,
			'version'      => $version,
		);
		update_option( self::OPTION, $entries );
	}

	/**
	 * Remove an entry the merchant excluded/deleted.
	 *
	 * Must run *before* (or regardless of) the delete push landing: the nightly manifest
	 * re-lists every registry id, and the backend answers an id it does not hold with
	 * `request_full` — so a forgotten removal would resurrect an entry the merchant
	 * deleted. Removing first means the worst failure mode is the opposite and benign:
	 * a delete that never lands is tombstoned by the next nightly manifest anyway.
	 */
	public function forget( int $object_id ): void {
		$entries = $this->all();
		if ( ! array_key_exists( $object_id, $entries ) ) {
			return;
		}
		unset( $entries[ $object_id ] );
		update_option( self::OPTION, $entries );
	}

	/**
	 * The `object_id` a manual entry with this title should be pushed under.
	 *
	 * Derived from the title so re-saving the same entry replaces it rather than
	 * accumulating near-duplicates the merchant cannot tell apart (`crc32` is a stable
	 * spread, not a security choice). A crc32 collision between two *different* titles is
	 * resolved by probing forward inside the band, checked against the registry — the only
	 * authority on which manual ids are taken.
	 */
	public function id_for_title( string $title ): int {
		$entries = $this->all();
		$base    = (int) ( sprintf( '%u', crc32( $title ) ) % self::ID_BAND_SIZE );

		// Linear probe: at most count+1 slots can be occupied in a row, so the loop is
		// bounded by the registry size, not the band size.
		$limit = count( $entries ) + 1;
		for ( $i = 0; $i < $limit; $i++ ) {
			$candidate = self::ID_BAND_START + ( ( $base + $i ) % self::ID_BAND_SIZE );
			$existing  = $entries[ $candidate ] ?? null;
			if ( null === $existing || $title === $existing['title'] ) {
				return $candidate;
			}
		}

		// Unreachable unless the registry holds tens of millions of entries; fall back to
		// the raw slot rather than failing the save.
		return self::ID_BAND_START + $base;
	}

	/**
	 * Rebuild the `PushItem` for one recorded entry — the exact shape
	 * `Panel::ajax_manual_entry()` pushed, so the manifest row and any re-push are
	 * indistinguishable from the original save.
	 *
	 * @param int $version Version stamp for this push. Pass the stored version for the
	 *                     manifest (the entry has not changed since it was pushed); pass a
	 *                     fresh `time()` for a re-push so last-writer-wins dates the
	 *                     re-include after the exclusion's tombstone (D-3).
	 * @return array<string, mixed>|null Null when the id is not in the registry.
	 */
	public function push_item( int $object_id, ?int $version = null ): ?array {
		$entry = $this->get( $object_id );
		if ( null === $entry ) {
			return null;
		}

		return array(
			'object_type'  => 'manual',
			'object_id'    => $object_id,
			'content'      => $entry['title'] . "\n\n" . $entry['content'],
			'content_hash' => $entry['content_hash'],
			'version'      => $version ?? $entry['version'],
			'source'       => 'manual',
			'meta'         => array( 'title' => $entry['title'] ),
		);
	}

	/**
	 * `PushItem` rows for every recorded entry — what `ManifestBuilder::build()` merges
	 * into the manifest so the backend's tombstone pass sees manual entries as present.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function push_items(): array {
		$items = array();
		foreach ( array_keys( $this->all() ) as $object_id ) {
			$item = $this->push_item( $object_id );
			if ( null !== $item ) {
				$items[] = $item;
			}
		}
		return $items;
	}
}
