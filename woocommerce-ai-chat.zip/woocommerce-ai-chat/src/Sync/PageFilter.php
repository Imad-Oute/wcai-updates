<?php
/**
 * The key-page decision seam (`add-content-ingestion-kb §1.1a`, design D-6).
 *
 * `PageSelector` is `final`, and its heuristic is tested directly in `PageSelectorTest`.
 * `ContentHooks` only needs the *verdict* — "should this page be pushed?" — so it depends on
 * this interface rather than the concrete selector. That keeps the hook tests about hook
 * behaviour (is a non-key page skipped?) instead of re-deriving the allowlist through
 * mocked option reads.
 *
 * It was a *one*-method interface, and that was wrong: `Panel` also holds a `PageFilter`
 * and calls `set_override()` on it when a merchant includes or excludes a page by hand. The
 * call resolved only because the concrete `PageSelector` is what production injects — pass
 * any other implementation (`ContentHooksTest`'s own `StubPageSelector`, for one) and it is
 * an immediate fatal. Declared here now, so the contract matches what callers rely on.
 *
 * `PageSelector` remains the sole implementation, and remains final.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

/**
 * The include/exclude verdict for a candidate page.
 */
interface PageFilter {

	/** Whether this page passes the key-page heuristic and should be indexed. */
	public function should_collect( int $page_id ): bool;

	/**
	 * Record a merchant's manual include/exclude for a page, overriding the heuristic.
	 *
	 * @param int  $page_id        The page the merchant acted on.
	 * @param bool $should_include Their verdict, which wins over `should_collect()`.
	 */
	public function set_override( int $page_id, bool $should_include ): void;
}
