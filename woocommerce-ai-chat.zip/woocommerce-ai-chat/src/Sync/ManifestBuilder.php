<?php
/**
 * Nightly reconciliation manifest (`add-content-ingestion-kb §2.6`, FR-008/FR-034, D-7).
 *
 * Collects everything that *should* currently be indexed and reduces it to the lightweight
 * `[{object_id, content_hash, version}]` the manifest contract carries — no content crosses
 * the wire (TR-017c). The backend diffs this against what it holds and self-heals missed
 * creates, updates, and deletes within 24h:
 *
 *   - an id the backend holds but the manifest omits  → the backend tombstones it;
 *   - an id whose hash differs, or that the backend lacks → returned in `request_full`;
 *   - an id whose hash matches                          → skipped (no re-embed).
 *
 * `request_full` names `object_id`s only, so the builder also keeps a map from `object_id`
 * back to the full `PushItem` it built, letting the nightly job answer a re-push request
 * without re-collecting the whole catalogue a second time.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

final class ManifestBuilder implements ManifestSource {

	private ContentCollector $collector;
	private ManualEntryRegistry $manual;

	public function __construct( ?ContentCollector $collector = null, ?ManualEntryRegistry $manual = null ) {
		$this->collector = $collector ?? new ContentCollector();
		$this->manual    = $manual ?? new ManualEntryRegistry();
	}

	/**
	 * Build the manifest and the `object_id => PushItem` lookup in one collection pass.
	 *
	 * Store identity is included alongside the catalogue so the manifest is the complete
	 * picture of what should be indexed — otherwise the backend, seeing no store-identity id
	 * in the manifest, would tombstone it every night. Manual entries are included from the
	 * `ManualEntryRegistry` for the identical reason: they have no WordPress object the
	 * collector could walk, so the registry is the only record that they should exist, and
	 * omitting them meant every merchant-authored answer was deleted by the next nightly
	 * reconciliation.
	 *
	 * @return array{manifest: array<int, array<string, mixed>>, items: array<int, array<string, mixed>>}
	 *   `manifest` is the `ManifestItem` rows to push; `items` maps `object_id` → the full
	 *   `PushItem` for the re-push path.
	 */
	public function build(): array {
		$all = array_merge(
			array( $this->collector->collect_store_identity() ),
			$this->collector->collect_all(),
			// Registry rows carry the hash/version recorded at push time, so an unchanged
			// manual entry hash-matches the backend's row and is never re-embedded.
			$this->manual->push_items()
		);

		$manifest = array();
		$items    = array();
		foreach ( $all as $item ) {
			$object_id = (int) ( $item['object_id'] ?? 0 );

			$manifest[]          = array(
				'object_id'    => $object_id,
				'content_hash' => (string) ( $item['content_hash'] ?? '' ),
				'version'      => (int) ( $item['version'] ?? 0 ),
			);
			$items[ $object_id ] = $item;
		}

		return array(
			'manifest' => $manifest,
			'items'    => $items,
		);
	}
}
