<?php
/**
 * Key-page selection heuristic (`add-content-ingestion-kb §1.1a`, design D-6).
 *
 * FR-029 scopes page collection to *key* pages — About / Shipping / Returns / FAQ /
 * Contact / Terms / Privacy — but `save_post_page` fires for every page on the site. A
 * blog-heavy store would otherwise push hundreds of irrelevant pages, burning memory-item
 * quota and adding retrieval noise. So a page is collected only when it matches one of
 * three ordered sources of truth:
 *
 *   (a) **Well-known page settings** — pages the platform itself has designated:
 *       WordPress's `wp_page_for_privacy_policy` and WooCommerce's terms page, plus the
 *       WC shop-functional pages (cart/checkout/account are *excluded*; they are UI, not
 *       knowledge — see `is_functional_page()`).
 *   (b) **Slug/title allowlist** — pattern matching for the key-page set, with localized
 *       variants, because most stores author these as ordinary pages.
 *   (c) **Merchant override** — the Knowledge Base include/exclude toggle (§5.3), which
 *       wins over both directions: it can include a non-matching page and exclude a
 *       matching one.
 *
 * Precedence is deliberate: an explicit merchant decision (c) always beats the heuristic,
 * because the merchant knows their store better than a slug pattern does.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

final class PageSelector implements PageFilter {

	/**
	 * Slug/title fragments identifying the key-page set (D-6b).
	 *
	 * Matched as substrings against both slug and title, so `shipping-returns` and
	 * `our-shipping-policy` both hit. Localized variants are included for the languages
	 * v1 targets; the list is a filterable seam (`wcai_key_page_patterns`) so a store in
	 * another locale can extend it without a plugin change.
	 *
	 * @var string[]
	 */
	private const KEY_PAGE_PATTERNS = array(
		// English.
		'about',
		'shipping',
		'delivery',
		'return',
		'refund',
		'faq',
		'frequently-asked',
		'contact',
		'terms',
		'conditions',
		'privacy',
		'policy',
		'warranty',
		'guarantee',
		'exchange',
		'support',
		'help',
		// French.
		'a-propos',
		'livraison',
		'retour',
		'contactez',
		'confidentialite',
		'garantie',
		'conditions-generales',
		'aide',
		// Spanish.
		'acerca',
		'envio',
		'devolucion',
		'contacto',
		'privacidad',
		'garantia',
		'ayuda',
		// German.
		'ueber-uns',
		'versand',
		'ruckgabe',
		'kontakt',
		'datenschutz',
		'impressum',
		'hilfe',
		// Arabic (slugs are often transliterated; titles match natively).
		'شحن',
		'إرجاع',
		'اتصل',
		'خصوصية',
		'الشروط',
		'حول',
	);

	/**
	 * Whether a page should be collected and pushed.
	 *
	 * @param int $page_id The page's post ID.
	 * @return bool True when the page is key content the assistant should be able to cite.
	 */
	public function should_collect( int $page_id ): bool {
		if ( $page_id <= 0 ) {
			return false;
		}

		// (c) Merchant override wins in both directions, checked first.
		$override = $this->override_for( $page_id );
		if ( null !== $override ) {
			return $override;
		}

		// Cart/checkout/account are interactive UI. Indexing them yields answers like
		// "your cart is empty" — noise that never helps a shopper question.
		if ( $this->is_functional_page( $page_id ) ) {
			return false;
		}

		// (a) Platform-designated policy pages.
		if ( $this->is_well_known_page( $page_id ) ) {
			return true;
		}

		// (b) Slug/title allowlist.
		return $this->matches_key_page_pattern( $page_id );
	}

	/**
	 * The merchant's explicit include/exclude decision for a page, if any.
	 *
	 * Stored as `[ page_id => bool ]` under a single option, written by the Knowledge Base
	 * page (§5.3). Returns null when the merchant has expressed no opinion, which is the
	 * signal to fall through to the heuristic.
	 *
	 * @param int $page_id
	 * @return bool|null
	 */
	public function override_for( int $page_id ) {
		$overrides = get_option( WAI_OPTION_KB_PAGE_OVERRIDES );
		if ( ! is_array( $overrides ) || ! array_key_exists( $page_id, $overrides ) ) {
			return null;
		}
		return (bool) $overrides[ $page_id ];
	}

	/** Record a merchant include/exclude decision (used by the Knowledge Base page). */
	public function set_override( int $page_id, bool $should_include ): void {
		$overrides = get_option( WAI_OPTION_KB_PAGE_OVERRIDES );
		if ( ! is_array( $overrides ) ) {
			$overrides = array();
		}
		$overrides[ $page_id ] = $should_include;
		update_option( WAI_OPTION_KB_PAGE_OVERRIDES, $overrides );
	}

	/**
	 * Pages the platform designates as policy content (D-6a).
	 *
	 * These are authoritative: if WordPress or WooCommerce says "this is the privacy
	 * policy", no slug matching is needed.
	 */
	private function is_well_known_page( int $page_id ): bool {
		$well_known = array(
			(int) get_option( 'wp_page_for_privacy_policy' ),
			(int) get_option( 'woocommerce_terms_page_id' ),
		);
		return in_array( $page_id, array_filter( $well_known ), true );
	}

	/**
	 * WooCommerce's transactional pages. Excluded even though they are "well known" —
	 * they render dynamic UI, not knowledge.
	 */
	private function is_functional_page( int $page_id ): bool {
		$functional = array(
			(int) get_option( 'woocommerce_cart_page_id' ),
			(int) get_option( 'woocommerce_checkout_page_id' ),
			(int) get_option( 'woocommerce_myaccount_page_id' ),
		);
		return in_array( $page_id, array_filter( $functional ), true );
	}

	/** Substring match of the allowlist against the page's slug and title (D-6b). */
	private function matches_key_page_pattern( int $page_id ): bool {
		$post = get_post( $page_id );
		if ( ! $post ) {
			return false;
		}

		/**
		 * Filter the key-page slug/title patterns.
		 *
		 * @param string[] $patterns Substrings matched against slug and title.
		 */
		$patterns = apply_filters( 'wcai_key_page_patterns', self::KEY_PAGE_PATTERNS );
		if ( ! is_array( $patterns ) ) {
			$patterns = self::KEY_PAGE_PATTERNS;
		}

		$slug  = is_string( $post->post_name ?? null ) ? strtolower( $post->post_name ) : '';
		$title = is_string( $post->post_title ?? null ) ? strtolower( $post->post_title ) : '';

		foreach ( $patterns as $pattern ) {
			if ( ! is_string( $pattern ) || '' === $pattern ) {
				continue;
			}
			$needle = strtolower( $pattern );
			if ( str_contains( $slug, $needle ) || str_contains( $title, $needle ) ) {
				return true;
			}
		}
		return false;
	}
}
