<?php
/**
 * The manifest-build seam (`add-content-ingestion-kb §2.6, §6.4`).
 *
 * `ManifestBuilder` is `final`. The nightly job's own behaviour — that it pushes the
 * manifest, then re-pushes exactly the items the backend named in `request_full`, from the
 * map it already built rather than a second collection pass — is a property of the
 * scheduler, and provable only if the built manifest can be scripted.
 *
 * `ManifestBuilder` remains the sole implementation, and remains final.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

/**
 * Builds the nightly reconciliation manifest.
 */
interface ManifestSource {

	/**
	 * @return array{manifest: array<int, array<string, mixed>>, items: array<int, array<string, mixed>>}
	 *   `manifest` is the lightweight `ManifestItem` rows; `items` maps `object_id` → the
	 *   full `PushItem`, so a `request_full` reply needs no re-collection.
	 */
	public function build(): array;
}
