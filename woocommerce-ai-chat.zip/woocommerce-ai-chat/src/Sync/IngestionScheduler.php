<?php
/**
 * Action Scheduler job layer for content ingestion (`add-content-ingestion-kb §2.3`).
 *
 * Every push the plugin makes runs here, on Action Scheduler, never inline in a WooCommerce
 * save (NFR-030). The hook handlers (`ContentHooks`) do no HTTP; they enqueue one of these
 * jobs and return, so a slow or failing backend can never stall a merchant's product save.
 *
 * Four jobs, all in the `wc_ai_agent` group so an operator can see and clear the plugin's
 * scheduled work under one filter:
 *
 *   - **`push_single`** — re-collect one changed item and push it (§2.1). Args are the
 *     `{object_type, source_id}` identifier, not the content: the job re-collects at run
 *     time, so the pushed content is current and the version stamp dates *that* moment for
 *     last-writer-wins (D-3). A re-collect that comes back empty (the item was unpublished
 *     or deleted meanwhile) turns into a delete.
 *   - **`push_delete`** — tombstone one item by its namespaced `object_id` (§2.4).
 *   - **`push_batch`** — the cursor-resumable full re-push (§2.3). A `{phase, offset}`
 *     cursor walks products → categories → pages one 50-item page at a time, each job
 *     scheduling the next. The cursor lives in the Action Scheduler arg row, so an
 *     interruption resumes from the last committed page rather than restarting; the push
 *     endpoint's idempotency (NFR-027) makes a replayed page a no-op.
 *   - **`nightly_manifest`** — the reconciliation sweep (§2.6, D-7).
 *
 * **Retry + backoff.** Action Scheduler does not retry a failed action on its own, so a job
 * that hits a transient backend failure reschedules itself with a jittered, capped
 * exponential backoff and an incrementing attempt counter, giving up after `MAX_ATTEMPTS`
 * rather than hammering a downed backend forever — the nightly manifest is the backstop that
 * eventually reconciles whatever the retries never landed.
 *
 * **A `429` is not one of those failures.** It is a healthy backend pacing us, so it takes a
 * separate path (`retry_after_rate_limit()`): the delay comes from the server's own
 * `Retry-After` rather than from the ladder, and the attempt counter does not advance. Under
 * the shared path a store that tripped the ceiling burned all five attempts inside a few
 * minutes on guaranteed refusals and then dropped the content — a catalogue sync losing pages
 * because it was briefly told to slow down.
 *
 * @package WooAIChat
 *
 * The `as_*` Action Scheduler functions are provided by WooCommerce, not by this plugin,
 * and every call site guards on `function_exists()` — which is what keeps them resolvable
 * to a reader and to PHPStan alike, no suppression needed.
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

use WooAIChat\Auth\TokenStore;

final class IngestionScheduler implements IngestionQueue {

	/** Action Scheduler hook names — one per job, all in the shared group. */
	public const HOOK_PUSH_SINGLE      = 'wcai_push_single';
	public const HOOK_PUSH_DELETE      = 'wcai_push_delete';
	public const HOOK_PUSH_BATCH       = 'wcai_push_batch';
	public const HOOK_NIGHTLY_MANIFEST = 'wcai_nightly_manifest';

	/** Items per full-push page. Matches `ContentPusher::BATCH_SIZE` and the `push_batch` cursor step. */
	private const BATCH_SIZE = 50;

	/** Give up after this many attempts; the nightly manifest reconciles the remainder. */
	private const MAX_ATTEMPTS = 5;

	/** Backoff ceiling in seconds, so a long outage does not push the retry days out. */
	private const MAX_BACKOFF = 300;

	/**
	 * Full-push phases, in priority order: products answer most shopper questions, so a
	 * partially-completed walk has indexed the highest-value content first.
	 *
	 * @var string[]
	 */
	private const PHASES = array(
		ContentCollector::TYPE_PRODUCT,
		ContentCollector::TYPE_CATEGORY,
		ContentCollector::TYPE_PAGE,
	);

	private TokenStore $tokens;
	private ?ContentPusher $pusher;
	private ?ContentSource $collector;
	private ?ManifestSource $manifest;
	private IndexingProgress $progress;

	/**
	 * Collaborators are optional and lazily built, so production stays a one-arg
	 * construction while the §6.1/§6.4 tests can drive the job bodies — the cursor walk, the
	 * retry ladder, the manifest re-push — without WooCommerce or a backend present.
	 */
	public function __construct(
		TokenStore $tokens,
		?ContentPusher $pusher = null,
		?ContentSource $collector = null,
		?ManifestSource $manifest = null,
		?IndexingProgress $progress = null
	) {
		$this->tokens    = $tokens;
		$this->pusher    = $pusher;
		$this->collector = $collector;
		$this->manifest  = $manifest;
		$this->progress  = $progress ?? new IndexingProgress();
	}

	/**
	 * Wire the four job callbacks and make sure the nightly manifest is scheduled.
	 *
	 * The nightly schedule normally lands at activation (`Lifecycle::activate`), but a store
	 * that updates *into* this version was activated before the job existed, so an
	 * `admin_init` backstop schedules it idempotently on the first admin hit — the same
	 * shape `SubscriptionCheckJob` uses for its own daily job.
	 */
	public function register(): void {
		add_action( self::HOOK_PUSH_SINGLE, array( $this, 'run_push_single' ), 10, 1 );
		add_action( self::HOOK_PUSH_DELETE, array( $this, 'run_push_delete' ), 10, 1 );
		add_action( self::HOOK_PUSH_BATCH, array( $this, 'run_push_batch' ), 10, 1 );
		add_action( self::HOOK_NIGHTLY_MANIFEST, array( $this, 'run_nightly_manifest' ), 10, 0 );

		add_action(
			'admin_init',
			static function (): void {
				self::schedule_nightly();
			}
		);
	}

	// -- Enqueue seam (called by ContentHooks) -----------------------------------------

	/**
	 * Enqueue a single-item push, de-duplicating a burst of saves for the same item.
	 *
	 * A product save can fire several hooks (`woocommerce_update_product` plus a stock
	 * hook); without the dedup guard each would enqueue an identical job. The guard checks
	 * for a pending action with the same first-attempt args and skips if one exists.
	 */
	public function enqueue_single( string $object_type, int $source_id ): void {
		if ( ! function_exists( 'as_enqueue_async_action' ) || $source_id <= 0 ) {
			return;
		}
		$args = array( self::single_args( $object_type, $source_id, 1 ) );
		if ( $this->already_scheduled( self::HOOK_PUSH_SINGLE, $args ) ) {
			return;
		}
		as_enqueue_async_action( self::HOOK_PUSH_SINGLE, $args, WAI_ACTION_SCHEDULER_GROUP );
	}

	/**
	 * Enqueue an immediate delete for one item (§2.4).
	 *
	 * @param string $object_type One of `ContentCollector::TYPE_*`.
	 * @param int    $object_id   The *namespaced* id the push stored the item under.
	 * @param int    $version     The tombstone version (last-writer-wins).
	 */
	public function enqueue_delete( string $object_type, int $object_id, int $version ): void {
		if ( ! function_exists( 'as_enqueue_async_action' ) ) {
			return;
		}
		$args = array( self::delete_args( $object_type, $object_id, $version, 1 ) );
		if ( $this->already_scheduled( self::HOOK_PUSH_DELETE, $args ) ) {
			return;
		}
		as_enqueue_async_action( self::HOOK_PUSH_DELETE, $args, WAI_ACTION_SCHEDULER_GROUP );
	}

	/**
	 * Kick off (or restart) a cursor-resumable full re-push from the first page (§2.3/§2.5).
	 *
	 * Idempotent against a re-trigger: if a full push is already walking, a second trigger
	 * finds the pending head job and does not start a competing walk.
	 */
	public function enqueue_full_resync(): void {
		if ( ! function_exists( 'as_enqueue_async_action' ) ) {
			return;
		}
		$args = array( self::batch_args( 0, 0, 1 ) );
		if ( $this->already_scheduled( self::HOOK_PUSH_BATCH, $args ) ) {
			return;
		}
		as_enqueue_async_action( self::HOOK_PUSH_BATCH, $args, WAI_ACTION_SCHEDULER_GROUP );

		// Opened *after* the job is queued, so a failed enqueue cannot leave a record of a
		// walk that never started — the page would poll a bar that could not move. The
		// counts are taken once, here, rather than per batch: three catalogue-wide reads
		// on a click the merchant is waiting on is affordable, per batch is not.
		//
		// Guarded for the same reason `record_progress()` is: the re-index is the thing the
		// merchant asked for, and a catalogue read that fails while counting must not take
		// down the walk that was successfully queued a line above. Without a record the
		// page falls back to the indeterminate "Indexing…" state, which is the pre-existing
		// behaviour rather than a regression.
		try {
			$this->progress->start( $this->collector()->count_all() );
		} catch ( \Throwable $e ) {
			$this->progress->clear();
		}
	}

	// -- Job callbacks ------------------------------------------------------------------

	/**
	 * Re-collect one item and push it, or delete it when it is no longer indexable (§2.1).
	 *
	 * @param array<string, mixed> $args `{object_type, source_id, attempt}`.
	 */
	public function run_push_single( $args ): void {
		$args        = is_array( $args ) ? $args : array();
		$object_type = (string) ( $args['object_type'] ?? '' );
		$source_id   = (int) ( $args['source_id'] ?? 0 );
		$attempt     = (int) ( $args['attempt'] ?? 1 );
		if ( '' === $object_type || $source_id <= 0 ) {
			return;
		}

		try {
			$item = $this->collector()->collect_by_type( $object_type, $source_id );

			if ( null === $item ) {
				// Gone or no longer indexable (unpublished, now-excluded): remove it. The
				// delete carries this moment as its tombstone version so it wins over any
				// stale in-flight push for the same item.
				$result = $this->pusher()->delete(
					array(
						array(
							'object_type' => $object_type,
							'object_id'   => ContentCollector::encode_object_id( $object_type, $source_id ),
							'version'     => time(),
						),
					)
				);
			} else {
				$result = $this->pusher()->push( array( $item ) );
			}

			if ( true !== ( $result['ok'] ?? false ) ) {
				if ( self::was_rate_limited( $result ) ) {
					$this->retry_after_rate_limit(
						self::HOOK_PUSH_SINGLE,
						self::single_args( $object_type, $source_id, $attempt ),
						self::retry_after_of( $result )
					);
					return;
				}
				$this->retry( self::HOOK_PUSH_SINGLE, self::single_args( $object_type, $source_id, $attempt + 1 ), $attempt );
			}
		} catch ( \Throwable $e ) {
			$this->retry( self::HOOK_PUSH_SINGLE, self::single_args( $object_type, $source_id, $attempt + 1 ), $attempt );
		}
	}

	/**
	 * Tombstone one item (§2.4).
	 *
	 * @param array<string, mixed> $args `{object_type, object_id, version, attempt}`.
	 */
	public function run_push_delete( $args ): void {
		$args        = is_array( $args ) ? $args : array();
		$object_type = (string) ( $args['object_type'] ?? '' );
		$object_id   = (int) ( $args['object_id'] ?? 0 );
		$version     = (int) ( $args['version'] ?? time() );
		$attempt     = (int) ( $args['attempt'] ?? 1 );
		if ( '' === $object_type ) {
			return;
		}

		try {
			$result = $this->pusher()->delete(
				array(
					array(
						'object_type' => $object_type,
						'object_id'   => $object_id,
						'version'     => $version,
					),
				)
			);
			if ( true !== ( $result['ok'] ?? false ) ) {
				if ( self::was_rate_limited( $result ) ) {
					$this->retry_after_rate_limit(
						self::HOOK_PUSH_DELETE,
						self::delete_args( $object_type, $object_id, $version, $attempt ),
						self::retry_after_of( $result )
					);
					return;
				}
				$this->retry( self::HOOK_PUSH_DELETE, self::delete_args( $object_type, $object_id, $version, $attempt + 1 ), $attempt );
			}
		} catch ( \Throwable $e ) {
			$this->retry( self::HOOK_PUSH_DELETE, self::delete_args( $object_type, $object_id, $version, $attempt + 1 ), $attempt );
		}
	}

	/**
	 * Push one page of the full re-push and schedule the next (§2.3).
	 *
	 * @param array<string, mixed> $args `{phase, offset, attempt}`.
	 */
	public function run_push_batch( $args ): void {
		$args    = is_array( $args ) ? $args : array();
		$phase   = (int) ( $args['phase'] ?? 0 );
		$offset  = (int) ( $args['offset'] ?? 0 );
		$attempt = (int) ( $args['attempt'] ?? 1 );

		if ( $phase < 0 || $phase >= count( self::PHASES ) ) {
			return; // Walk complete.
		}

		try {
			$collector = $this->collector();
			$slice     = $collector->collect_slice( self::PHASES[ $phase ], $offset, self::BATCH_SIZE );
			$items     = $slice['items'];

			// Store identity rides the very first page so the whole catalogue is covered by
			// the walk without a separate one-off job.
			if ( 0 === $phase && 0 === $offset ) {
				array_unshift( $items, $collector->collect_store_identity() );
			}

			if ( array() !== $items ) {
				$result = $this->pusher()->push( $items );
				if ( true !== ( $result['ok'] ?? false ) ) {
					// Retry the *same* page — the cursor does not advance past a page that
					// never landed. A rate limit is the case where that matters most: a
					// full-catalogue walk is exactly the traffic shape that trips the ceiling,
					// and dropping a page here would leave a hole nothing but the nightly
					// manifest ever fills.
					if ( self::was_rate_limited( $result ) ) {
						$this->retry_after_rate_limit(
							self::HOOK_PUSH_BATCH,
							self::batch_args( $phase, $offset, $attempt ),
							self::retry_after_of( $result )
						);
						return;
					}
					$this->retry( self::HOOK_PUSH_BATCH, self::batch_args( $phase, $offset, $attempt + 1 ), $attempt );
					return;
				}
				// What the backend actually did with the page — recorded before the cursor
				// advances, because "sent" and "stored" are different facts. A plan whose
				// memory quota is exhausted (or zero) answers a push with HTTP 200 and
				// `rejected: N`, and until this tally existed the walk read that as success:
				// it completed all phases and reported "52 items sent" for a catalogue the
				// backend had discarded in its entirety. The progress record now carries
				// both numbers so the completion copy can tell the merchant which happened.
				$this->tally_progress(
					(int) ( $result['accepted'] ?? 0 ),
					(int) ( $result['rejected'] ?? 0 )
				);

				// The plan's memory cap is exhausted (§3.6); further pages can only be
				// rejected, so stop the walk here rather than burn calls on them. The record
				// is closed as finished — before this, the early return left it `running`
				// with nothing to ever complete it, so the bar spun until the staleness
				// window aged it out fifteen minutes later.
				if ( true === ( $result['memory_limit_reached'] ?? false ) ) {
					$this->finish_progress();
					return;
				}
			}

			// Advance the cursor: next page of this phase while raw rows remain, else the
			// first page of the next phase.
			if ( true === ( $slice['has_more'] ?? false ) ) {
				$next = self::batch_args( $phase, $offset + self::BATCH_SIZE, 1 );
			} elseif ( $phase + 1 < count( self::PHASES ) ) {
				$next = self::batch_args( $phase + 1, 0, 1 );
			} else {
				$this->finish_progress();
				return; // Last phase drained — walk complete.
			}

			// Reported from the *next* cursor rather than the one just finished: `$offset` is
			// where this page started, so a walk that has completed page one of fifty would
			// otherwise report zero done. Recorded after the push succeeded, so a page that
			// is retrying does not advance the bar past content that has not landed.
			$this->record_progress( (int) ( $next['phase'] ?? 0 ), (int) ( $next['offset'] ?? 0 ) );

			$this->schedule( self::HOOK_PUSH_BATCH, array( $next ), $this->jitter() );
		} catch ( \Throwable $e ) {
			$this->retry( self::HOOK_PUSH_BATCH, self::batch_args( $phase, $offset, $attempt + 1 ), $attempt );
		}
	}

	/**
	 * Translate the walk's per-phase cursor into an absolute position and record it.
	 *
	 * Wrapped in its own try/catch: progress is a report *about* the walk, and a failure to
	 * write it must not fail the batch that was actually delivering content. The walk is the
	 * product; the bar is the narration.
	 *
	 * @param int $phase_index Index into `self::PHASES`.
	 * @param int $offset      The cursor within that phase.
	 */
	/**
	 * Add a batch's accepted/rejected counts to the record, never failing the walk over it.
	 *
	 * Same guard discipline as `record_progress()`/`finish_progress()`: this runs inside
	 * `run_push_batch()`'s try block, whose catch retries the page — a throw here would
	 * re-push content that already landed.
	 */
	private function tally_progress( int $accepted, int $rejected ): void {
		try {
			$this->progress->tally( $accepted, $rejected );
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Close the progress record, never letting that failure reach the walk.
	 *
	 * Separate from `record_progress()` only so the completion path reads as completion.
	 * The guard is the load-bearing part: this is called from *inside* `run_push_batch()`'s
	 * try block, whose catch schedules a retry — so an unguarded throw here would turn "the
	 * walk finished" into "the last page failed, run it again", re-pushing the final page
	 * on a loop for a bar nobody was watching.
	 */
	private function finish_progress(): void {
		try {
			$this->progress->finish();
		} catch ( \Throwable $e ) {
			return;
		}
	}

	private function record_progress( int $phase_index, int $offset ): void {
		try {
			$record = $this->progress->read();
			$counts = is_array( $record['counts'] ?? null ) ? $record['counts'] : array();
			if ( array() === $counts ) {
				return;
			}

			$phase = $phase_index >= 0 && $phase_index < count( self::PHASES )
				? self::PHASES[ $phase_index ]
				: '';

			$this->progress->advance(
				IndexingProgress::absolute( $counts, $phase, $offset ),
				$phase
			);
		} catch ( \Throwable $e ) {
			return;
		}
	}

	/**
	 * Nightly manifest-diff reconciliation and the re-push of whatever it asks for (§2.6).
	 */
	public function run_nightly_manifest(): void {
		try {
			$built  = $this->manifest()->build();
			$result = $this->pusher()->push_manifest( $built['manifest'] );
			if ( true !== ( $result['ok'] ?? false ) ) {
				// A rate limit is the one failure worth a same-day retry. Tomorrow is an
				// acceptable next attempt for an outage — the manifest is a reconciliation,
				// not a deadline — but a limit that clears in a minute should not cost the
				// store a day of unreconciled drift, and the backend has told us exactly
				// when to come back.
				if ( self::was_rate_limited( $result ) ) {
					$this->retry_after_rate_limit(
						self::HOOK_NIGHTLY_MANIFEST,
						array(),
						self::retry_after_of( $result )
					);
				}
				return; // Otherwise tomorrow's run is the next attempt; no tight retry here.
			}

			// The backend named the ids it needs a full copy of (missed creates/updates).
			// Push exactly those, from the map we already built — no second collection pass.
			$to_push = array();
			foreach ( $result['request_full'] as $object_id ) {
				if ( isset( $built['items'][ $object_id ] ) ) {
					$to_push[] = $built['items'][ $object_id ];
				}
			}
			if ( array() !== $to_push ) {
				$this->pusher()->push( $to_push );
			}
		} catch ( \Throwable $e ) {
			// Swallow: a nightly job must not surface a fatal, and the next run reconciles.
			return;
		}
	}

	// -- Recurring schedule (called by Lifecycle + the admin_init backstop) -------------

	/**
	 * Schedule the recurring nightly manifest job, idempotently.
	 *
	 * A one-hour up-front jitter keeps a fleet of stores from all reconciling at the same
	 * minute; Action Scheduler despreads too, but this also avoids the "first run fires in
	 * the next 60s" window for a store scheduling near midnight.
	 */
	public static function schedule_nightly(): void {
		if ( ! function_exists( 'as_schedule_recurring_action' ) || ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}
		if ( false !== as_next_scheduled_action( self::HOOK_NIGHTLY_MANIFEST, null, WAI_ACTION_SCHEDULER_GROUP ) ) {
			return;
		}
		$first_run = time() + HOUR_IN_SECONDS + wp_rand( 0, HOUR_IN_SECONDS );
		as_schedule_recurring_action(
			$first_run,
			DAY_IN_SECONDS,
			self::HOOK_NIGHTLY_MANIFEST,
			array(),
			WAI_ACTION_SCHEDULER_GROUP
		);
	}

	/** Unschedule the nightly job (deactivation / uninstall). */
	public static function unschedule_nightly(): void {
		if ( ! function_exists( 'as_unschedule_action' ) ) {
			return;
		}
		as_unschedule_action( self::HOOK_NIGHTLY_MANIFEST, array(), WAI_ACTION_SCHEDULER_GROUP );
	}

	// -- Internals ----------------------------------------------------------------------

	/**
	 * The pusher, lazily built so a test can inject a fake and production stays zero-arg.
	 */
	private function pusher(): ContentPusher {
		if ( null === $this->pusher ) {
			$this->pusher = new ContentPusher( $this->tokens );
		}
		return $this->pusher;
	}

	/** The collector, lazily built for the same reason as the pusher. */
	private function collector(): ContentSource {
		if ( null === $this->collector ) {
			$this->collector = new ContentCollector();
		}
		return $this->collector;
	}

	/** The manifest builder, lazily built for the same reason as the pusher. */
	private function manifest(): ManifestSource {
		if ( null === $this->manifest ) {
			$this->manifest = new ManifestBuilder();
		}
		return $this->manifest;
	}

	/**
	 * Reschedule a failed job with jittered exponential backoff, until the attempt cap.
	 *
	 * @param array<string, mixed> $next_args The args carrying the incremented attempt.
	 */
	private function retry( string $hook, array $next_args, int $attempt ): void {
		if ( $attempt >= self::MAX_ATTEMPTS ) {
			return; // The nightly manifest is the backstop for anything that never landed.
		}
		$backoff = min( self::MAX_BACKOFF, 30 * ( 2 ** ( $attempt - 1 ) ) ) + $this->jitter();
		$this->schedule( $hook, array( $next_args ), $backoff );
	}

	/**
	 * Reschedule a *rate-limited* job: the backend's own delay, and no attempt consumed.
	 *
	 * Two departures from `retry()`, both because a 429 is not a failure of this job.
	 *
	 * **The delay comes from the server.** The backoff ladder above is a guess at a number
	 * the backend has already told us — `Retry-After` is the exact second the window rolls
	 * over. Retrying earlier is guaranteed to be refused again, and every refusal spends an
	 * attempt on nothing.
	 *
	 * **The attempt counter does not advance.** `MAX_ATTEMPTS` exists so a job cannot hammer
	 * a *broken* backend forever; a rate limit is a healthy backend pacing us. Counting
	 * refusals against the cap meant a store that tripped the limit exhausted five attempts
	 * inside a few minutes and then dropped the content on the floor until the nightly
	 * manifest happened to notice — a catalogue sync silently losing pages because it was
	 * briefly told to slow down. The job is not making progress, but it is not failing
	 * either, and the two need different budgets.
	 *
	 * The nightly manifest remains the backstop if a store somehow stays limited forever,
	 * and `SubscriptionGate::is_rate_limited()` is what makes the condition visible to the
	 * merchant meanwhile.
	 *
	 * @param array<string, mixed> $same_args The args carrying the *unchanged* attempt.
	 */
	private function retry_after_rate_limit( string $hook, array $same_args, int $retry_after ): void {
		$delay = $retry_after > 0 ? $retry_after : self::MAX_BACKOFF;
		// Jitter on top of the server's number, not instead of it: a fleet-wide limit
		// synchronises every store's `Retry-After`, and retrying in lockstep the instant the
		// window rolls is how a rate limit becomes a self-sustaining one.
		$this->schedule( $hook, array( $same_args ), $delay + $this->jitter() );
	}

	/**
	 * Whether a pusher result failed *because* the backend rate-limited us.
	 *
	 * @param array<string, mixed> $result
	 */
	private static function was_rate_limited( array $result ): bool {
		return ContentPusher::ERROR_RATE_LIMITED === ( $result['error'] ?? '' );
	}

	/**
	 * The `Retry-After` seconds a pusher result carries, or 0.
	 *
	 * @param array<string, mixed> $result
	 */
	private static function retry_after_of( array $result ): int {
		$retry_after = $result['retry_after'] ?? 0;
		return is_numeric( $retry_after ) ? max( 0, (int) $retry_after ) : 0;
	}

	/**
	 * Schedule a single delayed action.
	 *
	 * @param array<int, array<string, mixed>> $args
	 */
	private function schedule( string $hook, array $args, int $delay ): void {
		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}
		as_schedule_single_action( time() + max( 0, $delay ), $hook, $args, WAI_ACTION_SCHEDULER_GROUP );
	}

	/**
	 * Whether an identical action is already pending, so an enqueue can dedup.
	 *
	 * @param array<int, array<string, mixed>> $args
	 */
	private function already_scheduled( string $hook, array $args ): bool {
		return function_exists( 'as_next_scheduled_action' )
			&& false !== as_next_scheduled_action( $hook, $args, WAI_ACTION_SCHEDULER_GROUP );
	}

	/** A small random spread so retries and chained batches do not thundering-herd. */
	private function jitter(): int {
		return function_exists( 'wp_rand' ) ? (int) wp_rand( 0, 30 ) : 0;
	}

	/** @return array<string, mixed> */
	private static function single_args( string $object_type, int $source_id, int $attempt ): array {
		return array(
			'object_type' => $object_type,
			'source_id'   => $source_id,
			'attempt'     => $attempt,
		);
	}

	/** @return array<string, mixed> */
	private static function delete_args( string $object_type, int $object_id, int $version, int $attempt ): array {
		return array(
			'object_type' => $object_type,
			'object_id'   => $object_id,
			'version'     => $version,
			'attempt'     => $attempt,
		);
	}

	/** @return array<string, mixed> */
	private static function batch_args( int $phase, int $offset, int $attempt ): array {
		return array(
			'phase'   => $phase,
			'offset'  => $offset,
			'attempt' => $attempt,
		);
	}
}
