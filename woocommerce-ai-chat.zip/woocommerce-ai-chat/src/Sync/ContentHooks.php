<?php
/**
 * WooCommerce content, stock, deletion, and site-URL hooks (`add-content-ingestion-kb §2.1,
 * §2.2, §2.4, §2.5`).
 *
 * The incremental supply side: when a merchant edits a product, changes stock, deletes an
 * item, or migrates the site URL, exactly one thing happens here — the changed item is
 * enqueued for a version-stamped push on Action Scheduler (`IngestionScheduler`) — never a
 * full re-push, and never a synchronous HTTP call (FR-007, D-13).
 *
 * **Every handler is wrapped in a try/catch that swallows (NFR-030).** A push failure, a
 * malformed object, a missing Action Scheduler — none of it may propagate into the
 * WooCommerce save that triggered the hook. The merchant's save must complete; the index
 * catches up on the job queue, and the nightly manifest reconciles anything that slipped.
 *
 * The hooks read through WooCommerce/WordPress identifiers only and hand ids to the
 * scheduler; the actual collection happens later, in the job, at which point the item's
 * current state is what gets pushed.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

final class ContentHooks {

	private IngestionQueue $scheduler;
	private PageFilter $pages;

	public function __construct( IngestionQueue $scheduler, ?PageFilter $pages = null ) {
		$this->scheduler = $scheduler;
		$this->pages     = $pages ?? new PageSelector();
	}

	/**
	 * Register every content/stock/deletion/site-URL hook.
	 *
	 * Product content and variation saves go through WooCommerce's CRUD hooks
	 * (`woocommerce_new_product` / `woocommerce_update_product`) rather than `save_post`, so
	 * the handler fires on HPOS-backed writes too.
	 */
	public function register(): void {
		// Product content (§2.1).
		add_action( 'woocommerce_new_product', array( $this, 'on_product_saved' ), 10, 1 );
		add_action( 'woocommerce_update_product', array( $this, 'on_product_saved' ), 10, 1 );
		add_action( 'woocommerce_new_product_variation', array( $this, 'on_variation_saved' ), 10, 1 );
		add_action( 'woocommerce_update_product_variation', array( $this, 'on_variation_saved' ), 10, 1 );

		// Stock (§2.1) — the three stock-specific hooks the spec names.
		add_action( 'woocommerce_product_set_stock', array( $this, 'on_product_stock' ), 10, 1 );
		add_action( 'woocommerce_variation_set_stock', array( $this, 'on_variation_stock' ), 10, 1 );
		add_action( 'woocommerce_reduce_order_stock', array( $this, 'on_order_stock' ), 10, 1 );

		// Key pages (§2.1) — the heuristic is applied before enqueuing (D-6).
		add_action( 'save_post_page', array( $this, 'on_page_saved' ), 10, 1 );

		// Categories (§2.1).
		add_action( 'created_product_cat', array( $this, 'on_category_saved' ), 10, 1 );
		add_action( 'edited_product_cat', array( $this, 'on_category_saved' ), 10, 1 );
		add_action( 'delete_product_cat', array( $this, 'on_category_deleted' ), 10, 1 );

		// Deletions (§2.4) — immediate tombstone, not deferred to nightly.
		add_action( 'woocommerce_trash_product', array( $this, 'on_product_removed' ), 10, 1 );
		add_action( 'woocommerce_delete_product', array( $this, 'on_product_removed' ), 10, 1 );
		add_action( 'wp_trash_post', array( $this, 'on_post_trashed' ), 10, 1 );
		add_action( 'before_delete_post', array( $this, 'on_post_deleted' ), 10, 1 );

		// Site URL change (§2.5) — permalinks and `sources` links must follow the domain.
		add_action( 'update_option_siteurl', array( $this, 'on_site_url_changed' ), 10, 2 );
		add_action( 'update_option_home', array( $this, 'on_site_url_changed' ), 10, 2 );
	}

	/**
	 * A product was created or updated: enqueue a single-item push.
	 *
	 * @param int|mixed $product_id
	 */
	public function on_product_saved( $product_id ): void {
		$this->safely(
			function () use ( $product_id ): void {
				$this->scheduler->enqueue_single( ContentCollector::TYPE_PRODUCT, (int) $product_id );
			}
		);
	}

	/**
	 * A variation changed: push its *parent* product, which is what carries the variant
	 * summary and aggregate availability in the index.
	 *
	 * @param int|mixed $variation_id
	 */
	public function on_variation_saved( $variation_id ): void {
		$this->safely(
			function () use ( $variation_id ): void {
				$parent = $this->parent_product_id( (int) $variation_id );
				if ( $parent > 0 ) {
					$this->scheduler->enqueue_single( ContentCollector::TYPE_PRODUCT, $parent );
				}
			}
		);
	}

	/**
	 * `woocommerce_product_set_stock` — the product object whose stock changed.
	 *
	 * @param \WC_Product|mixed $product
	 */
	public function on_product_stock( $product ): void {
		$this->safely(
			function () use ( $product ): void {
				$id = $this->product_id_of( $product );
				if ( $id > 0 ) {
					$this->scheduler->enqueue_single( ContentCollector::TYPE_PRODUCT, $id );
				}
			}
		);
	}

	/**
	 * `woocommerce_variation_set_stock` — a variation's stock changed; push the parent.
	 *
	 * @param \WC_Product_Variation|mixed $variation
	 */
	public function on_variation_stock( $variation ): void {
		$this->safely(
			function () use ( $variation ): void {
				$id     = $this->product_id_of( $variation );
				$parent = $id > 0 ? $this->parent_product_id( $id ) : 0;
				$target = $parent > 0 ? $parent : $id;
				if ( $target > 0 ) {
					$this->scheduler->enqueue_single( ContentCollector::TYPE_PRODUCT, $target );
				}
			}
		);
	}

	/**
	 * `woocommerce_reduce_order_stock` — an order reduced stock on its line items; push each
	 * affected product (deduplicated by the scheduler).
	 *
	 * @param \WC_Order|mixed $order
	 */
	public function on_order_stock( $order ): void {
		$this->safely(
			function () use ( $order ): void {
				if ( ! is_object( $order ) || ! method_exists( $order, 'get_items' ) ) {
					return;
				}
				$items = $order->get_items();
				if ( ! is_array( $items ) ) {
					return;
				}
				foreach ( $items as $line ) {
					if ( is_object( $line ) && method_exists( $line, 'get_product_id' ) ) {
						$product_id = (int) $line->get_product_id();
						if ( $product_id > 0 ) {
							$this->scheduler->enqueue_single( ContentCollector::TYPE_PRODUCT, $product_id );
						}
					}
				}
			}
		);
	}

	/**
	 * A page was saved: enqueue it only when it passes the key-page heuristic (D-6).
	 *
	 * A non-key page is skipped entirely — it never consumes memory-item quota. A *key* page
	 * that was just unpublished still enqueues; the job re-collects, finds it non-public, and
	 * pushes a delete, so unpublishing a key page cleans it out of the index.
	 *
	 * @param int|mixed $post_id
	 */
	public function on_page_saved( $post_id ): void {
		$this->safely(
			function () use ( $post_id ): void {
				$post_id = (int) $post_id;
				if ( $post_id <= 0 || $this->is_autosave_or_revision( $post_id ) ) {
					return;
				}
				if ( $this->pages->should_collect( $post_id ) ) {
					$this->scheduler->enqueue_single( ContentCollector::TYPE_PAGE, $post_id );
				}
			}
		);
	}

	/**
	 * A product category was created or edited.
	 *
	 * @param int|mixed $term_id
	 */
	public function on_category_saved( $term_id ): void {
		$this->safely(
			function () use ( $term_id ): void {
				$this->scheduler->enqueue_single( ContentCollector::TYPE_CATEGORY, (int) $term_id );
			}
		);
	}

	/**
	 * A product category was deleted: tombstone it immediately (§2.4).
	 *
	 * @param int|mixed $term_id
	 */
	public function on_category_deleted( $term_id ): void {
		$this->safely(
			function () use ( $term_id ): void {
				$this->enqueue_delete( ContentCollector::TYPE_CATEGORY, (int) $term_id );
			}
		);
	}

	/**
	 * A product was trashed or permanently deleted: immediate tombstone (§2.4, FR-037).
	 *
	 * @param int|mixed $product_id
	 */
	public function on_product_removed( $product_id ): void {
		$this->safely(
			function () use ( $product_id ): void {
				$this->enqueue_delete( ContentCollector::TYPE_PRODUCT, (int) $product_id );
			}
		);
	}

	/**
	 * A post was trashed: if it is a page, tombstone it (§2.4).
	 *
	 * @param int|mixed $post_id
	 */
	public function on_post_trashed( $post_id ): void {
		$this->safely(
			function () use ( $post_id ): void {
				if ( 'page' === get_post_type( (int) $post_id ) ) {
					$this->enqueue_delete( ContentCollector::TYPE_PAGE, (int) $post_id );
				}
			}
		);
	}

	/**
	 * A post is about to be permanently deleted: if it is a page, tombstone it (§2.4).
	 *
	 * @param int|mixed $post_id
	 */
	public function on_post_deleted( $post_id ): void {
		$this->safely(
			function () use ( $post_id ): void {
				if ( 'page' === get_post_type( (int) $post_id ) ) {
					$this->enqueue_delete( ContentCollector::TYPE_PAGE, (int) $post_id );
				}
			}
		);
	}

	/**
	 * The site or home URL changed (e.g. staging → production): trigger a full re-push so
	 * stored permalinks and `sources` links match the live domain (§2.5, FR-093).
	 *
	 * @param mixed $old_value
	 * @param mixed $new_value
	 */
	public function on_site_url_changed( $old_value, $new_value ): void {
		$this->safely(
			function () use ( $old_value, $new_value ): void {
				if ( (string) $old_value !== (string) $new_value ) {
					$this->scheduler->enqueue_full_resync();
				}
			}
		);
	}

	// -- Internals ----------------------------------------------------------------------

	/**
	 * Compute the namespaced `object_id` for a raw id and enqueue its delete with a
	 * this-moment tombstone version.
	 */
	private function enqueue_delete( string $object_type, int $source_id ): void {
		if ( $source_id <= 0 ) {
			return;
		}
		$this->scheduler->enqueue_delete(
			$object_type,
			ContentCollector::encode_object_id( $object_type, $source_id ),
			time()
		);
	}

	/**
	 * Read a product/variation id from either an id or a WC object.
	 *
	 * @param \WC_Product|int|mixed $product
	 */
	private function product_id_of( $product ): int {
		if ( is_numeric( $product ) ) {
			return (int) $product;
		}
		if ( is_object( $product ) && method_exists( $product, 'get_id' ) ) {
			return (int) $product->get_id();
		}
		return 0;
	}

	/**
	 * The parent product id for a variation id, or 0 when it is not a variation (a simple
	 * product is its own parent for our purposes and the caller already has that id).
	 */
	private function parent_product_id( int $variation_id ): int {
		if ( $variation_id <= 0 || ! function_exists( 'wc_get_product' ) ) {
			return 0;
		}
		$variation = wc_get_product( $variation_id );
		if ( is_object( $variation ) && method_exists( $variation, 'get_parent_id' ) ) {
			return (int) $variation->get_parent_id();
		}
		return 0;
	}

	/** Whether a save is an autosave or a revision, which must not trigger a push. */
	private function is_autosave_or_revision( int $post_id ): bool {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return true;
		}
		return function_exists( 'wp_is_post_revision' ) && false !== wp_is_post_revision( $post_id );
	}

	/**
	 * Run a handler body, guaranteeing nothing escapes into the WooCommerce save flow
	 * (§2.2, NFR-030).
	 */
	private function safely( callable $handler ): void {
		try {
			$handler();
		} catch ( \Throwable $e ) {
			// Deliberately swallowed: a push-scheduling failure must never break a merchant's
			// save. The nightly manifest (§2.6) reconciles whatever this missed.
			return;
		}
	}
}
