<?php
/**
 * The enqueue seam (`add-content-ingestion-kb §2.3, §6.4`).
 *
 * `IngestionScheduler` is `final` for the same reason `TokenStorage` is: it is the one
 * class that touches Action Scheduler, and keeping it unextendable makes "what schedules
 * work?" a grep rather than a class-hierarchy walk. But `ContentHooks` has a behaviour that
 * must be asserted directly — that a *failing* enqueue never propagates into the WooCommerce
 * save (NFR-030, §6.4) — and asserting it needs a collaborator that can be made to fail.
 *
 * So `ContentHooks` depends on this interface instead. It names only the three enqueue
 * methods the hook layer actually calls, which also documents the seam: the hooks enqueue
 * work and never run it, never push, and never touch Action Scheduler directly.
 *
 * `IngestionScheduler` remains the sole implementation, and remains final.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

/**
 * Enqueue access to the ingestion job queue.
 */
interface IngestionQueue {

	/** Enqueue a re-collect-and-push for one changed item (§2.1). */
	public function enqueue_single( string $object_type, int $source_id ): void;

	/**
	 * Enqueue an immediate tombstone for one item (§2.4).
	 *
	 * @param int $object_id The *namespaced* id the push stored the item under.
	 * @param int $version   The tombstone version (last-writer-wins).
	 */
	public function enqueue_delete( string $object_type, int $object_id, int $version ): void;

	/** Kick off a cursor-resumable full re-push (§2.3/§2.5). */
	public function enqueue_full_resync(): void;
}
