<?php
/**
 * Daily subscription-check Action Scheduler job (`add-foundation-onboarding §5.1`).
 *
 * Scheduled by `Lifecycle::activate()` in group `wc_ai_agent` (TR-020); the hook fires
 * once per day, refreshed against the backend, and the gate's cache is the result.
 *
 * Notes:
 * - The job is the **only** thing that refreshes the state in steady state; activation
 *   also refreshes once, the wizard also refreshes once, but the daily job is the
 *   mechanism that keeps the merchant's dashboard pill honest without requiring them to
 *   visit.
 * - `ActionScheduler_QueueRunner` runs jobs in-process under WP-CLI or via the
 *   recurring "spawn on admin hit" loop. Both are AS's concern; we just register the
 *   hook callback here and let AS dispatch.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

use WooAIChat\Auth\SubscriptionGate;

final class SubscriptionCheckJob {

	private SubscriptionGate $gate;

	public function __construct( SubscriptionGate $gate ) {
		$this->gate = $gate;
	}

	/**
	 * Register the `wcai_subscription_check` Action Scheduler hook callback and the
	 * admin-init backstop (the "AS is not running" case from FR-042). The backstop
	 * refreshes from any admin hit *if* the gate's cache is older than the daily
	 * interval — that means a hosted WordPress instance whose AS loop is silent still
	 * gets a refresh the first time the merchant opens the admin for the day, rather
	 * than surfacing a stale pill.
	 */
	public function register(): void {
		add_action( 'wcai_subscription_check', array( $this, 'run' ) );

		add_action( 'admin_init', array( $this, 'maybe_refresh_on_admin' ) );
	}

	/**
	 * AS hook callback. Fires the gate refresh with `force=true` because the daily job
	 * is the canonical refresh path and must not respect the in-process throttle.
	 */
	public function run(): void {
		$this->refresh_guarded();
	}

	/**
	 * Backstop for a hosting setup where AS does not run (FR-042 names this; the
	 * Health Check page landed in `add-merchant-insight-ops`). Here, we only fire the
	 * refresh if the cache is older than the refresh interval — the actual warning
	 * path lives in the merchant ops epic.
	 */
	public function maybe_refresh_on_admin(): void {
		$state      = $this->gate->cached_state();
		$now        = time();
		$checked_at = is_int( $state['checked_at'] ?? null ) ? (int) $state['checked_at'] : 0;
		if ( 0 === $checked_at || ( $now - $checked_at ) > SubscriptionGate::CACHE_TTL ) {
			$this->refresh_guarded();
		}
	}

	/**
	 * The refresh, with the misconfiguration case contained.
	 *
	 * `BackendClient::require_base_url()` throws `RuntimeException` when
	 * `WAI_BACKEND_URL` is undefined or non-HTTPS. On an *activated* store this job's
	 * `admin_init` backstop reaches that throw on every single admin page — and
	 * `admin_init` fires before `admin_notices`, so the uncaught exception white-screened
	 * the whole `/wp-admin` before `Compatibility::backend_url_ok()`'s notice (written
	 * for exactly this misconfiguration) could ever render. Swallowing the throw here
	 * lets the page finish loading; the gate then serves its last-known state, and the
	 * compatibility notice on that same page load is what tells the merchant what to fix.
	 */
	private function refresh_guarded(): void {
		try {
			$this->gate->refresh( true );
		} catch ( \RuntimeException $e ) {
			// Misconfigured backend URL. The notice path owns the messaging; a refresh
			// that cannot even be attempted must degrade to last-known, not to a fatal.
			unset( $e );
		}
	}
}
