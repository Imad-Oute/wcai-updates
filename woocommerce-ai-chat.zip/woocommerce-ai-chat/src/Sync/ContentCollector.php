<?php
/**
 * Content collection + hashing (`add-content-ingestion-kb §1.1, §1.2, §1.3`).
 *
 * Turns WooCommerce/WordPress content into the `PushItem` shape the backend's
 * `/v1/index/push` contract defines. The plugin is a thin client (D1): it emits raw text
 * plus a hash and nothing else — no chunking, no embedding, no vector anything.
 *
 * Three responsibilities, deliberately in one class because they are one decision:
 *
 * - **Collect** (§1.1) products, non-empty categories, key pages, and store identity,
 *   reading through WooCommerce CRUD (`wc_get_product`, `$product->get_*`) rather than
 *   `get_post_meta`. CRUD is what makes this HPOS-safe: it resolves whichever storage
 *   backend the store runs, where raw meta reads assume the legacy post tables.
 * - **Exclude** (§1.2) draft/private/password-protected/hidden items and empty
 *   categories, so nothing non-public reaches the index. A shopper must never be told
 *   about a draft product.
 * - **Hash** (§1.3) the serialized content with SHA-256 so the backend can skip
 *   re-embedding unchanged items (FR-031).
 *
 * **The hash covers exactly the `content` string that is pushed** — not the source
 * objects, not a field subset. The backend compares `content_hash` byte-for-byte to
 * decide whether to re-embed, so any field that can change the content must be inside
 * the hashed string, and anything volatile (timestamps, request ids) must be outside it,
 * or every push would look changed and re-embed the whole catalogue.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Sync;

final class ContentCollector implements ContentSource {

	/** Object types, matching the backend's `ObjectType` enum. */
	public const TYPE_PRODUCT  = 'product';
	public const TYPE_CATEGORY = 'category';
	public const TYPE_PAGE     = 'page';

	/**
	 * Offsets that keep `object_id` unique *across types* within a store.
	 *
	 * The backend stores items under `(store_id, object_type, object_id)`, but the nightly
	 * manifest contract (`ManifestItem`) carries `object_id` **only** — no `object_type`.
	 * Its reconciliation therefore assumes one `object_id` never denotes two different
	 * items. WordPress does not honour that assumption: post IDs and term IDs are
	 * independent sequences, so a category and a page routinely share an id (this is not
	 * exotic — it happens on a store with five pages).
	 *
	 * Left uncorrected, two things break in the nightly diff:
	 *   - the tombstone pass deletes by `(store_id, object_id)` with no type, so dropping
	 *     one of the pair removes the other's chunks too;
	 *   - the unchanged check matches a hash against *any* row under that id, so one
	 *     type's hash can mask the other's change.
	 *
	 * Namespacing the id space here fixes it from the plugin side without a contract
	 * change. Products keep their true ID (the common case, and the one worth being able
	 * to eyeball in logs); categories and pages are offset far above any plausible post
	 * ID. `decode_object_id()` inverts this for anything that needs the original.
	 */
	private const ID_OFFSET_CATEGORY = 2000000000;
	private const ID_OFFSET_PAGE     = 1000000000;

	private PageSelector $pages;

	public function __construct( ?PageSelector $pages = null ) {
		$this->pages = $pages ?? new PageSelector();
	}

	/**
	 * Collect everything eligible for the index — the onboarding full collection.
	 *
	 * Ordered products → categories → pages so a partially-completed run still indexes
	 * the highest-value content first (products answer most shopper questions).
	 *
	 * @return array<int, array<string, mixed>> `PushItem`-shaped rows.
	 */
	public function collect_all(): array {
		return array_merge(
			$this->collect_products(),
			$this->collect_categories(),
			$this->collect_pages()
		);
	}

	/**
	 * Collect all publishable products (§1.1) minus the default exclusions (§1.2).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function collect_products(): array {
		// `wc_get_products` with `status: publish` filters drafts/private at the query
		// level; the per-item guard in `collect_product` still runs because visibility
		// and password protection are not query-expressible.
		$products = wc_get_products(
			array(
				'status' => 'publish',
				'limit'  => -1,
				'return' => 'objects',
			)
		);
		if ( ! is_array( $products ) ) {
			return array();
		}

		$items = array();
		foreach ( $products as $product ) {
			$item = $this->collect_product( $product );
			if ( null !== $item ) {
				$items[] = $item;
			}
		}
		return $items;
	}

	/**
	 * Serialize one product, or null when it must be excluded (§1.2).
	 *
	 * @param \WC_Product|mixed $product A WooCommerce product object.
	 * @return array<string, mixed>|null
	 */
	public function collect_product( $product ): ?array {
		if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return null;
		}
		if ( ! $this->is_product_indexable( $product ) ) {
			return null;
		}

		$content = $this->product_content( $product );
		if ( trim( $content ) === '' ) {
			return null;
		}

		return $this->make_item(
			self::TYPE_PRODUCT,
			(int) $product->get_id(),
			$content,
			array(
				'permalink' => $this->safe_call( $product, 'get_permalink', '' ),
				'title'     => $this->plain_name( (string) $this->safe_call( $product, 'get_name', '' ) ),
				'sku'       => $this->safe_call( $product, 'get_sku', '' ),
			)
		);
	}

	/**
	 * Default exclusions (§1.2, FR-032): draft/private status, password protection, and
	 * `catalog_visibility = hidden`.
	 *
	 * Hidden is included here rather than left to the query because a merchant uses it to
	 * mean "not part of my catalogue" — surfacing such a product in a chat answer would
	 * contradict an explicit merchant decision.
	 *
	 * @param \WC_Product|mixed $product
	 */
	public function is_product_indexable( $product ): bool {
		$status = (string) $this->safe_call( $product, 'get_status', '' );
		if ( 'publish' !== $status ) {
			return false;
		}
		// A password on the post means the content is gated from the public; the assistant
		// must not repeat gated content to an anonymous shopper.
		$password = (string) $this->safe_call( $product, 'get_post_password', '' );
		if ( '' !== $password ) {
			return false;
		}
		$visibility = (string) $this->safe_call( $product, 'get_catalog_visibility', 'visible' );
		if ( 'hidden' === $visibility ) {
			return false;
		}
		return true;
	}

	/**
	 * Flatten a product into the text the backend will chunk and embed.
	 *
	 * Field order is fixed and label-prefixed. Fixed order is what makes the SHA-256 hash
	 * stable — reordering fields would change the hash without the content changing and
	 * force a needless re-embed. The labels survive chunking, so a chunk split mid-product
	 * still carries "Price:" next to the number and stays interpretable in isolation.
	 *
	 * @param \WC_Product|mixed $product
	 */
	public function product_content( $product ): string {
		$parts = array();

		$parts[] = 'Product: ' . $this->plain_name( (string) $this->safe_call( $product, 'get_name', '' ) );

		$sku = (string) $this->safe_call( $product, 'get_sku', '' );
		if ( '' !== $sku ) {
			$parts[] = 'SKU: ' . $sku;
		}

		$short = $this->plain_text( (string) $this->safe_call( $product, 'get_short_description', '' ) );
		if ( '' !== $short ) {
			$parts[] = 'Summary: ' . $short;
		}
		$desc = $this->plain_text( (string) $this->safe_call( $product, 'get_description', '' ) );
		if ( '' !== $desc ) {
			$parts[] = 'Description: ' . $desc;
		}

		$price = $this->price_text( $product );
		if ( '' !== $price ) {
			$parts[] = 'Price: ' . $price;
		}

		$parts[] = 'Availability: ' . $this->stock_text( $product );

		$delivery = $this->delivery_text( $product );
		if ( '' !== $delivery ) {
			$parts[] = 'Delivery: ' . $delivery;
		}

		$categories = $this->term_names( (int) $this->safe_call( $product, 'get_id', 0 ), 'product_cat' );
		if ( array() !== $categories ) {
			$parts[] = 'Categories: ' . implode( ', ', $categories );
		}
		$tags = $this->term_names( (int) $this->safe_call( $product, 'get_id', 0 ), 'product_tag' );
		if ( array() !== $tags ) {
			$parts[] = 'Tags: ' . implode( ', ', $tags );
		}

		$attributes = $this->attribute_text( $product );
		if ( '' !== $attributes ) {
			$parts[] = 'Attributes: ' . $attributes;
		}

		$variants = $this->variant_summary( $product );
		if ( '' !== $variants ) {
			$parts[] = 'Variants: ' . $variants;
		}

		return implode( "\n", $parts );
	}

	/**
	 * Collect non-empty product categories (§1.1/§1.2).
	 *
	 * `hide_empty => true` is the FR-032 "empty categories excluded" rule expressed at the
	 * query level: a category with no products has nothing to say about the catalogue.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function collect_categories(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => true,
			)
		);
		if ( ! is_array( $terms ) ) {
			return array();
		}

		$items = array();
		foreach ( $terms as $term ) {
			$item = $this->collect_category( $term );
			if ( null !== $item ) {
				$items[] = $item;
			}
		}
		return $items;
	}

	/**
	 * Serialize one product category, or null when it must be excluded (empty category,
	 * FR-032).
	 *
	 * Extracted from `collect_categories` so the `edited_product_cat` hook handler (§2.1)
	 * and the manifest builder (§2.6) can serialize a single term through the identical
	 * path the bulk collection uses.
	 *
	 * @param \WP_Term|mixed $term A `product_cat` term.
	 * @return array<string, mixed>|null
	 */
	public function collect_category( $term ): ?array {
		if ( ! is_object( $term ) || ! isset( $term->term_id ) ) {
			return null;
		}
		// Empty categories are excluded (FR-032). `hide_empty` handles this at the query
		// level for the bulk path, but the single-term path (a hook re-collect) has no
		// query to lean on, so the rule lives here too.
		if ( isset( $term->count ) && 0 === (int) $term->count ) {
			return null;
		}

		$parts = array( 'Category: ' . $this->plain_name( (string) ( $term->name ?? '' ) ) );
		$desc  = $this->plain_text( (string) ( $term->description ?? '' ) );
		if ( '' !== $desc ) {
			$parts[] = 'Description: ' . $desc;
		}
		$parts[] = 'Products in category: ' . (string) ( $term->count ?? 0 );

		return $this->make_item(
			self::TYPE_CATEGORY,
			self::ID_OFFSET_CATEGORY + (int) $term->term_id,
			implode( "\n", $parts ),
			array(
				'title'     => $this->plain_name( (string) ( $term->name ?? '' ) ),
				'source_id' => (int) $term->term_id,
			)
		);
	}

	/**
	 * Collect key pages, filtered by the D-6 heuristic (§1.1a).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function collect_pages(): array {
		$pages = get_posts(
			array(
				'post_type'   => 'page',
				'post_status' => 'publish',
				'numberposts' => -1,
			)
		);
		if ( ! is_array( $pages ) ) {
			return array();
		}

		$items = array();
		foreach ( $pages as $page ) {
			$item = $this->collect_page( $page );
			if ( null !== $item ) {
				$items[] = $item;
			}
		}
		return $items;
	}

	/**
	 * Serialize one page, or null when the heuristic or exclusions reject it.
	 *
	 * Also used by the `save_post_page` hook handler (§2.1), which is why the selection
	 * decision lives here rather than only in the bulk loop — the hook must apply the
	 * identical rule (D-6).
	 *
	 * @param \WP_Post|mixed $page
	 * @return array<string, mixed>|null
	 */
	public function collect_page( $page ): ?array {
		if ( ! is_object( $page ) || ! isset( $page->ID ) ) {
			return null;
		}
		if ( ( $page->post_status ?? '' ) !== 'publish' ) {
			return null;
		}
		if ( (string) ( $page->post_password ?? '' ) !== '' ) {
			return null;
		}
		if ( ! $this->pages->should_collect( (int) $page->ID ) ) {
			return null;
		}

		$body = $this->plain_text( (string) ( $page->post_content ?? '' ) );
		if ( '' === $body ) {
			return null;
		}

		$content = 'Page: ' . (string) ( $page->post_title ?? '' ) . "\n" . $body;

		return $this->make_item(
			self::TYPE_PAGE,
			self::ID_OFFSET_PAGE + (int) $page->ID,
			$content,
			array(
				'permalink' => get_permalink( (int) $page->ID ),
				'title'     => $this->plain_name( (string) ( $page->post_title ?? '' ) ),
				'source_id' => (int) $page->ID,
			)
		);
	}

	/**
	 * Store identity (§1.1) — name, description, and contact/currency basics.
	 *
	 * Pushed as a `page` item under a reserved id because the backend's `ObjectType` has
	 * no `store` member. It sits in the page namespace at offset + 0; no WordPress post
	 * has ID 0, so the slot cannot collide with a real page.
	 *
	 * @return array<string, mixed>
	 */
	public function collect_store_identity(): array {
		$parts   = array(
			'Store: ' . (string) get_bloginfo( 'name' ),
		);
		$tagline = $this->plain_text( (string) get_bloginfo( 'description' ) );
		if ( '' !== $tagline ) {
			$parts[] = 'About: ' . $tagline;
		}
		$parts[] = 'Website: ' . (string) home_url();

		if ( function_exists( 'get_woocommerce_currency' ) ) {
			$parts[] = 'Currency: ' . (string) get_woocommerce_currency();
		}
		$email = (string) get_option( 'woocommerce_email_from_address' );
		if ( '' !== $email ) {
			$parts[] = 'Contact email: ' . $email;
		}

		return $this->make_item(
			self::TYPE_PAGE,
			self::ID_OFFSET_PAGE,
			implode( "\n", $parts ),
			array(
				'title' => $this->plain_name( (string) get_bloginfo( 'name' ) ),
				'kind'  => 'store_identity',
			)
		);
	}

	/**
	 * Collect a single item by type and its source (WordPress/WooCommerce) id.
	 *
	 * The incremental hook handlers (§2.1) re-collect the one changed item at job-run time
	 * rather than passing its content through the Action Scheduler arg table: the args stay
	 * small identifiers, and the pushed content reflects the item's state when the job runs
	 * (which is what the version stamp then dates for last-writer-wins, D-3).
	 *
	 * Returns null when the item no longer exists or is no longer indexable — a product
	 * unpublished between the hook firing and the job running, a page that flips outside the
	 * key-page heuristic. The caller reads null as "remove it from the index" and pushes a
	 * delete instead (§2.1/§2.4).
	 *
	 * @param string $object_type One of the `TYPE_*` constants.
	 * @param int    $source_id   The raw post/term id (not the namespaced `object_id`).
	 * @return array<string, mixed>|null
	 */
	public function collect_by_type( string $object_type, int $source_id ): ?array {
		if ( self::TYPE_PRODUCT === $object_type ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $source_id ) : null;
			return is_object( $product ) ? $this->collect_product( $product ) : null;
		}
		if ( self::TYPE_CATEGORY === $object_type ) {
			$term = get_term( $source_id, 'product_cat' );
			if ( ! is_object( $term ) || is_wp_error( $term ) ) {
				return null;
			}
			return $this->collect_category( $term );
		}
		if ( self::TYPE_PAGE === $object_type ) {
			$post = get_post( $source_id );
			return is_object( $post ) ? $this->collect_page( $post ) : null;
		}
		return null;
	}

	/**
	 * One page of a collection phase, for the cursor-resumable full push (§2.3).
	 *
	 * `has_more` is computed from the *raw* row count the query returned, not from the
	 * number of items that survived exclusion — a page of 50 products where 10 are hidden
	 * returns 40 items but there may still be more products, and paging on the surviving
	 * count would silently stop the walk on the first heavily-filtered page.
	 *
	 * @param string $phase  One of the `TYPE_*` constants.
	 * @param int    $offset Row offset into that phase.
	 * @param int    $limit  Page size.
	 * @return array{items: array<int, array<string, mixed>>, has_more: bool}
	 */
	public function collect_slice( string $phase, int $offset, int $limit ): array {
		if ( self::TYPE_PRODUCT === $phase ) {
			return $this->collect_products_slice( $offset, $limit );
		}
		if ( self::TYPE_CATEGORY === $phase ) {
			return $this->collect_categories_slice( $offset, $limit );
		}
		if ( self::TYPE_PAGE === $phase ) {
			return $this->collect_pages_slice( $offset, $limit );
		}
		return array(
			'items'    => array(),
			'has_more' => false,
		);
	}

	/**
	 * How many rows each phase will walk, for the re-index progress report (§5.5).
	 *
	 * Counts the *raw* rows the slice queries page over, using the same criteria — not the
	 * items that survive exclusion — because that is what the cursor advances through. A
	 * total derived from surviving items would disagree with the cursor it is compared
	 * against, and the bar would stall short of full on any store with hidden products.
	 *
	 * These are three cheap COUNT-shaped reads, run once when a re-sync is queued rather
	 * than per batch. An error from any of them counts as zero for that phase rather than
	 * failing the whole report: a progress bar is not worth breaking a re-index over.
	 *
	 * @return array{product: int, category: int, page: int, total: int}
	 */
	public function count_all(): array {
		$counts = array(
			self::TYPE_PRODUCT  => 0,
			self::TYPE_CATEGORY => 0,
			self::TYPE_PAGE     => 0,
		);

		try {
			if ( function_exists( 'wc_get_products' ) ) {
				$products                     = wc_get_products(
					array(
						'status' => 'publish',
						'limit'  => -1,
						'return' => 'ids',
					)
				);
				$counts[ self::TYPE_PRODUCT ] = is_array( $products ) ? count( $products ) : 0;
			}
		} catch ( \Throwable $e ) {
			$counts[ self::TYPE_PRODUCT ] = 0;
		}

		$terms                         = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => true,
				'fields'     => 'ids',
			)
		);
		$counts[ self::TYPE_CATEGORY ] = is_array( $terms ) ? count( $terms ) : 0;

		$pages                     = get_posts(
			array(
				'post_type'   => 'page',
				'post_status' => 'publish',
				'numberposts' => -1,
				'fields'      => 'ids',
			)
		);
		$counts[ self::TYPE_PAGE ] = is_array( $pages ) ? count( $pages ) : 0;

		return array(
			'product'  => $counts[ self::TYPE_PRODUCT ],
			'category' => $counts[ self::TYPE_CATEGORY ],
			'page'     => $counts[ self::TYPE_PAGE ],
			'total'    => $counts[ self::TYPE_PRODUCT ] + $counts[ self::TYPE_CATEGORY ] + $counts[ self::TYPE_PAGE ],
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>, has_more: bool}
	 */
	private function collect_products_slice( int $offset, int $limit ): array {
		$products = wc_get_products(
			array(
				'status'  => 'publish',
				'limit'   => $limit,
				'offset'  => $offset,
				'orderby' => 'ID',
				'order'   => 'ASC',
				'return'  => 'objects',
			)
		);
		if ( ! is_array( $products ) ) {
			return array(
				'items'    => array(),
				'has_more' => false,
			);
		}

		$items = array();
		foreach ( $products as $product ) {
			$item = $this->collect_product( $product );
			if ( null !== $item ) {
				$items[] = $item;
			}
		}
		return array(
			'items'    => $items,
			'has_more' => count( $products ) === $limit,
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>, has_more: bool}
	 */
	private function collect_categories_slice( int $offset, int $limit ): array {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => true,
				'number'     => $limit,
				'offset'     => $offset,
				'orderby'    => 'term_id',
				'order'      => 'ASC',
			)
		);
		if ( ! is_array( $terms ) ) {
			return array(
				'items'    => array(),
				'has_more' => false,
			);
		}

		$items = array();
		foreach ( $terms as $term ) {
			$item = $this->collect_category( $term );
			if ( null !== $item ) {
				$items[] = $item;
			}
		}
		return array(
			'items'    => $items,
			'has_more' => count( $terms ) === $limit,
		);
	}

	/**
	 * @return array{items: array<int, array<string, mixed>>, has_more: bool}
	 */
	private function collect_pages_slice( int $offset, int $limit ): array {
		$pages = get_posts(
			array(
				'post_type'   => 'page',
				'post_status' => 'publish',
				'numberposts' => $limit,
				'offset'      => $offset,
				'orderby'     => 'ID',
				'order'       => 'ASC',
			)
		);
		if ( ! is_array( $pages ) ) {
			return array(
				'items'    => array(),
				'has_more' => false,
			);
		}

		$items = array();
		foreach ( $pages as $page ) {
			$item = $this->collect_page( $page );
			if ( null !== $item ) {
				$items[] = $item;
			}
		}
		return array(
			'items'    => $items,
			'has_more' => count( $pages ) === $limit,
		);
	}

	/**
	 * Namespace a raw post/term id into the pushed `object_id` space.
	 *
	 * The inverse of `decode_object_id`, needed by the delete path (§2.4): a hook fires with
	 * a raw id, and the delete must address the item under the same namespaced id the push
	 * stored it under.
	 */
	public static function encode_object_id( string $object_type, int $source_id ): int {
		if ( self::TYPE_CATEGORY === $object_type ) {
			return $source_id + self::ID_OFFSET_CATEGORY;
		}
		if ( self::TYPE_PAGE === $object_type ) {
			return $source_id + self::ID_OFFSET_PAGE;
		}
		return $source_id;
	}

	/**
	 * Recover the WordPress/WooCommerce id from a pushed `object_id`.
	 *
	 * The inverse of the namespacing above. The Knowledge Base page (§5) needs this to map
	 * a backend-reported item back to an editable post or term.
	 *
	 * @return int The original post/term ID (0 for the store-identity item).
	 */
	public static function decode_object_id( string $object_type, int $object_id ): int {
		if ( self::TYPE_CATEGORY === $object_type ) {
			return $object_id - self::ID_OFFSET_CATEGORY;
		}
		if ( self::TYPE_PAGE === $object_type ) {
			return $object_id - self::ID_OFFSET_PAGE;
		}
		return $object_id;
	}

	/**
	 * SHA-256 of the exact content string (§1.3, FR-031).
	 *
	 * Hex-encoded lowercase to satisfy the contract's `^[a-f0-9]{64}$` pattern.
	 */
	public function hash( string $content ): string {
		return hash( 'sha256', $content );
	}

	/**
	 * Assemble a `PushItem`-shaped row.
	 *
	 * `version` is a Unix timestamp: the backend uses it for last-writer-wins (D-3), so it
	 * only has to increase monotonically for a given item. Wall-clock time does that
	 * across separate requests without needing a stored counter per item.
	 *
	 * @param array<string, mixed> $meta
	 * @return array<string, mixed>
	 */
	private function make_item( string $type, int $object_id, string $content, array $meta = array() ): array {
		$content = $this->normalize( $content );
		return array(
			'object_type'  => $type,
			'object_id'    => $object_id,
			'content'      => $content,
			'content_hash' => $this->hash( $content ),
			'version'      => time(),
			'meta'         => array_filter(
				$meta,
				static fn( $v ) => '' !== $v && null !== $v && false !== $v
			),
			'source'       => 'auto',
		);
	}

	/**
	 * Collapse whitespace so trivial editor churn does not change the hash.
	 *
	 * Without this, a merchant adding a blank line in the editor would produce a new hash,
	 * a re-embed, and a bill for tokens on content that reads identically.
	 */
	private function normalize( string $text ): string {
		$text = str_replace( array( "\r\n", "\r" ), "\n", $text );
		$text = preg_replace( '/[ \t]+/', ' ', $text ) ?? $text;
		$text = preg_replace( '/\n{3,}/', "\n\n", $text ) ?? $text;
		return trim( $text );
	}

	/**
	 * Strip shortcodes/HTML and decode entities into plain text for embedding.
	 *
	 * `strip_shortcodes()` only removes shortcodes that are *registered in the current
	 * process*, which is the wrong set here: this runs under Action Scheduler and WP-CLI,
	 * where the theme and most page-builder plugins never register theirs. Relying on it
	 * alone embeds literal `[vc_row]` / `[et_pb_section]` markup from builder-authored
	 * pages and retrieves it back as answer text. So the registered pass runs first (it
	 * correctly unwraps enclosing shortcodes like `[tab]content[/tab]`), then a regex
	 * sweeps whatever tags remain.
	 */
	/**
	 * A name or title, with stored HTML entities decoded.
	 *
	 * WordPress stores names it sanitised on the way in — a category created as
	 * "Vases & Candles" sits in the terms table as "Vases &amp; Candles", and product or
	 * page titles can carry the same. Descriptions were already covered because
	 * `plain_text()` ends in `html_entity_decode`, but every *name* went into the pushed
	 * item raw. The cost was in both directions: the Knowledge Base page displayed the
	 * literal "&amp;" (its renderer builds text nodes, which is correct — the payload was
	 * wrong), and the embedded chunk text itself carried "Category: Vases &amp; Candles",
	 * gibberish tokens the shopper's query never contains.
	 */
	private function plain_name( string $name ): string {
		return html_entity_decode( $name, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}

	private function plain_text( string $html ): string {
		if ( '' === $html ) {
			return '';
		}
		$text = strip_shortcodes( $html );
		// Remaining `[tag]`, `[/tag]`, `[tag attr="x"]` from shortcodes not registered in
		// this process. The trailing part must start with `=`, `/`, or an `attr=` pair, so
		// bracketed prose with a plain space ("[note 1]", "[see below]") is left intact —
		// merchants do write that in descriptions, and eating it corrupts real content.
		$text = preg_replace(
			'/\[\/?[a-zA-Z][a-zA-Z0-9_-]*(?:\s+[a-zA-Z0-9_-]+=[^\]]*|\s*\/)?\]/',
			'',
			$text
		) ?? $text;
		$text = wp_strip_all_tags( $text );
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return $this->normalize( $text );
	}

	/**
	 * Human-readable price, including the sale price when one is active, so the
	 * assistant can answer "is it on sale?" without a second lookup.
	 *
	 * @param \WC_Product|mixed $product
	 */
	private function price_text( $product ): string {
		$price = (string) $this->safe_call( $product, 'get_price', '' );
		if ( '' === $price ) {
			return '';
		}
		$currency = function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : '';
		$text     = trim( $price . ' ' . $currency );

		$regular = (string) $this->safe_call( $product, 'get_regular_price', '' );
		$sale    = (string) $this->safe_call( $product, 'get_sale_price', '' );
		if ( '' !== $sale && '' !== $regular && $sale !== $regular ) {
			$text .= ' (on sale, was ' . trim( $regular . ' ' . $currency ) . ')';
		}
		return $text;
	}

	/**
	 * Stock as words rather than a raw status slug, because the embedding is matched
	 * against shopper phrasing like "is it in stock".
	 *
	 * @param \WC_Product|mixed $product
	 */
	private function stock_text( $product ): string {
		$status = (string) $this->safe_call( $product, 'get_stock_status', 'instock' );
		$map    = array(
			'instock'     => 'In stock',
			'outofstock'  => 'Out of stock',
			'onbackorder' => 'Available on backorder',
		);
		$text   = $map[ $status ] ?? 'In stock';

		$qty = $this->safe_call( $product, 'get_stock_quantity', null );
		if ( is_numeric( $qty ) ) {
			$text .= ' (' . (int) $qty . ' available)';
		}
		return $text;
	}

	/**
	 * Digital vs. physical, in words a shopper would use ("download", "physical item"),
	 * because nothing else in the collected content states this: a virtual/downloadable
	 * product's description does not reliably say so, and a shopper asking "is this a
	 * download or a physical item" has nothing else to match against.
	 *
	 * Downloadable takes priority over virtual in the wording when both are true (the
	 * common WooCommerce combination for digital goods) since "download" is the more
	 * specific, shopper-meaningful term; virtual-only (no file, e.g. a service) is worded
	 * separately since it is not something a shopper would call a "download".
	 *
	 * @param \WC_Product|mixed $product
	 */
	private function delivery_text( $product ): string {
		$downloadable = (bool) $this->safe_call( $product, 'is_downloadable', false );
		$virtual      = (bool) $this->safe_call( $product, 'is_virtual', false );

		if ( $downloadable ) {
			return 'Digital download, no physical shipment';
		}
		if ( $virtual ) {
			return 'Virtual item, no physical shipment';
		}
		return 'Physical item, shipped to you';
	}

	/**
	 * Visible product attributes as `Name: value, value`.
	 *
	 * Attributes flagged non-visible are the merchant's internal data, so they are skipped
	 * for the same reason `hidden` products are.
	 *
	 * @param \WC_Product|mixed $product
	 */
	private function attribute_text( $product ): string {
		$attributes = $this->safe_call( $product, 'get_attributes', array() );
		if ( ! is_array( $attributes ) || array() === $attributes ) {
			return '';
		}

		$rendered = array();
		foreach ( $attributes as $attribute ) {
			if ( ! is_object( $attribute ) || ! method_exists( $attribute, 'get_name' ) ) {
				continue;
			}
			if ( method_exists( $attribute, 'get_visible' ) && ! $attribute->get_visible() ) {
				continue;
			}

			$name   = wc_attribute_label( (string) $attribute->get_name() );
			$values = array();

			if ( method_exists( $attribute, 'is_taxonomy' ) && $attribute->is_taxonomy() ) {
				$terms = $this->safe_call( $attribute, 'get_terms', array() );
				if ( is_array( $terms ) ) {
					foreach ( $terms as $term ) {
						if ( is_object( $term ) && isset( $term->name ) ) {
							$values[] = $this->plain_name( (string) $term->name );
						}
					}
				}
			} else {
				$options = $this->safe_call( $attribute, 'get_options', array() );
				if ( is_array( $options ) ) {
					foreach ( $options as $option ) {
						$values[] = (string) $option;
					}
				}
			}

			$values = array_filter( $values, static fn( $v ) => trim( $v ) !== '' );
			if ( array() !== $values ) {
				$rendered[] = $name . ': ' . implode( ', ', $values );
			}
		}
		return implode( '; ', $rendered );
	}

	/**
	 * A compact variant summary for variable products (§1.1's "variant summary").
	 *
	 * Summary, not per-variant items: a 200-variant product would otherwise flood the
	 * memory-item quota and bury the parent product in near-duplicate chunks. Capped at 20
	 * so a pathological product cannot dominate its own content.
	 *
	 * @param \WC_Product|mixed $product
	 */
	private function variant_summary( $product ): string {
		if ( ! method_exists( $product, 'is_type' ) || ! $product->is_type( 'variable' ) ) {
			return '';
		}
		$children = $this->safe_call( $product, 'get_children', array() );
		if ( ! is_array( $children ) || array() === $children ) {
			return '';
		}

		$total     = count( $children );
		$summaries = array();
		foreach ( array_slice( $children, 0, 20 ) as $child_id ) {
			$variation = function_exists( 'wc_get_product' ) ? wc_get_product( $child_id ) : null;
			if ( ! is_object( $variation ) ) {
				continue;
			}
			$label       = $this->plain_name( (string) $this->safe_call( $variation, 'get_name', '' ) );
			$stock       = (string) $this->safe_call( $variation, 'get_stock_status', '' );
			$summaries[] = trim( $label . ( 'outofstock' === $stock ? ' (out of stock)' : '' ) );
		}

		$text = implode( '; ', array_filter( $summaries ) );
		if ( $total > 20 ) {
			$text .= sprintf( ' … and %d more', $total - 20 );
		}
		return trim( $text );
	}

	/**
	 * Term names for a taxonomy, empty on any failure.
	 *
	 * @return string[]
	 */
	private function term_names( int $post_id, string $taxonomy ): array {
		if ( $post_id <= 0 ) {
			return array();
		}
		$terms = get_the_terms( $post_id, $taxonomy );
		if ( ! is_array( $terms ) ) {
			return array();
		}
		$names = array();
		foreach ( $terms as $term ) {
			if ( is_object( $term ) && isset( $term->name ) ) {
				$names[] = $this->plain_name( (string) $term->name );
			}
		}
		return $names;
	}

	/**
	 * Call a getter that may not exist on this product type.
	 *
	 * WooCommerce product classes are a type hierarchy plus third-party subclasses; a
	 * simple product has no `get_children`, and a custom type may lack getters the core
	 * types have. Guarding here keeps collection from fataling on one unusual product and
	 * losing the entire catalogue push.
	 *
	 * @param mixed  $subject  The product (or attribute/variation) to read from.
	 * @param string $method   Getter name.
	 * @param mixed  $fallback Returned when the getter is absent, throws, or yields null.
	 * @return mixed
	 */
	private function safe_call( $subject, string $method, $fallback = null ) {
		if ( ! is_object( $subject ) || ! method_exists( $subject, $method ) ) {
			return $fallback;
		}
		try {
			$value = $subject->{$method}();
		} catch ( \Throwable $e ) {
			return $fallback;
		}
		return null === $value ? $fallback : $value;
	}
}
