<?php
/**
 * Plugin bootstrap (`add-foundation-onboarding §1.1`).
 *
 * The entrypoint after `plugins_loaded` — runs the compatibility guards once more
 * (activation also runs them, but a version bump late detected only on load), declares
 * HPOS compatibility before WooCommerce finishes initialising, wires the modules the
 * activation flow reaches (`Auth`, `Sync`, `Admin`), and registers the onboarding +
 * subscription-gate hooks.
 *
 * Single instance: WordPress loads plugins once. Modules pull `Plugin::instance()` to
 * reach their siblings without forming import cycles; the same pattern Woo Extensibility
 * uses (e.g. `WC()->`).
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat;

use WooAIChat\Admin\OnboardingWizard;
use WooAIChat\Admin\Panel;
use WooAIChat\Auth\SubscriptionGate;
use WooAIChat\Auth\TokenStorage;
use WooAIChat\Ops\ApiVersion;
use WooAIChat\Ops\FailureNotice;
use WooAIChat\Ops\StatusSurface;
use WooAIChat\Ops\UpdateChecker;
use WooAIChat\Sync\ContentHooks;
use WooAIChat\Sync\IngestionScheduler;
use WooAIChat\Sync\SubscriptionCheckJob;
use WooAIChat\Widget\Enqueue;

/**
 * The plugin's singleton entrypoint.
 *
 * Holds the cross-module wiring (`TokenStorage`, `SubscriptionGate`) that other modules
 * need, but does **not** hold state shared between requests — the singleton is per-
 * request like everything in PHP-FPM, not a long-lived process.
 */
final class Plugin {

	private static ?Plugin $instance = null;

	private TokenStorage $tokens;
	private StatusSurface $status_surface;
	private UpdateChecker $update_checker;
	private SubscriptionGate $gate;
	private OnboardingWizard $wizard;
	private Panel $panel;
	private SubscriptionCheckJob $checker;
	private IngestionScheduler $ingestion;
	private ContentHooks $content_hooks;
	private Enqueue $widget_enqueue;
	private FailureNotice $failure_notice;
	private ApiVersion $api_version;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Run the same compatibility gate the activation hook ran, so a version
		// mismatch introduced between activation and the next page load is still
		// noticed (a merchant who upgrades WooCommerce above our supported version
		// should not silently have a broken plugin loaded).
		Compatibility::check_and_notice();

		// HPOS declaration on `before_woocommerce_init`. Has to be wired before the
		// first `plugins_loaded` WooCommerce handler finishes; declaring it here keeps
		// the registration alongside the rest of the bootstrap — there is one site
		// where the rest of HPOS-work knows to live.
		add_action( 'before_woocommerce_init', array( Compatibility::class, 'declare_hpos_compatibility' ) );

		// The outage-disambiguation surface (`add-platform-ops-surfaces` §2.4, D15). Built
		// here and handed to the gate so the admin surfaces that render a failure message
		// read the same instance the gate records reachability against — one statement,
		// rendered in several places, rather than several opinions (design D-3).
		$this->tokens         = new TokenStorage();
		$this->status_surface = new StatusSurface();
		$this->update_checker = new UpdateChecker();
		$this->gate           = new SubscriptionGate( $this->tokens, null, $this->status_surface );
		$this->checker        = new SubscriptionCheckJob( $this->gate );

		// Content ingestion (`add-content-ingestion-kb` §2): the Action Scheduler job
		// layer that owns every push, and the WooCommerce hooks that feed it. The hooks do
		// no HTTP — they enqueue jobs — so a slow backend never stalls a product save.
		//
		// Built before the wizard and the panel because both enqueue through this same
		// scheduler: the wizard kicks the first full sync the moment activation succeeds,
		// and the Knowledge Base page's three write actions (§5.3–5.5) enqueue through it
		// — one queue, whether the trigger was activation, a product save, or a merchant
		// pressing "Re-index".
		$this->ingestion     = new IngestionScheduler( $this->tokens );
		$this->content_hooks = new ContentHooks( $this->ingestion );

		$this->wizard = new OnboardingWizard( $this->tokens, $this->gate, null, $this->ingestion );

		// The FR-038 merchant alert (`add-merchant-insight-ops §4.2`) — reads the same status
		// surface the gate itself records reachability against and the Health Check page's
		// `connectivity` row reads, so all three cannot describe different outages (D-3).
		$this->failure_notice = new FailureNotice( $this->status_surface );
		$this->api_version    = new ApiVersion();

		// The Merchant Admin Panel (`add-merchant-insight-ops §1.1`). Registered
		// unconditionally: its own pre-activation view (ES-007) is what a store without
		// tokens should see, and hiding the menu until activation would leave a merchant
		// mid-onboarding with no way back to the dashboard they were promised.
		//
		// Constructed *before* the widget enqueue because the enqueue reads its
		// `WidgetSettings` — see below.
		$this->panel = new Panel( $this->tokens, $this->gate, null, $this->ingestion );

		// Storefront widget enqueue (`add-shopper-chat` §4.2/§4.7): decides whether the
		// bundle loads on the current page and what config it boots with.
		//
		// It is handed the *panel's* `WidgetSettings` rather than a fresh one, so the
		// object the Settings form writes is the object the storefront reads. With a
		// second instance the two agree only by both re-reading the option, and the
		// merchant's accent, position, and enable toggle silently did nothing at all
		// before this was wired (FR-012).
		$panel                = $this->panel;
		$this->widget_enqueue = new Enqueue(
			$this->tokens,
			$this->gate,
			null,
			static function () use ( $panel ): array {
				return $panel->widget_settings()->widget_config();
			}
		);

		// Refresh the gate on activation (synchronous once) and via the daily
		// Action Scheduler job wired by `Lifecycle::activate()` (§5.1).
		$this->checker->register();
		$this->wizard->register();
		$this->panel->register();
		$this->ingestion->register();
		$this->content_hooks->register();
		$this->widget_enqueue->register();
		$this->failure_notice->register();
		// Renders only on a MAJOR seam mismatch; the recording half is a side effect of
		// `BackendClient::decode()` and needs no hook of its own.
		$this->api_version->register();

		// Private plugin distribution (`add-platform-ops-surfaces` §3.2, NFR-036). No
		// merchant-facing behaviour depends on this — it only makes an update *offered*
		// in `/wp-admin/plugins.php` — so it is safe to wire unconditionally rather than
		// gating it behind the subscription/onboarding state everything else here reads.
		$this->update_checker->register();
	}

	/**
	 * The subscription gate — also the source of the merchant-facing failure class
	 * (`SubscriptionGate::failure_class()`).
	 */
	public function gate(): SubscriptionGate {
		return $this->gate;
	}

	/**
	 * The outage-disambiguation surface, for the admin surfaces that render a failure
	 * message (`add-merchant-insight-ops`: Health Check, the backend-unreachable notice).
	 * Reading it here rather than re-deriving state is what keeps those surfaces from
	 * contradicting the status page (§2.4, design D-3).
	 */
	public function status_surface(): StatusSurface {
		return $this->status_surface;
	}
}
