<?php
/**
 * Activation / deactivation / uninstall lifecycle (`add-foundation-onboarding §1.5`).
 *
 * Activation primes the `wai_*` `wp_options` entries with safe defaults and schedules
 * the `subscription_check` Action Scheduler job (FR-006, TR-020). Deactivation
 * unschedules the job and clears the subscription transient — but the store token is
 * **retained** (NFR-039): a merchant who deactivates by accident should not have to
 * re-onboard to get their store back. The backend treats a token that no longer matches
 * a tenant row as 401 (D17 rotation), so "reactivate → wizard does not need to re-enter
 * the license" is the consequence the plugin owns.
 *
 * Uninstall lives in `uninstall.php` and is gated by `WP_UNINSTALL_PLUGIN`. There the
 * plugin does the full purge: drop every `wai_*` option, cancel any AS jobs in the
 * group, and fire the backend erasure request (`POST /v1/auth/erasure`, FR-045/D10),
 * which erases the store's vectors, indexed content, and conversations.
 *
 * @package WooAIChat
 *
 * The Action Scheduler classes are provided by WooCommerce, not by this plugin. Their
 * absence is a guard failure case for the next activation rather than an error — see the
 * `function_exists()` checks at each call site.
 */

declare(strict_types=1);

namespace WooAIChat;

use WooAIChat\Admin\WidgetSettings;
use WooAIChat\Sync\IngestionScheduler;

/**
 * Plugin activation / deactivation / uninstall hooks.
 *
 * Pure static — there is no state to hold. Activation writes defaults to `wp_options`
 * and schedules the one Action Scheduler job; deactivation unschedules; uninstall (in
 * `uninstall.php`) does the drop.
 */
final class Lifecycle {

	/**
	 * Called from `register_activation_hook`. Records the onboarding-not-yet-started
	 * state, schedules the daily subscription-check job.
	 *
	 * Activation is one of the two places the spec for §1.4 (blocked outbound HTTPS)
	 * runs from; here we just schedule AS — the activation-page notice is wired in
	 * the wizard on first hit.
	 */
	public static function activate(): void {
		// Prime options only if not already set (a re-activation after deactivation
		// preserves the prior token set, per the design above — `add_option` is the
		// idempotent "set if missing" the spec needs).
		add_option( WAI_OPTION_STORE_TOKEN, '' );
		add_option( WAI_OPTION_WIDGET_TOKEN, '' );
		add_option( WAI_OPTION_STORE_ID, '' );
		add_option( WAI_OPTION_SITE_FINGERPRINT, '' );
		add_option( WAI_OPTION_LICENSE_KEY_HASH, '' );
		add_option(
			WAI_OPTION_CONSENT,
			array(
				'consented_at' => null,
				'dpa_version'  => null,
			)
		);
		add_option(
			WAI_OPTION_SUBSCRIPTION_CACHE,
			array(
				'status'       => 'inactive',
				'checked_at'   => null,
				'subscription' => null,
				'fetched_from' => 'defaults',
			)
		);
		// The widget configuration (FR-012, `add-merchant-insight-ops §3.2–3.3`).
		// `add_option` for the same reason as the rest: a re-activation must not reset a
		// merchant's widget title and position back to the defaults.
		add_option( WAI_OPTION_WIDGET_SETTINGS, WidgetSettings::defaults() );

		// The site fingerprint is generated server-side at activation. The license
		// binds to it (D16) so one license does not serve many unrelated stores.
		if ( get_option( WAI_OPTION_SITE_FINGERPRINT ) === '' ) {
			update_option( WAI_OPTION_SITE_FINGERPRINT, self::generate_fingerprint() );
		}

		// Schedule the daily subscription check (FR-006, TR-020). Action Scheduler
		// ships with WooCommerce; if it is absent, the activation page notice fires
		// through `Compatibility::check_and_notice` for the missing WC. Hooked as
		// a recurring action in the group shared with the metering icons.
		self::schedule_subscription_check();

		// Schedule the nightly manifest-diff reconciliation (`add-content-ingestion-kb`
		// §2.6). Guarded on the class existing because the activation fallback path can run
		// without the autoloader; an already-activated store gets it from the scheduler's
		// `admin_init` backstop instead.
		if ( class_exists( IngestionScheduler::class ) ) {
			IngestionScheduler::schedule_nightly();
		}

		// Flush the subscription transient on activation so the first request after
		// activation always pulls from the backend rather than reading a stale cache.
		delete_transient( WAI_TRANSIENT_SUBSCRIPTION_STATE );
	}

	/**
	 * Called from `register_deactivation_hook`.
	 *
	 * The widget itself needs no code here to be "removed immediately" (FR-044): WordPress
	 * stops calling a deactivated plugin's hooks at all, so the storefront enqueue in
	 * `Plugin::instance()` never runs again from the moment deactivation completes. What
	 * this method owns is the two things that do not follow from PHP simply not running —
	 * the scheduled jobs (which Action Scheduler would otherwise keep firing against a
	 * plugin that can no longer handle them) and the subscription cache (stale on
	 * reactivation otherwise). The store token is deliberately *not* touched here — see
	 * `uninstall()` for the intentional-removal counterpart.
	 */
	public static function deactivate(): void {
		self::unschedule_subscription_check();
		if ( class_exists( IngestionScheduler::class ) ) {
			IngestionScheduler::unschedule_nightly();
		}
		delete_transient( WAI_TRANSIENT_SUBSCRIPTION_STATE );
	}

	/**
	 * Drop every option the plugin owns. Called from `uninstall.php`, gated there by
	 * `WP_UNINSTALL_PLUGIN`. The full erasure request to the backend (D10) is fired
	 * here as a best-effort `wp_remote_post`; if the backend is unreachable at
	 * uninstall time the local purge still completes — the backend retains data
	 * until the metering epic's grace-end schedule fires.
	 */
	public static function uninstall(): void {
		// Read *before* the purge below deletes it. `get_option()` returns `false` for an
		// option that does not exist, and reading this after `delete_option()` would
		// therefore always see it gone — silently skipping the erasure request on every
		// uninstall, forever, despite defining a "best-effort" branch that looked live.
		//
		// And *decrypt* it: the row holds `TokenStorage`'s `mac‖iv‖ciphertext` blob, not
		// the token. The blob used to be sent verbatim as the Bearer credential, which
		// guaranteed a 401 — the erasure branch had never once succeeded. `decrypt()`
		// returns null for a foreign or corrupted blob, and the guard below already
		// treats a non-string as "no token, skip the request", which is the right
		// degradation: local purge still runs, the backend's grace-end schedule purges
		// server-side. `class_exists` because `uninstall.php` loads no autoloader; it
		// requires `Encryption.php` alongside this file.
		$stored      = get_option( WAI_OPTION_STORE_TOKEN );
		$store_token = is_string( $stored ) && '' !== $stored && class_exists( Encryption::class )
			? Encryption::decrypt( $stored )
			: null;

		// Local option purge (TR-008). Every `WAI_OPTION_*` the activation path primed.
		delete_option( WAI_OPTION_STORE_TOKEN );
		delete_option( WAI_OPTION_WIDGET_TOKEN );
		delete_option( WAI_OPTION_STORE_ID );
		delete_option( WAI_OPTION_SITE_FINGERPRINT );
		delete_option( WAI_OPTION_LICENSE_KEY_HASH );
		delete_option( WAI_OPTION_CONSENT );
		delete_option( WAI_OPTION_SUBSCRIPTION_CACHE );
		// The setup prompt's dismissal flag and the last activation error are owned by
		// `OnboardingWizard`, not by a `WAI_OPTION_*` constant, so they are named here
		// explicitly. TR-008's promise is that uninstall leaves no `wai_*` row behind,
		// and a row this class does not know about is exactly how that promise rots.
		// String literals, not `OnboardingWizard::OPTION_NOTICE_DISMISSED`: `uninstall.php`
		// requires *only* this file (no autoloader — see its header), so a class constant
		// here would fatal the uninstall on a missing class. The names are duplicated
		// deliberately and the owning class' docblock points back here.
		delete_option( 'wai_setup_notice_dismissed' );
		delete_option( 'wai_activation_error' );
		// `OnboardingWizard::OPTION_GUIDED_STEP` — how far the merchant got through the
		// post-activation steps. Same literal-not-constant reasoning as the two above.
		delete_option( 'wai_wizard_step' );
		// The rows owned by later epics, named as literals for the same no-autoloader
		// reason as above: the widget configuration, the KB page include/exclude
		// overrides, the manual-entry registry, the backend failure streak, and the
		// status-surface transient. Each was primed or written by a class this request
		// never loads, and TR-008's promise is that uninstall leaves no `wai_*` row
		// behind — these four options and two transients were being left behind.
		delete_option( 'wai_widget_settings' );
		delete_option( 'wai_kb_page_overrides' );
		delete_option( 'wai_manual_entries' );
		delete_option( 'wai_backend_failure_streak' );
		delete_transient( 'wai_status_surface_state' );
		delete_transient( 'wai_wizard_connectivity' );
		delete_transient( WAI_TRANSIENT_SUBSCRIPTION_STATE );

		self::unschedule_subscription_check();
		if ( class_exists( IngestionScheduler::class ) ) {
			IngestionScheduler::unschedule_nightly();
		}

		// Best-effort backend erasure request (`POST /v1/auth/erasure`, FR-045, D10). The
		// endpoint erases this store's vectors, indexed content, and conversations, scoped
		// to whatever the presented store token resolves to — there is no store id in the
		// body, so this cannot name anyone else's data. The `reason` field it carries is
		// not read by the backend; it is kept because it costs nothing and makes the
		// request self-describing in a proxy log.
		//
		// Best-effort in the literal sense: the response is not inspected and a failure is
		// not retried. Nothing else erases this store afterwards — the backend's nightly
		// sweep moves a lapsed subscription to `cancelled` but deliberately deletes
		// nothing — so a merchant who needs erasure confirmed has to ask, and an operator
		// runs it from the Owner Panel. That is a thin guarantee, and it is the one this
		// call actually provides; the D10 workflow that makes erasure provable (an
		// append-only log, a receipt) is still owed.
		//
		// The request is skipped entirely when the token is missing or was unreadable,
		// because the endpoint has no other way to identify the store.
		if ( is_string( $store_token ) && '' !== $store_token && defined( 'WAI_BACKEND_URL' ) ) {
			wp_remote_post(
				rtrim( WAI_BACKEND_URL, '/' ) . '/v1/auth/erasure',
				array(
					'timeout'   => 10,
					'sslverify' => true,
					'headers'   => array(
						'authorization' => 'Bearer ' . $store_token,
						'content-type'  => 'application/json',
					),
					'body'      => wp_json_encode( array( 'reason' => 'merchant_uninstall' ) ),
				)
			);
		}
	}

	/**
	 * Schedules the daily `subscription_check` job in the wc_ai_agent group.
	 *
	 * Idempotent: `as_next_scheduled_action` returns false (unscheduled) before the
	 * first call and the action's own id afterwards; we only schedule when false.
	 * Re-activation therefore does not stack up jobs — a deactivation/activation
	 * cycle leaves exactly one entry on the schedule.
	 */
	public static function schedule_subscription_check(): void {
		// Both functions, not just the one this method's happy path ends on. The guard
		// checked `as_schedule_recurring_action` alone while the next line calls
		// `as_next_scheduled_action` — safe in practice, since Action Scheduler brings both
		// or neither, but it left the actual call site unguarded and is the pattern
		// `Sync\IngestionScheduler` already gets right.
		if ( ! function_exists( 'as_schedule_recurring_action' ) || ! function_exists( 'as_next_scheduled_action' ) ) {
			// Action Scheduler is absent. Impossible against the `wc_ok()` guard, but
			// if the plugin is somehow loaded without AS the job is silently
			// unscheduled — and the next subscription check happens on a normal page
			// load instead (`SubscriptionGate::maybe_refresh`).
			return;
		}
		if ( as_next_scheduled_action( 'wcai_subscription_check' ) !== false ) {
			return;
		}
		// +1h jitter so a fleet of stores does not all hit the backend at the same
		// minute after midnight. AS itself despreads too, but a one-hour upfront
		// jitter also avoids the 'first run hits in the next 60s' window for users
		// activating at 23:55.
		$first_run = time() + HOUR_IN_SECONDS + wp_rand( 0, HOUR_IN_SECONDS );
		as_schedule_recurring_action(
			$first_run,
			DAY_IN_SECONDS,
			'wcai_subscription_check',
			array(),
			WAI_ACTION_SCHEDULER_GROUP
		);
	}

	/** Unschedule every pending `wcai_subscription_check` action. */
	public static function unschedule_subscription_check(): void {
		if ( ! function_exists( 'as_unschedule_action' ) ) {
			return;
		}
		as_unschedule_action( 'wcai_subscription_check', array(), WAI_ACTION_SCHEDULER_GROUP );
	}

	/**
	 * Generate a site fingerprint for the D16 binding.
	 *
	 * The fingerprint is `wp_generate_uuid4()` — a fresh UUID per activation — and the
	 * license binds to it server-side. A staging→production migration re-binds via the
	 * FR-093 carve-out; a hand-installed second copy of the plugin does not.
	 */
	private static function generate_fingerprint(): string {
		if ( function_exists( 'wp_generate_uuid4' ) ) {
			return wp_generate_uuid4();
		}
		// A fallback for very early tests (WP-only envs that have not loaded the UUID
		// helper). `wp_salt` provides the entropy; we hash a secret + a fresh nonce.
		return wp_hash( wp_salt( 'nonce' ) . uniqid( '', true ) );
	}
}
