<?php
/**
 * The Health Check page (`add-merchant-insight-ops §4.1/§4.4`, FR-018/042/043, SR-005, D12).
 *
 * Six backend-computed checks — connectivity, subscription, last sync, indexed content,
 * quota, recent answer quality — plus indexing-queue progress, each rendered with the
 * backend's own plain-language explanation and fix. This page authors none of that copy:
 * `app.merchant.service` (`_check()`'s "fix is mandatory unless healthy" invariant) is
 * where FR-018/SR-005 are actually enforced, and duplicating the wording here would put a
 * second, driftable copy of "what a lapsed subscription means" in the codebase. The page's
 * only job is to render `MerchantHealthResponse` faithfully and translate the six `check`
 * names + three `status` values into merchant-facing labels.
 *
 * ## Where the §4.4 re-sync CTA lives
 *
 * The backend's `last_sync` fix text already says "Open the Knowledge Base page and run a
 * sync" when the store is stale (>25h) or has missed the nightly run entirely (>48h,
 * `STALE_FAILING_AFTER_HOURS` — the same signal that also stands in for a hook that has
 * been failing quietly: both converge on "how long since the last successful push", so one
 * check and one threshold cover the scheduler-stall and hook-failure requirements at once).
 * Rather than parse that sentence for a link, `payload()` gives `last_sync` and
 * `collection` — the two checks whose fix is "go run a sync" — a `resyncUrl`, which the
 * client renders as an actual button pointed at the Knowledge Base page's existing
 * re-sync trigger (`add-content-ingestion-kb §5.5`) rather than a second one here.
 *
 * ## §4.2 — when the health read itself fails
 *
 * The six checks above all come from a *successful* `GET /v1/merchant/health` — but a
 * backend that is unreachable cannot self-report `connectivity: failing`; there is no
 * response body to shape at all in that case (`Panel::ajax_health()`'s `$body === null`
 * branch). `payload()` takes an optional `FailureClass` for exactly that gap: when the
 * caller has one — i.e. the read failed and `SubscriptionGate::failure_class()` resolved
 * past `NONE` (FR-038's 3-consecutive-failure threshold) — its headline/fix overwrite the
 * `connectivity` row instead of a second, page-authored "could not connect" string. This is
 * the one property `test_a_failing_checks_explanation_and_fix_pass_through_verbatim`
 * doesn't cover: there the backend answered and described its own failure; here it didn't
 * answer at all, and the independent status surface (D15) is the only source of truth left.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

use WooAIChat\Auth\BackendUrl;
use WooAIChat\Ops\FailureClass;
use WooAIChat\Widget\Enqueue;

/**
 * Renders the Health Check shell and shapes `/v1/merchant/health` for it.
 */
final class HealthCheckPage {

	/** Checks whose backend `fix` text points at the Knowledge Base's re-sync action (§4.4). */
	private const RESYNC_CHECKS = array( 'last_sync', 'collection' );

	/**
	 * The Health Check body: one row per check, then the indexing-queue line.
	 *
	 * Emits no outbound HTTP — see `Panel`'s header on why every panel page renders a shell
	 * and fills it over AJAX (NFR-005).
	 */
	/**
	 * How many checks `/v1/merchant/health` always returns (§4.1).
	 *
	 * Used only to size the loading skeleton. The rendered list comes from the response,
	 * so a backend that one day returns more does not break anything here — the skeleton
	 * would simply be one row short for a moment.
	 */
	private const CHECK_COUNT = 6;

	public function render(): void {
		echo '<div class="wcai-health" data-wcai-page="health">';

		// The loading state carries the *shape* of what is coming, not just a sentence.
		// Six checks always arrive, so six placeholder rows are an honest promise rather
		// than a guess — and they stop the page from being a blank void for the duration
		// of the backend read, which is what a bare "Checking your store…" left behind.
		echo '<div class="wcai-loading" data-wcai-loading="1" role="status">';
		echo '<p class="wcai-loading-text">' . esc_html__( 'Checking your store…', 'woocommerce-ai-chat' ) . '</p>';
		echo '<ul class="wcai-health-list wcai-health-skeleton" aria-hidden="true">';
		for ( $i = 0; $i < self::CHECK_COUNT; $i++ ) {
			echo '<li class="wcai-health-item"><div class="wcai-health-item-head">'
				. '<span class="wcai-skeleton" style="width:38%">&nbsp;</span>'
				. '<span class="wcai-skeleton" style="width:64px">&nbsp;</span>'
				. '</div></li>';
		}
		echo '</ul></div>';

		echo '<p class="wcai-health-overall" data-wcai-field="overallBanner" hidden></p>';

		echo '<ul class="wcai-health-list" data-wcai-health-list hidden></ul>';

		echo '<p class="wcai-health-indexing" data-wcai-field="indexingProgress"></p>';

		echo '</div>';
	}

	/**
	 * Shape `/v1/merchant/health` (a `MerchantHealthResponse`) into what the client renders.
	 *
	 * Pure: no WordPress state beyond translation/formatting helpers, so it is directly
	 * testable against a contract-shaped array — the same posture every other page's
	 * `payload()` takes.
	 *
	 * @param array<string, mixed> $body    A `MerchantHealthResponse`. Ignored (rendered as
	 *                                      all-healthy-except-connectivity) when `$failure`
	 *                                      is failing — the caller reaches for `$failure`
	 *                                      precisely when the real read did not succeed.
	 * @param FailureClass|null    $failure The status-surface verdict (§4.2), when the
	 *                                      `/v1/merchant/health` call itself failed. Null —
	 *                                      the default, and every case before this session —
	 *                                      renders exactly as before.
	 * @param string|null          $api_base The `apiBase` the storefront widget would be
	 *                                      given, for the locally-computed storefront row.
	 *                                      Null omits the row entirely.
	 * @return array<string, mixed>
	 */
	public function payload( array $body, ?FailureClass $failure = null, ?string $api_base = null ): array {
		return $this->with_storefront_row( $this->backend_payload( $body, $failure ), $api_base );
	}

	/**
	 * The rows that come from the backend — everything `payload()` did before the
	 * storefront row existed.
	 *
	 * @param array<string, mixed> $body
	 * @return array<string, mixed>
	 */
	private function backend_payload( array $body, ?FailureClass $failure ): array {
		if ( null !== $failure && $failure->is_failing() ) {
			return $this->failure_payload( $failure );
		}

		// An empty body is the caller's signal that the health read itself failed while
		// the outage streak had not yet crossed its threshold — the streak counts one
		// failure per *day*, so a fresh outage sits below it for up to three days. The
		// old fallthrough rendered that case as a green "Healthy" banner over zero rows,
		// on the page a merchant opens precisely because something looks broken. Report
		// the one fact this page actually knows: the service did not answer.
		if ( ! isset( $body['overall'] ) && ! isset( $body['checks'] ) ) {
			return array(
				'overall'      => 'failing',
				'overallLabel' => self::status_label( 'failing' ),
				'checks'       => array(
					array(
						'check'        => 'connectivity',
						'label'        => self::check_label( 'connectivity' ),
						'status'       => 'failing',
						'statusLabel'  => self::status_label( 'failing' ),
						'explanation'  => __( 'The AI service could not be reached to run the health checks.', 'woocommerce-ai-chat' ),
						'fix'          => __( 'Wait a few minutes and reload this page. If it keeps failing, make sure your host allows outbound HTTPS connections.', 'woocommerce-ai-chat' ),
						'lastVerified' => '',
						'resyncUrl'    => null,
					),
				),
			);
		}

		$overall = is_string( $body['overall'] ?? null ) ? (string) $body['overall'] : 'healthy';
		$checks  = is_array( $body['checks'] ?? null ) ? $body['checks'] : array();

		return array(
			'overall'      => $overall,
			'overallLabel' => self::status_label( $overall ),
			'checks'       => array_map( array( $this, 'shape_check' ), $checks ),
		);
	}

	/**
	 * Append the storefront row — the only check on this page the plugin computes itself.
	 *
	 * Every other row is a fact the *backend* reports about the store, which left one
	 * failure mode with no surface anywhere: an `apiBase` a shopper's browser cannot use.
	 * The widget dies before it makes a request, so the backend has nothing to report, the
	 * logs stay empty, and the other six rows go green — a merchant whose storefront chat
	 * is completely dead was shown a clean bill of health (`docs/LOCAL-TESTING-ISSUES-
	 * 2026-08-01.md` §6.1, which cost an afternoon to diagnose by reading page source).
	 *
	 * It cannot *prove* a shopper's browser succeeds — only a shopper's browser can do
	 * that, and this page makes no outbound request at all (NFR-005). What it can do is
	 * catch every case observed so far and, failing that, print the resolved URL, which is
	 * most of the diagnostic value: the §6.1 session ended the moment someone read
	 * `apiBase`.
	 *
	 * The verdict comes from `Enqueue::api_base_usable()` rather than being re-derived
	 * here, so this page cannot disagree with what the storefront actually did (D-3).
	 *
	 * @param array<string, mixed> $payload  The backend-derived payload.
	 * @param string|null          $api_base The resolved `apiBase`; null omits the row.
	 * @return array<string, mixed>
	 */
	private function with_storefront_row( array $payload, ?string $api_base ): array {
		if ( null === $api_base ) {
			return $payload;
		}

		$usable = Enqueue::api_base_usable( $api_base );

		$payload['checks'][] = array(
			'check'        => 'storefront',
			'label'        => self::check_label( 'storefront' ),
			'status'       => $usable ? 'healthy' : 'failing',
			'statusLabel'  => self::status_label( $usable ? 'healthy' : 'failing' ),
			'explanation'  => $this->storefront_explanation( $api_base, $usable ),
			'fix'          => $usable ? null : $this->storefront_fix( $api_base ),
			'lastVerified' => '',
			'resyncUrl'    => null,
		);

		// A failing row under a "Healthy" banner is the exact defect 1.2.0 fixed for
		// connectivity — the banner is what a merchant reads first, and it must not
		// contradict the list beneath it.
		if ( ! $usable ) {
			$payload['overall']      = 'failing';
			$payload['overallLabel'] = self::status_label( 'failing' );
		}

		return $payload;
	}

	/** The storefront row's explanation, which always names the resolved URL. */
	private function storefront_explanation( string $api_base, bool $usable ): string {
		if ( $usable ) {
			return sprintf(
				/* translators: %s: the backend URL shoppers' browsers are given. */
				__( 'Your storefront chat widget is configured to reach the AI service at %s.', 'woocommerce-ai-chat' ),
				$api_base
			);
		}

		if ( '' === $api_base ) {
			return __( 'Your storefront chat widget has no address for the AI service, so it does not load for shoppers at all.', 'woocommerce-ai-chat' );
		}

		if ( BackendUrl::is_container_hostname( (string) wp_parse_url( $api_base, PHP_URL_HOST ) ) ) {
			return sprintf(
				/* translators: %s: the backend URL shoppers' browsers are given. */
				__( 'Your storefront chat widget is configured to reach the AI service at %s — an address only this server can resolve. Shoppers\' browsers cannot reach it, so the chat window never connects.', 'woocommerce-ai-chat' ),
				$api_base
			);
		}

		return sprintf(
			/* translators: %s: the backend URL shoppers' browsers are given. */
			__( 'Your storefront chat widget would reach the AI service at %s, which is not an encrypted connection. Shopper messages would be readable by anyone on the network path, so the widget is not loaded.', 'woocommerce-ai-chat' ),
			$api_base
		);
	}

	/** The storefront row's fix, in terms of the two constants a deployer actually sets. */
	private function storefront_fix( string $api_base ): string {
		if ( '' === $api_base ) {
			return __( 'Define WAI_BACKEND_URL in wp-config.php, pointing at the public https address of the AI service.', 'woocommerce-ai-chat' );
		}

		return __( 'Set WAI_BACKEND_URL in wp-config.php to the public https address of the AI service — the one a browser can open. If this server reaches it by a shorter private route, put that in WAI_INTERNAL_BACKEND_URL instead and leave WAI_BACKEND_URL public.', 'woocommerce-ai-chat' );
	}

	/**
	 * §4.2 — the shape rendered when the health read itself failed. `connectivity` carries
	 * the status-surface's verdict; the other five checks have no data to report and stay
	 * out of the list entirely rather than guessing a status for something never read —
	 * an absent row reads as "not checked", where a fabricated `healthy` would read as a
	 * claim this page cannot back up.
	 */
	private function failure_payload( FailureClass $failure ): array {
		return array(
			'overall'      => 'failing',
			'overallLabel' => self::status_label( 'failing' ),
			'checks'       => array(
				array(
					'check'        => 'connectivity',
					'label'        => self::check_label( 'connectivity' ),
					'status'       => 'failing',
					'statusLabel'  => self::status_label( 'failing' ),
					'explanation'  => $failure->headline(),
					'fix'          => $failure->fix(),
					'lastVerified' => '',
					'resyncUrl'    => null,
				),
			),
		);
	}

	/**
	 * One `HealthCheckItem`, shaped for the client.
	 *
	 * @param mixed $raw One element of the response's `checks` array.
	 * @return array<string, mixed>
	 */
	private function shape_check( $raw ): array {
		$item = is_array( $raw ) ? $raw : array();

		$check  = is_string( $item['check'] ?? null ) ? (string) $item['check'] : '';
		$status = is_string( $item['status'] ?? null ) ? (string) $item['status'] : 'healthy';

		return array(
			'check'        => $check,
			'label'        => self::check_label( $check ),
			'status'       => $status,
			'statusLabel'  => self::status_label( $status ),
			'explanation'  => is_string( $item['explanation'] ?? null ) ? (string) $item['explanation'] : '',
			// `null` when healthy (the contract's own invariant) or when a shape this
			// plugin does not recognise sends nothing — either way, no fix is not an
			// error state for this field, so it is passed through rather than defaulted
			// to an empty string a template might render as a blank line.
			'fix'          => isset( $item['fix'] ) && is_string( $item['fix'] ) ? (string) $item['fix'] : null,
			'lastVerified' => $this->verified_text( $item['last_verified'] ?? null ),
			// The Knowledge Base page's own re-sync trigger, or null. Built here rather
			// than as a boolean the client turns into a link: `UnansweredPage::addAnswerUrl`
			// sets the precedent — PHP has `admin_url()`, the client does not, so the URL
			// is a value in the payload like every other cross-page link on this panel.
			'resyncUrl'    => ( 'healthy' !== $status && in_array( $check, self::RESYNC_CHECKS, true ) )
				? admin_url( 'admin.php?page=wcai-knowledge' )
				: null,
		);
	}

	/**
	 * "Last checked 27 July 2026, 3:45 pm" in the site's own date/time format and locale,
	 * or an empty string for a check the backend did not timestamp — never "now", which
	 * would claim a verification that did not happen.
	 *
	 * The full sentence is built here, not in the client, for the same reason
	 * `OverviewPage::period_label()` builds "Usage resets on %s" in PHP rather than handing
	 * the client a raw date and a prefix to concatenate: `number_format_i18n`/`date_i18n`
	 * are WordPress locale helpers with no browser-side equivalent, and a concatenated
	 * translation does not read correctly in every language WordPress ships.
	 */
	private function verified_text( $raw ): string {
		$parsed = is_string( $raw ) ? strtotime( $raw ) : false;
		if ( false === $parsed ) {
			return '';
		}
		$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		return sprintf(
			/* translators: %s: the date and time this check last ran. */
			__( 'Last checked %s.', 'woocommerce-ai-chat' ),
			date_i18n( (string) $format, $parsed )
		);
	}

	/**
	 * The merchant-facing name for a contract `check` value.
	 *
	 * "Indexed content", not "Qdrant collection" or "vector store": the backend's own
	 * `collection_check` explanation already avoids naming Qdrant to the merchant
	 * (SR-005, "no jargon"), and a label that reintroduced the vendor name here would undo
	 * that on the one page whose entire point is plain language.
	 *
	 * An unrecognised check falls through to the raw value, the same rule
	 * `Panel::state_label()` and `KnowledgePage::type_label()` both follow — a backend
	 * newer than this plugin should be visible, not erased.
	 */
	public static function check_label( string $check ): string {
		$labels = array(
			'connectivity'  => __( 'Connectivity', 'woocommerce-ai-chat' ),
			'storefront'    => __( 'Storefront connection', 'woocommerce-ai-chat' ),
			'subscription'  => __( 'Subscription', 'woocommerce-ai-chat' ),
			'last_sync'     => __( 'Content sync', 'woocommerce-ai-chat' ),
			'collection'    => __( 'Indexed content', 'woocommerce-ai-chat' ),
			'quota'         => __( 'Reply usage', 'woocommerce-ai-chat' ),
			'recent_errors' => __( 'Answer quality', 'woocommerce-ai-chat' ),
		);

		return $labels[ $check ] ?? $check;
	}

	/**
	 * The merchant-facing name for a `healthy`/`warning`/`failing` status.
	 *
	 * Not the raw contract words: "failing" read next to a merchant's own store sounds
	 * like an accusation, and "needs attention" / "action needed" say the same fact as an
	 * instruction instead. Shared between `overall` and each check's `status` so the
	 * headline and its rows use one vocabulary.
	 */
	public static function status_label( string $status ): string {
		$labels = array(
			'healthy' => __( 'Healthy', 'woocommerce-ai-chat' ),
			'warning' => __( 'Needs attention', 'woocommerce-ai-chat' ),
			'failing' => __( 'Action needed', 'woocommerce-ai-chat' ),
		);

		return $labels[ $status ] ?? $status;
	}
}
