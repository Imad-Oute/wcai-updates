<?php
/**
 * The Unanswered Questions page (`add-merchant-insight-ops §2.4`, FR-015, DUX-006).
 *
 * The questions the assistant could not answer, most-asked first, each with an "Add Answer"
 * action that opens the manual knowledge-entry flow pre-filled with the question — and a
 * CSV export of the whole log.
 *
 * ## This page is the product's improvement loop
 *
 * Every other analytics surface tells a merchant how they are doing. This one is the only
 * place that tells them *what to do next*, and the "Add Answer" round-trip — question in,
 * indexed answer out, deflection rate down — is the loop the whole epic exists to close.
 * That is why the action is per row rather than a link to the Knowledge Base: a merchant
 * who has to retype the question into another page will not do it twice.
 *
 * ## "Add Answer" hands off; it does not index
 *
 * The manual-entry flow (`add-content-ingestion-kb §5.4`, FR-035) owns writing a
 * `source: manual` item at higher retrieval priority. This page links into it with the
 * question as a query argument, so there is one implementation of manual injection rather
 * than a second one here that would have to be kept in step with its priority rules. Until
 * that page lands, the link resolves to the Knowledge Base slug and the panel renders its
 * "not available yet" body — a dead-ended action, but not a wrong one.
 *
 * ## CSV, not XLSX
 *
 * `fputcsv` handles the escaping that a hand-rolled `implode(',')` gets wrong on the first
 * question containing a comma — and shopper questions contain commas, quotes, and newlines
 * constantly. The BOM is deliberate: without it Excel opens UTF-8 CSV as Latin-1 and turns
 * every accented question into mojibake, which for a store with French shoppers is most of
 * the file.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

/**
 * Renders the Unanswered shell, shapes the log for it, and streams the CSV export.
 */
final class UnansweredPage {

	/** The Unanswered body: the export control, the table, and the ES-004 empty state. */
	public function render(): void {
		echo '<div class="wcai-unanswered" data-wcai-page="unanswered">';
		echo '<p class="wcai-loading" data-wcai-loading="1">' . esc_html__( 'Loading unanswered questions…', 'woocommerce-ai-chat' ) . '</p>';

		// The export failure bounce from `Panel::handle_unanswered_export()`. Checked
		// against a literal, and the page is already behind `manage_woocommerce`.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display flag, no state change.
		if ( isset( $_GET['wcai_export'] ) && 'failed' === $_GET['wcai_export'] ) {
			echo '<div class="notice notice-error inline"><p>';
			echo esc_html__( 'The export could not be generated because the AI service did not respond. Try again in a moment.', 'woocommerce-ai-chat' );
			echo '</p></div>';
		}

		// ES-004 — nothing unanswered. Phrased as the achievement it is, not as "no data".
		echo '<div class="wcai-empty" data-wcai-empty="unanswered" hidden>';
		echo '<h2>' . esc_html__( 'No unanswered questions — great coverage!', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p>' . esc_html__( 'Every question shoppers asked in this period was answered from your store content. Anything the assistant cannot answer will show up here.', 'woocommerce-ai-chat' ) . '</p>';
		echo '</div>';

		echo '<div data-wcai-unanswered-body hidden>';

		printf(
			'<form method="post" action="%1$s" class="wcai-export">',
			esc_url( admin_url( 'admin-post.php' ) )
		);
		wp_nonce_field( Panel::NONCE_ACTION );
		echo '<input type="hidden" name="action" value="wcai_export_unanswered" />';
		echo '<button type="submit" class="button">' . esc_html__( 'Export CSV', 'woocommerce-ai-chat' ) . '</button>';
		echo '</form>';

		echo '<table class="widefat striped"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Question', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Times asked', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Language', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Last asked', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Action', 'woocommerce-ai-chat' ) . '</th>';
		echo '</tr></thead><tbody data-wcai-field="unansweredRows"></tbody></table>';

		echo '</div></div>';
	}

	/**
	 * Shape the response's `unanswered` block into display rows.
	 *
	 * @param array<string, mixed> $body A `MerchantAnalyticsResponse`.
	 * @return array{isEmpty: bool, rows: array<int, array<string, mixed>>}
	 */
	public function payload( array $body ): array {
		$rows = $this->rows( is_array( $body['unanswered'] ?? null ) ? $body['unanswered'] : array() );

		return array(
			'isEmpty' => array() === $rows,
			'rows'    => $rows,
		);
	}

	/**
	 * @param array<int, mixed> $unanswered The response's `unanswered` list.
	 * @return array<int, array{question: string, count: string, locale: string, lastAsked: string, addAnswerUrl: string}>
	 */
	private function rows( array $unanswered ): array {
		$rows = array();
		foreach ( $unanswered as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$question = is_string( $item['question'] ?? null ) ? (string) $item['question'] : '';
			if ( '' === $question ) {
				continue;
			}

			$rows[] = array(
				'question'     => $question,
				'count'        => number_format_i18n( isset( $item['count'] ) ? (int) $item['count'] : 0 ),
				'locale'       => is_string( $item['detected_locale'] ?? null ) ? (string) $item['detected_locale'] : '',
				'lastAsked'    => $this->format_date( $item['last_asked'] ?? null ),
				'addAnswerUrl' => $this->add_answer_url( $question ),
			);
		}
		return $rows;
	}

	/**
	 * The deep link into the manual knowledge-entry flow, pre-filled with the question.
	 *
	 * The question rides in the query string, so it is length-bounded in practice by the
	 * chat input and URL-encoded here. The receiving page must treat it as untrusted input
	 * regardless — it originated with a shopper — which is why it is passed as a value to
	 * be re-escaped there rather than as pre-built markup.
	 */
	private function add_answer_url( string $question ): string {
		return add_query_arg(
			array(
				'page'      => 'wcai-knowledge',
				'wcai_add'  => 'manual',
				'wcai_seed' => rawurlencode( $question ),
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * A contract timestamp in the site's own date format.
	 *
	 * @param mixed $value An ISO-8601 string from the contract, or anything else.
	 */
	private function format_date( $value ): string {
		if ( ! is_string( $value ) || '' === $value ) {
			return '';
		}
		$timestamp = strtotime( $value );
		if ( false === $timestamp ) {
			return '';
		}
		return date_i18n( (string) get_option( 'date_format' ), $timestamp );
	}

	/**
	 * Stream the unanswered log as a CSV download and exit.
	 *
	 * Writes to `php://output` through `fputcsv` rather than building a string: the
	 * escaping is the reason to use it at all, and a store with a long tail of unanswered
	 * questions should not need the whole file in memory to download it.
	 *
	 * `last_asked` is exported in ISO-8601, not the site's display format — an export is
	 * read by a spreadsheet, and ISO-8601 is the one form every locale's spreadsheet parses
	 * as a date rather than as text.
	 *
	 * @param array<string, mixed> $body A `MerchantAnalyticsResponse`.
	 */
	public function send_csv( array $body ): void {
		$unanswered = is_array( $body['unanswered'] ?? null ) ? $body['unanswered'] : array();

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header(
			'Content-Disposition: attachment; filename="' . sanitize_file_name(
				'wcai-unanswered-' . gmdate( 'Y-m-d' ) . '.csv'
			) . '"'
		);

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming a download to the client, not touching the filesystem.
		$out = fopen( 'php://output', 'w' );
		if ( false === $out ) {
			exit;
		}

		// UTF-8 BOM — see the class note on Excel.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- php://output is the HTTP response body.
		fwrite( $out, "\xEF\xBB\xBF" );

		fputcsv(
			$out,
			array(
				__( 'Question', 'woocommerce-ai-chat' ),
				__( 'Times asked', 'woocommerce-ai-chat' ),
				__( 'Language', 'woocommerce-ai-chat' ),
				__( 'Last asked', 'woocommerce-ai-chat' ),
			)
		);

		foreach ( $unanswered as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			fputcsv(
				$out,
				array(
					is_string( $item['question'] ?? null ) ? (string) $item['question'] : '',
					isset( $item['count'] ) ? (int) $item['count'] : 0,
					is_string( $item['detected_locale'] ?? null ) ? (string) $item['detected_locale'] : '',
					is_string( $item['last_asked'] ?? null ) ? (string) $item['last_asked'] : '',
				)
			);
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- see fopen above.
		fclose( $out );
		exit;
	}
}
