<?php
/**
 * Onboarding wizard (`add-foundation-onboarding §4.1–§4.4`).
 *
 * v1 ships the **minimal** wizard slice: a stepped flow on a single admin page that does
 *     1. Subscribe — link to the marketing site's WooCommerce storefront (`add-marketing-
 *        site §5.3–§5.5`, superseding the external-pricing-page design
 *        `add-metering-quota-billing` never built). WooCommerce checkout, with the
 *        WooCommerce Stripe Gateway processing payment, triggers backend license issuance
 *        on order completion.
 *     2. License key — live-validated against the backend (`POST /v1/auth/activate`),
 *        blocked on invalid / already-bound key with a plain-language error per §4.2.
 *     3. Data-processing consent — explicit opt-in with a DPA link, recorded as a
 *        timestamp on activation; cannot be skipped (NFR-032, RC-001).
 *     4.Activated — shows both the `activated` outcome and the cached status pill.
 *
 * No AI-key field anywhere (D1, FR-003); the wizard itself does not accept AI-provider
 * configuration, and never renders the input controls other plugins' wizards have for
 * those — even field-absence is a property the spec asks us to enforce.
 *
 * The full UX-spec stepped wizard (`ux-spec-v1.md` §US-001–007) lands at S6 (the §4
 * sprint sequencing note); this is the S2 tracer-bullet slice that satisfies the
 * tasks' acceptance and is consumed later by `add-merchant-insight-ops`.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

use WooAIChat\Auth\BackendApi;
use WooAIChat\Auth\BackendClient;
use WooAIChat\Auth\LicenseActivator;
use WooAIChat\Auth\SubscriptionGate;
use WooAIChat\Auth\TokenStore;
use WooAIChat\Compatibility;

// This class also depends on `MerchantData`, `KnowledgePage`, and `WidgetSettings`. They
// take no `use` line because they are siblings in `WooAIChat\Admin`; the note is here so
// the dependency list at the top of the file is not misleading by omission.

use WooAIChat\Sync\IndexingProgress;
use WooAIChat\Sync\IngestionQueue;

final class OnboardingWizard {

	/**
	 * The wizard's `?page=` slug.
	 *
	 * A constant because four places name it — the menu registration, the asset-enqueue
	 * guard, the post-activation redirect, and `Panel`'s pre-activation call to action —
	 * and a literal in each is four chances for them to drift apart.
	 */
	public const PAGE_SLUG = 'wcai-onboarding';

	/**
	 * The query flag that re-opens the license form on an already-connected store.
	 *
	 * A constant because two files name it — the wizard reads it, and `Panel` builds the
	 * "Reconnect this store" link on the 401 banner — and that link's whole job is to land
	 * on a form. A literal in each is two chances for them to drift apart, at which point
	 * the link silently degrades back into the dead end this constant exists to fix: the
	 * wizard would ignore an unrecognised parameter and render "your store is connected"
	 * to a merchant who had just been told it was not.
	 */
	public const QUERY_RECONNECT = 'wcai_reconnect';

	/** The nonce action guarding the wizard's live license check. */
	public const NONCE_ACTION = 'wcai_wizard';

	/** The nonce action guarding the setup-notice dismissal. */
	public const NONCE_DISMISS = 'wcai_dismiss_setup_notice';

	/** The nonce action guarding the post-activation steps' navigation and colour save. */
	public const NONCE_GUIDED = 'wcai_wizard_guided';

	/**
	 * The query parameter naming which post-activation step to render.
	 *
	 * A constant because the rail links to it, both step handlers redirect to it, and the
	 * renderer reads it — four places, and a literal in each is four chances to drift into a
	 * rail whose links land on the wrong screen.
	 */
	public const QUERY_STEP = 'wcai_step';

	/** Step 4 — indexing progress. */
	public const STEP_INDEXING = 4;

	/** Step 5 — the content-quality gate. */
	public const STEP_QUALITY = 5;

	/** Step 6 — the widget's accent colour. */
	public const STEP_COLOUR = 6;

	/** The first and last post-activation step, so the clamps below name no literals. */
	public const STEP_FIRST_GUIDED = self::STEP_INDEXING;
	public const STEP_LAST_GUIDED  = self::STEP_COLOUR;

	/**
	 * How far the merchant has reached in the post-activation steps (4, 5, or 6).
	 *
	 * ## Why the *absence* of this row is meaningful, and not just "step 4"
	 *
	 * The row is written by `handle_activate_post()` on a successful activation and deleted
	 * when the merchant finishes or skips the guided flow. So it says one thing precisely:
	 * *this store is part-way through guided setup right now*.
	 *
	 * Reading a missing row as "start at step 4" would be wrong in both of the states where
	 * it is missing. A store that finished setup would be walked back through it on every
	 * visit to the wizard page, and — the case that actually matters — a store that
	 * activated under an older version, before these steps existed, would be handed an
	 * unfinished-looking flow for setup it completed weeks ago. Both of those merchants get
	 * the activated screen, which is the honest answer for a store that is already live.
	 *
	 * It is a high-water mark, not a cursor: the rail lets a merchant step back to review
	 * step 4 from step 6, and doing so must not un-reach step 6.
	 *
	 * `Lifecycle::uninstall()` deletes this row by its literal name (`uninstall.php` runs
	 * without the autoloader, so it cannot name this constant). If the value here ever
	 * changes, change it there too or the row survives uninstall (TR-008).
	 */
	public const OPTION_GUIDED_STEP = 'wai_wizard_step';

	/**
	 * Caches the outbound-connectivity probe for `ajax_check_connectivity()`.
	 *
	 * Read and written either side of the `wp_remote_head()` call below, but never
	 * declared — so every probe raised `Error: Undefined constant` and `admin-ajax`
	 * answered 500. The failure is invisible to the unit suite, which asserts the handler
	 * is *hooked* and never invokes it, and invisible to the design-review harness, whose
	 * README states it does not exercise AJAX. It takes a browser on a real WordPress to
	 * see it, which is how it shipped.
	 *
	 * Prefixed `wai_` to match the option and transient names in the root plugin file.
	 */
	public const TRANSIENT_CONNECTIVITY = 'wai_wizard_connectivity';

	/**
	 * Records that the merchant dismissed the post-activation setup prompt.
	 *
	 * `Lifecycle::uninstall()` deletes this row by its literal name rather than by this
	 * constant, because `uninstall.php` runs without the autoloader. If the value here
	 * ever changes, change it there too or the row survives uninstall (TR-008).
	 */
	public const OPTION_NOTICE_DISMISSED = 'wai_setup_notice_dismissed';

	private TokenStore $tokens;
	private SubscriptionGate $gate;
	private BackendApi $backend;

	/**
	 * The backend reads behind steps 4 and 5 (indexing progress, the quality score).
	 *
	 * Held as `MerchantData` for the same NFR-019 reason `Panel` does: this class calls
	 * `wp_localize_script()`, so it must never be able to *name* a store-token accessor.
	 * `MerchantData` consumes the token internally and hands back only response envelopes,
	 * which is what keeps that separation structural rather than a matter of care.
	 */
	private MerchantData $data;

	/** Renders the score card on step 5, reusing the Knowledge Base's own shaping. */
	private KnowledgePage $knowledge;

	/** The local walk record step 4's poll reports from — see `ajax_indexing()`. */
	private IndexingProgress $resync_progress;

	/** Reads and writes the accent colour on step 6. */
	private WidgetSettings $widget;

	/**
	 * The content-sync queue, used to kick the first full sync the moment activation
	 * succeeds. Optional so the unit suite and any non-sync construction keep working
	 * with three arguments; production always injects it (`Plugin::__construct()`).
	 */
	private ?IngestionQueue $ingestion;

	public function __construct( TokenStore $tokens, SubscriptionGate $gate, ?BackendApi $backend = null, ?IngestionQueue $ingestion = null ) {
		$this->tokens    = $tokens;
		$this->gate      = $gate;
		$this->backend   = $backend ?? new BackendClient();
		$this->data      = new MerchantData( $tokens, $this->backend );
		$this->knowledge = new KnowledgePage();
		$this->widget    = new WidgetSettings();
		$this->ingestion = $ingestion;

		$this->resync_progress = new IndexingProgress();
	}

	/** Register the admin menu and the AJAX handler for the activation step. */
	public function register(): void {
		// Priority 11, after `Panel::add_menu_pages()` at the default 10. `add_submenu_page`
		// silently does nothing when its parent slug is not registered yet, and WordPress
		// runs same-priority callbacks in registration order — where the wizard is wired
		// *first* (`Plugin::__construct`). At equal priority the wizard would therefore
		// attach to a menu that does not exist, its page would never be registered, and
		// every link into setup would 404 with nothing logged.
		add_action( 'admin_menu', array( $this, 'add_menu_page' ), 11 );
		// After the access check, before the sidebar paints — see `hide_menu_entry()`.
		add_action( 'admin_head', array( $this, 'hide_menu_entry' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_step_assets' ) );
		// The handler registered under admin-post (not admin-ajax) keeps activation off
		// the unauthenticated `wp_ajax_*` channel — the wizard runs inside `/wp-admin`
		// and the merchant is already auth'd. admin-post re-checks the panel capability
		// with `current_user_can` before reaching the activate path (NFR-019) — a menu
		// capability says nothing about who can POST to `admin-post.php`.
		add_action( 'admin_post_wcai_activate', array( $this, 'handle_activate_post' ) );
		// The design's step 2 validates the key *before* the merchant commits to the
		// activation POST, so an invalid key is an inline error rather than a page
		// round-trip that has already spent the license's one binding attempt.
		add_action( 'wp_ajax_wcai_wizard_check_connectivity', array( $this, 'ajax_check_connectivity' ) );
		add_action( 'admin_notices', array( $this, 'maybe_render_setup_notice' ) );
		add_action( 'admin_post_wcai_dismiss_setup_notice', array( $this, 'handle_dismiss_notice' ) );

		// The post-activation steps (4-6). Navigation goes through admin-post rather than a
		// bare link for the same reason activation does: each of these *writes* — the step
		// mark, the accent colour, the "finished" deletion — and a state change behind a GET
		// is a state change any prefetcher or crawler in the merchant's browser can trigger.
		add_action( 'admin_post_wcai_wizard_advance', array( $this, 'handle_advance' ) );
		add_action( 'admin_post_wcai_wizard_colour', array( $this, 'handle_colour_save' ) );
		// Step 4 polls this rather than blocking its own render on the backend — see
		// `render_step_indexing()` on why the screen must paint before the network answers.
		add_action( 'wp_ajax_wcai_wizard_indexing', array( $this, 'ajax_indexing' ) );
		// Step 5's "Publish anyway". A sibling of the Knowledge Base's own override endpoint
		// rather than a reuse of it: this one is nonce'd under the wizard's action, and the
		// wizard's assets never localize the panel's nonce.
		add_action( 'wp_ajax_wcai_wizard_override', array( $this, 'ajax_override_gate' ) );
	}

	/**
	 * The post-activation prompt (FR-001, PRD §10 step 1).
	 *
	 * *"AI Chat activated — complete setup in 3 steps."* A merchant who has just clicked
	 * Activate on the plugins screen is looking at that screen, not at a menu they have
	 * no reason to know exists yet — so the route into setup has to come to them once.
	 *
	 * Three conditions, all of which have to hold, and each for its own reason:
	 *   - the store has not activated, or there is nothing to prompt for;
	 *   - the merchant has not dismissed it, because a prompt that returns after being
	 *     dismissed is not a prompt, it is a nag;
	 *   - the merchant can actually act on it — showing an editor a setup CTA that
	 *     `wp_die()`s on click is worse than showing nothing.
	 *
	 * It is deliberately absent on the wizard page itself: telling someone to go where
	 * they already are is noise.
	 */
	public function maybe_render_setup_notice(): void {
		if ( ! current_user_can( Panel::capability() ) ) {
			return;
		}
		if ( $this->tokens->has_activation() ) {
			return;
		}
		if ( get_option( self::OPTION_NOTICE_DISMISSED ) ) {
			return;
		}
		// Reading which admin screen we are on, to suppress a notice, is not processing
		// form data — there is no state change to protect and no nonce a plain GET
		// navigation could carry. The value is `sanitize_key`'d before comparison.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$current_page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		if ( self::PAGE_SLUG === $current_page ) {
			return;
		}

		// Styled inline rather than from `panel.css`. This notice renders on *every* admin
		// screen — the Plugins screen most of all, which is where a merchant sees it
		// immediately after activating — and `panel.css` is enqueued only on the panel's
		// own pages, so a rule there would apply nowhere the notice actually appears.
		// Two declarations do not justify a second always-loaded stylesheet on every
		// admin page in the site.
		echo '<div class="notice notice-info wcai-setup-notice">';
		echo '<p style="margin-bottom:6px;"><strong>' . esc_html__( 'AI Chat activated — complete setup in 3 steps.', 'woocommerce-ai-chat' ) . '</strong></p>';
		echo '<p>';
		printf(
			'<a class="button button-primary" href="%1$s">%2$s</a> ',
			esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ),
			esc_html__( 'Start setup', 'woocommerce-ai-chat' )
		);
		// A real link rather than the core dismiss button: core's dismissal is per page
		// load and the notice would be back on the next screen. This one persists.
		printf(
			'<a class="button-link" style="margin-left:10px;" href="%1$s">%2$s</a>',
			esc_url(
				wp_nonce_url(
					admin_url( 'admin-post.php?action=wcai_dismiss_setup_notice' ),
					self::NONCE_DISMISS
				)
			),
			esc_html__( 'Dismiss', 'woocommerce-ai-chat' )
		);
		echo '</p></div>';
	}

	/**
	 * Persist the merchant's dismissal of the setup prompt.
	 *
	 * A `wp_options` row rather than a user meta: the prompt is about the *store's* setup
	 * state, not one person's preference, and a second administrator should not be told
	 * to set up a store their colleague is already setting up.
	 */
	public function handle_dismiss_notice(): void {
		if ( ! current_user_can( Panel::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'woocommerce-ai-chat' ) );
		}
		check_admin_referer( self::NONCE_DISMISS );

		update_option( self::OPTION_NOTICE_DISMISSED, 1 );

		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
		exit;
	}

	/**
	 * `wp_ajax_wcai_wizard_check_connectivity` — the step-2 pre-flight (FR-002, US-005).
	 *
	 * Named for what it does. It checks whether the **licensing service is reachable**;
	 * it does not check the key, and deliberately so: validating a key means calling
	 * `/v1/auth/activate`, which *binds* the license to this site's fingerprint (D16) and
	 * consumes the store's one binding — not something a keystroke may trigger. The real
	 * verdict on the key comes from `handle_activate_post()`, once the merchant has also
	 * consented.
	 *
	 * An earlier draft of this called itself `check_license` and told the merchant
	 * "Checking your license key…", which was a claim the code did not honour: a typo'd
	 * key sailed through the probe and failed at activation, which is exactly the
	 * round-trip the probe was added to avoid.
	 *
	 * `wp_ajax_` only, never `wp_ajax_nopriv_`: an unauthenticated variant would make this
	 * an unauthenticated way to make the site emit outbound requests on demand.
	 */
	public function ajax_check_connectivity(): void {
		if ( ! current_user_can( Panel::capability() ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'woocommerce-ai-chat' ) ),
				403
			);
			return;
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		// The key is not read at all — see the docblock. The field is still what triggers
		// the probe client-side, so an empty one means "nothing to pre-flight yet".
		if ( '' === $this->post_string( 'license_key' ) ) {
			wp_send_json_success( array( 'state' => 'empty' ) );
			return;
		}

		// Cached for a minute. `check_outbound_https()` makes a real `wp_remote_head()`
		// with a 5s timeout, and each one occupies a PHP worker for as long as it runs;
		// without this, a merchant editing a 20-character key past the client's debounce
		// can hold several workers open against a backend that is, by hypothesis, already
		// slow. A minute is short enough that a merchant who fixes their firewall and
		// retries sees the change on their second attempt.
		$cached = get_transient( self::TRANSIENT_CONNECTIVITY );
		if ( is_array( $cached ) ) {
			wp_send_json_success( $cached );
			return;
		}

		$outbound = Compatibility::check_outbound_https( $this->backend->get_base_url() );
		$payload  = $outbound['ok']
			? array( 'state' => 'reachable' )
			: array(
				'state'   => 'unreachable',
				'message' => sprintf(
					/* translators: %s: the backend host. */
					__( "Can't reach the licensing service at %s. Check your connection and try again.", 'woocommerce-ai-chat' ),
					$outbound['host']
				),
			);

		set_transient( self::TRANSIENT_CONNECTIVITY, $payload, MINUTE_IN_SECONDS );

		wp_send_json_success( $payload );
	}

	/**
	 * `wp_ajax_wcai_wizard_indexing` — step 4's progress poll.
	 *
	 * Returns the backend's `IndexingProgress` (shaped by `KnowledgePage::progress()`, so
	 * the wizard and the Knowledge Base describe the same state in the same words) plus the
	 * indexed-item count, which is the number a merchant actually recognises as "my store
	 * is in there".
	 *
	 * ## Why a failed read is `success` with a `state`, not `wp_send_json_error`
	 *
	 * The client polls this on a timer. An error envelope would have the browser treat a
	 * momentary blip as a failure of the *step*, and the natural client response — stop
	 * polling, show an error — is wrong for a store whose indexing is proceeding perfectly
	 * well behind one dropped request. The step is not blocked by this either way: see
	 * `render_step_indexing()` on why Continue is always available.
	 *
	 * `wp_ajax_` only, never `wp_ajax_nopriv_`: this reports a private store's content
	 * inventory.
	 */
	public function ajax_indexing(): void {
		if ( ! current_user_can( Panel::capability() ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'woocommerce-ai-chat' ) ),
				403
			);
			return;
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		// The *local* walk record first. `IngestionScheduler` is what actually indexes this
		// store, and it is the only component that knows its own cursor — the backend's
		// `IndexingProgress` is still a hardcoded `idle/0/0` (see `KnowledgePage::progress()`).
		// Until this read existed, that constant was the whole of step 4's progress: the bar
		// sat at 0% and the line repeated "Re-index scheduled" for the entire walk, which is
		// indistinguishable from a step that has hung.
		$local = $this->resync_progress->read();
		$walk  = $this->knowledge->resync_progress( $local );

		$health = $this->data->health();
		$body   = is_array( $health['body'] ?? null ) ? $health['body'] : array();
		$status = (int) ( $health['status'] ?? 0 );
		$ok     = $status >= 200 && $status < 300;

		$indexing = $ok && is_array( $body['indexing'] ?? null ) ? $body['indexing'] : array();
		$progress = $this->knowledge->progress( $indexing );

		// The item count comes from the knowledge endpoint's `total`, not from health:
		// `IndexingProgress` counts the *current run*, which is zero once a run finishes,
		// and a step that announced "0 items" the moment indexing succeeded would be
		// reporting the opposite of what happened.
		$total = 0;
		if ( $ok ) {
			$inventory = $this->data->knowledge( 1, 0 );
			$inv_body  = is_array( $inventory['body'] ?? null ) ? $inventory['body'] : array();
			$total     = isset( $inv_body['total'] ) ? (int) $inv_body['total'] : 0;
		}

		// Any walk this site actually ran speaks for itself — running *or* finished.
		//
		// Gating this on `isActive` alone was a bug with a nasty shape: the moment the walk
		// completed, `isActive` went false and the answer fell through to the backend's
		// stub, so a bar that had climbed to "4 of 54" snapped back to "Re-index scheduled.
		// It runs in the background" — the merchant watched real progress *un-happen* and
		// land on the same frozen sentence this whole change exists to remove. A finished
		// walk is the most informative thing this endpoint can report, not the least.
		//
		// `idle` is the only state that defers: no record, or one aged out by
		// `IndexingProgress::read()`'s staleness rule, genuinely has nothing to say.
		if ( 'idle' !== $walk['state'] ) {
			wp_send_json_success(
				array(
					'state'     => $walk['state'],
					'text'      => $walk['text'],
					'detail'    => $walk['detail'],
					'total'     => $total,
					'countText' => $this->indexed_count_text( $total ),
					'percent'   => $walk['percent'],
				)
			);
			return;
		}

		wp_send_json_success(
			array(
				'state'     => $progress['state'],
				'text'      => $progress['text'],
				'detail'    => '',
				'total'     => $total,
				'countText' => $this->indexed_count_text( $total ),
				// Drives the bar. `processed/total` is only meaningful mid-run; a finished
				// or idle queue reports 100 so the bar reads as complete rather than
				// snapping back to empty the instant the work is done.
				'percent'   => $this->indexing_percent( $indexing, $progress['state'], $total ),
			)
		);
	}

	/**
	 * `wp_ajax_wcai_wizard_override` — step 5's "Publish anyway" (D9/FR-014).
	 *
	 * A sibling of `Panel::ajax_override_gate()` rather than a call into it: the wizard's
	 * assets localize the wizard's nonce and not the panel's, so reusing the panel endpoint
	 * would mean shipping a second nonce to this page for one button.
	 *
	 * A backend failure is reported as a failure, not softened. The backend answers 503
	 * when it cannot record the decision rather than a false 200, precisely so a merchant is
	 * never told their widget is live while the gate is still shut — softening that here
	 * would throw away the one guarantee that behaviour exists to give.
	 */
	public function ajax_override_gate(): void {
		if ( ! current_user_can( Panel::capability() ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'woocommerce-ai-chat' ) ),
				403
			);
			return;
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		$result = $this->data->override_quality_gate();
		$status = (int) ( $result['status'] ?? 0 );

		if ( $status < 200 || $status >= 300 ) {
			wp_send_json_error(
				array( 'message' => __( "We couldn't record that just now. Try again in a moment, or publish from your Knowledge Base page.", 'woocommerce-ai-chat' ) ),
				200
			);
			return;
		}

		wp_send_json_success(
			array( 'message' => __( 'Published. Your assistant is answering shoppers now.', 'woocommerce-ai-chat' ) )
		);
	}

	/** "12 items indexed so far", or nothing at all when there is nothing to report yet. */
	private function indexed_count_text( int $total ): string {
		if ( $total < 1 ) {
			return '';
		}

		return sprintf(
			/* translators: %s: the number of indexed items. */
			_n( '%s item indexed so far.', '%s items indexed so far.', $total, 'woocommerce-ai-chat' ),
			number_format_i18n( $total )
		);
	}

	/**
	 * How full to draw step 4's bar, 0-100.
	 *
	 * The bar is a reassurance device, not a measurement, and the honest reading of each
	 * state is what it shows: a live run reports its real fraction; a finished run reports
	 * full; a store with nothing indexed and nothing running reports empty, because a full
	 * bar over an empty index would be the one genuinely misleading combination.
	 *
	 * @param array<string, mixed> $indexing The raw `IndexingProgress` block.
	 * @param string               $state    The shaped state from `KnowledgePage::progress()`.
	 * @param int                  $total    Indexed items the store actually has.
	 */
	private function indexing_percent( array $indexing, string $state, int $total ): int {
		$processed = isset( $indexing['processed'] ) ? (int) $indexing['processed'] : 0;
		$queued    = isset( $indexing['total'] ) ? (int) $indexing['total'] : 0;

		if ( 'running' === $state && $queued > 0 ) {
			return max( 0, min( 100, (int) round( ( $processed / $queued ) * 100 ) ) );
		}

		if ( 'failed' === $state ) {
			return 0;
		}

		return $total > 0 ? 100 : 0;
	}

	public function add_menu_page(): void {
		// Routable but unlisted. Setup is a one-time flow reached from the activation
		// notice and from the panel's pre-activation view; a permanent "Setup" item would
		// still be sitting in the menu long after the store went live.
		//
		// The parent must be a *real, registered* menu slug. Both hiding shortcuts fail
		// on WP 6.x, each by breaking the same mechanism: core's
		// `user_can_access_admin_page()` re-derives the page's hookname at request time
		// via `get_admin_page_parent()`, which resolves the parent by scanning `$submenu`,
		// and then requires the result to be a key of `$_registered_pages`.
		//   - `remove_submenu_page()` during `admin_menu` deletes the `$submenu` record
		//     that resolution reads, so the recomputed hookname stops matching — 403.
		//   - A `null` parent (deprecated since WP 6.1) registers the hookname in the
		//     "no parent" shape while request-time resolution falls back to `$pagenow`,
		//     so the two never match — also 403, for administrators too. That was this
		//     page's shipped state: every "Start setup" click died on
		//     "Sorry, you are not allowed to access this page."
		//
		// So: register honestly under the panel's top-level menu — which makes the access
		// check resolve exactly like the six panel pages that have always worked — and
		// drop only the *visual* row later, on `admin_head` (see `hide_menu_entry()`),
		// which runs after `admin.php` has finished the access check and before
		// `menu-header.php` paints the sidebar.
		//
		// Assets survive the parent change because `is_wizard_hook()` matches on the
		// `_page_<slug>` suffix rather than the parent-derived prefix.
		add_submenu_page(
			Panel::MENU_SLUG,
			__( 'AI Chat — Setup', 'woocommerce-ai-chat' ),
			__( 'Setup', 'woocommerce-ai-chat' ),
			Panel::capability(),
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Remove the wizard's row from the sidebar without unregistering the page.
	 *
	 * Hooked on `admin_head`, and the hook choice is the entire trick: `admin.php` runs
	 * core's access check while including `wp-admin/includes/menu.php`, long before
	 * `admin-header.php` fires `admin_head`, and the sidebar itself is painted by
	 * `menu-header.php` *after* the `<head>` closes. Editing `$submenu` in that window
	 * hides the row on every admin page while `$_registered_pages` — built at
	 * registration time — stays intact, so `admin.php?page=wcai-onboarding` keeps
	 * routing. Editing it any earlier is the 403 documented on `add_menu_page()`.
	 */
	public function hide_menu_entry(): void {
		global $submenu;
		if ( ! isset( $submenu[ Panel::MENU_SLUG ] ) || ! is_array( $submenu[ Panel::MENU_SLUG ] ) ) {
			return;
		}
		foreach ( $submenu[ Panel::MENU_SLUG ] as $index => $item ) {
			if ( self::PAGE_SLUG === ( $item[2] ?? null ) ) {
				unset( $submenu[ Panel::MENU_SLUG ][ $index ] );
			}
		}
	}

	/**
	 * Render the wizard. The step shown is chosen from the activation state:
	 *
	 *   - no tokens → Subscribe (step 1).
	 *   - has tokens but `gate.i_available()` is false → show the failure surface
	 *     the spec calls for (US-005): the activation failed and the merchant sees
	 *     the specific failure from the activate endpoint; a "Retry" button re-enters
	 *     the wizard at the license step.
	 *   - has tokens, `gate.i_available()` is true, and the guided-step row says the
	 *     merchant is still walking steps 4-6 → that step's screen.
	 *   - has tokens, `gate.i_available()` is true, and no guided-step row → Activated.
	 *
	 * The two states that both "have tokens and are serving" are separated by
	 * `OPTION_GUIDED_STEP`, whose absence means *not mid-setup* — see that constant on why
	 * a missing row cannot be read as "start at step 4" without dragging every already-live
	 * store back through a flow it finished.
	 *
	 * …unless the merchant explicitly asked to re-enter activation, which overrides all
	 * three. That override is the fix for a dead end: the panel's 401 banner offers
	 * "Reconnect this store" and pointed here, but the last branch fired first and the
	 * store was shown "your store is connected and the chat widget is live" — the one claim
	 * the banner had just contradicted. `wcai_retry` could not reach the form either, since
	 * it was read *below* that early return. Now both flags are resolved before it.
	 *
	 * The local state cannot be trusted to notice on its own here, which is why an explicit
	 * request is the mechanism. `has_activation()` reads two `wp_options` rows and
	 * `is_widget_available()` reads a 24h cache; after a backend-side rotation both keep
	 * saying "connected" until something calls the backend and learns otherwise.
	 * `SubscriptionGate::record_unauthorized()` now does exactly that from the panel's 401
	 * path, so in practice the state usually *has* caught up by the time the merchant
	 * clicks — but the recovery must not depend on a side effect having fired first.
	 *
	 * @return void — the renderer is an output sink.
	 */
	public function render_page(): void {
		$completed = $this->tokens->has_activation();
		$available = $this->gate->is_widget_available();
		$error     = get_option( 'wai_activation_error' );

		// US-005's "Retry": a store whose activation bound a license but whose subscription
		// is not serving has nothing to re-type on the failure screen, so the retry link
		// asks for the license form back. Re-entering the *whole* flow is right rather than
		// jumping to step 2 alone — activation re-binds and re-consents together, and the
		// backend treats a repeat activate as the rotation path (D17), so a partial re-run
		// would submit a form missing the consent the handler requires. Reconnect re-collects
		// consent for the same reason, and because re-binding is a fresh act of processing.
		//
		// Two flags rather than one because the *copy* differs, not the flow: a merchant
		// re-entering because their subscription lapsed may genuinely need the pricing page,
		// while one whose token was revoked already has a plan and telling them to subscribe
		// again would be wrong.
		//
		// GET parameters with no state change and no privileged effect: they only choose
		// which of two already-permitted views to render, so there is no nonce to check.
		$retrying     = $this->has_query_flag( 'wcai_retry' );
		$reconnecting = $this->has_query_flag( self::QUERY_RECONNECT );
		$reopen       = $retrying || $reconnecting;

		// Where the merchant has reached in the post-activation steps, and which of them to
		// draw. Resolved before the activated-screen branch below because a store mid-flow
		// must not be short-circuited into "you are all set" — that early return is what
		// made steps 4-6 unreachable in the first place.
		$reached = $this->guided_step_reached();
		$viewing = $this->guided_step_viewing( $reached );

		echo '<div class="wcai-root" id="wcai-onboarding"><div class="wcai-shell wcai-wizard">';

		echo '<h1 class="wcai-h1">' . esc_html__( 'Set up AI Chat', 'woocommerce-ai-chat' ) . '</h1>';
		echo '<p class="wcai-sub">' . esc_html__( 'A few quick steps to index your store and take the assistant live.', 'woocommerce-ai-chat' ) . '</p>';

		if ( $completed && $available && ! $reopen && 0 === $reached ) {
			// Nothing left to set up. The step rail would be six ticks and no action,
			// which reads as an unfinished flow rather than a finished one.
			$this->render_activated();
			echo '</div></div>';
			return;
		}

		// Activated, serving, and still walking steps 4-6. This is the branch that used to
		// not exist: the rail drew six steps and the flow ended at three.
		if ( $completed && $available && ! $reopen ) {
			echo '<div class="wcai-wizard-layout">';
			$this->render_step_rail( true, true, false, $viewing, $reached );

			echo '<div class="wcai-card wcai-wizard-card">';
			$this->render_guided_step( $viewing );
			echo '</div></div></div></div>';
			return;
		}

		echo '<div class="wcai-wizard-layout">';
		$this->render_step_rail( $completed && ! $reopen, $available, $reconnecting );

		echo '<div class="wcai-card wcai-wizard-card">';

		if ( ! $completed || $reopen ) {
			if ( $reconnecting ) {
				$this->render_step_reconnect();
			} else {
				$this->render_step_subscribe();
			}

			// The license + consent inputs must be *inside* the form element, or the
			// browser never submits them and activation fails with "A license key is
			// required" no matter what the merchant typed. Subscribe is a plain link
			// step, so it stays outside.
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="wcai-wizard-form">';
			wp_nonce_field( 'wcai_activate' );
			echo '<input type="hidden" name="action" value="wcai_activate" />';
			$this->render_step_license( $error );
			$this->render_step_consent();
			$this->render_submit_button();
			echo '</form>';
		} else {
			// Tokens exist but the gate is closed (US-005): activation itself worked and
			// the subscription did not. Re-running the whole wizard would be misleading,
			// so this is its own surface with a retry that re-enters at the license step.
			$this->render_activation_failed( $error );
		}

		echo '</div></div></div></div>';
	}

	// -- post-activation steps (4-6) ---------------------------------------------


	/**
	 * The furthest post-activation step this store has reached, or `0` when it is not in
	 * the guided flow at all.
	 *
	 * Clamped on read rather than trusted. The row is an integer this plugin writes, but it
	 * is also a `wp_options` row that a migration, a staging-database copy, or a merchant
	 * with WP-CLI can leave holding anything at all — and an out-of-range value here would
	 * pick no branch in `render_guided_step()` and render an empty card. Clamping turns
	 * every unusable value into the nearest usable one.
	 */
	private function guided_step_reached(): int {
		$stored = get_option( self::OPTION_GUIDED_STEP );

		if ( ! is_numeric( $stored ) ) {
			return 0;
		}

		$step = (int) $stored;

		if ( $step < self::STEP_FIRST_GUIDED ) {
			return 0;
		}

		return min( $step, self::STEP_LAST_GUIDED );
	}

	/**
	 * Which post-activation step to draw: the one the rail asked for, else the furthest
	 * reached.
	 *
	 * Bounded *above* by what the merchant has actually reached, so `?wcai_step=6` typed at
	 * a store still on step 4 shows step 4 rather than a colour picker for a widget whose
	 * indexing has not been looked at. Bounded below by step 4 because steps 1-3 are not
	 * addressable this way — they are one page, chosen by activation state, and a request
	 * for "step 2" here would otherwise render nothing.
	 *
	 * Stepping *back* is deliberately allowed: the rail links every reached step, and a
	 * merchant re-reading step 4 from step 6 is reviewing, not un-completing. That is why
	 * this returns a view cursor and `guided_step_reached()` keeps the high-water mark.
	 *
	 * @param int $reached The high-water mark from `guided_step_reached()`.
	 */
	private function guided_step_viewing( int $reached ): int {
		if ( 0 === $reached ) {
			return 0;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- view selection only; the value picks between screens the merchant is already permitted to see and changes nothing. Writes go through `handle_advance()`, which is nonce-checked.
		$raw = $_GET[ self::QUERY_STEP ] ?? '';

		if ( ! is_numeric( $raw ) ) {
			return $reached;
		}

		$asked = (int) $raw;

		if ( $asked < self::STEP_FIRST_GUIDED ) {
			return $reached;
		}

		return min( $asked, $reached );
	}

	/**
	 * Draw one post-activation step.
	 *
	 * `default` rather than an explicit `STEP_INDEXING` case, so a `$viewing` that somehow
	 * escaped both clamps still renders a real screen instead of an empty card.
	 *
	 * @param int $viewing The step being shown.
	 */
	private function render_guided_step( int $viewing ): void {
		switch ( $viewing ) {
			case self::STEP_QUALITY:
				$this->render_step_quality();
				break;
			case self::STEP_COLOUR:
				$this->render_step_colour();
				break;
			default:
				$this->render_step_indexing();
				break;
		}
	}

	/**
	 * The step rail (design step-rail, PRD §10).
	 *
	 * Six steps are drawn, and all six are now screens the merchant actually walks:
	 * Subscribe, License and Consent before activation (one page, three bands), then
	 * Indexing, the quality gate, and the colour prompt after it.
	 *
	 * A step is a **link** exactly when it has been reached, which is only ever true of
	 * steps 4-6 and only once activation has happened. Steps 1-3 are never linked even
	 * after they are done: they are one page selected by activation state, not three
	 * addresses, so a link back to "Consent" would either re-open the whole activation
	 * form or land on the same screen the merchant is already looking at. Steps ahead of
	 * the high-water mark are not linked either — a rail entry that looks clickable and is
	 * not is worse than one that plainly is not yet reachable.
	 *
	 * On the reconnect path step 1 is relabelled rather than dropped. Dropping it would
	 * renumber a rail the merchant may have seen before, and leaving it as "Subscribe"
	 * would have the rail contradicting the card beside it — which spends the reassurance
	 * that the card's copy exists to give: this merchant is not being asked to buy again.
	 *
	 * @param bool $completed    Whether activation has produced tokens.
	 * @param bool $available    Whether the subscription gate is open.
	 * @param bool $reconnecting Whether step 1 is a reconnect rather than a subscribe.
	 * @param int  $viewing      The post-activation step on screen, or 0 when not in that flow.
	 * @param int  $reached      The furthest post-activation step reached, or 0.
	 */
	private function render_step_rail( bool $completed, bool $available, bool $reconnecting = false, int $viewing = 0, int $reached = 0 ): void {
		$steps = array(
			$reconnecting
				? __( 'Reconnect', 'woocommerce-ai-chat' )
				: __( 'Subscribe', 'woocommerce-ai-chat' ),
			__( 'License key', 'woocommerce-ai-chat' ),
			__( 'Consent', 'woocommerce-ai-chat' ),
			__( 'Indexing', 'woocommerce-ai-chat' ),
			__( 'Quality gate', 'woocommerce-ai-chat' ),
			__( 'Widget colour', 'woocommerce-ai-chat' ),
		);

		// The step the rail highlights. Before activation that is step 1 — the whole 1-3
		// page. After it, the post-activation step actually on screen; `$viewing` is
		// authoritative there because the merchant can be reviewing step 4 while having
		// reached step 6, and the highlight has to follow the screen, not the progress.
		$current = $viewing > 0 ? $viewing : ( $completed ? self::STEP_FIRST_GUIDED : 1 );

		echo '<nav class="wcai-step-rail" aria-label="' . esc_attr__( 'Setup steps', 'woocommerce-ai-chat' ) . '">';
		echo '<ol class="wcai-step-list">';

		foreach ( $steps as $index => $label ) {
			$number = $index + 1;
			$active = $number === $current;

			// Steps 1-3 are done exactly when activation produced tokens. A post-activation
			// step is done once the merchant has moved past it — reached it *and* left it —
			// which is why this compares against the high-water mark and not the cursor.
			$done = $number < self::STEP_FIRST_GUIDED
				? ( $completed && ! $active )
				: ( $number < $reached && ! $active );

			// Linkable only backwards, and only over ground already covered. See the
			// docblock: steps 1-3 have no address of their own to link to.
			$linkable = ! $active
				&& $number >= self::STEP_FIRST_GUIDED
				&& $number <= $reached;

			$classes = 'wcai-step-item';
			if ( $done ) {
				$classes .= ' is-done';
			} elseif ( $active ) {
				$classes .= ' is-active';
			}
			if ( $linkable ) {
				$classes .= ' is-linked';
			}

			// The tick and the highlight are colour and glyph only; without this the
			// rail's state is invisible to a screen reader (NFR-045).
			$state_note = $done
				? '<span class="wcai-visually-hidden">' . esc_html__( '(completed)', 'woocommerce-ai-chat' ) . '</span>'
				: '';

			$body = sprintf(
				'<span class="wcai-step-marker" aria-hidden="true">%1$s</span><span class="wcai-step-label">%2$s</span>%3$s',
				$done ? '&#10003;' : esc_html( (string) $number ),
				esc_html( $label ),
				$state_note
			);

			if ( $linkable ) {
				$body = sprintf(
					'<a class="wcai-step-link" href="%1$s">%2$s</a>',
					esc_url( $this->step_url( $number ) ),
					$body
				);
			}

			printf(
				'<li class="%1$s"%2$s>%3$s</li>',
				esc_attr( $classes ),
				$active ? ' aria-current="step"' : '',
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- `$body` is markup assembled above from individually escaped parts; escaping it here would print the tags rather than render them.
				$body
			);
		}

		echo '</ol>';

		// Only before activation. Steps 4-6 *are* their own screens now, so the note that
		// explained their absence would be actively wrong beside a rail that links to them
		// — and the merchant reading it is one click from the first of the three.
		//
		// The note must stay *inside* the `<nav>`: echoed after it, it becomes a third child
		// of the `.wcai-wizard-layout` grid and takes the card's column, which then wraps to
		// a new row at the rail's 230px width.
		if ( 0 === $viewing ) {
			echo '<p class="wcai-step-rail-note">' . esc_html__( 'Steps 4-6 open automatically once your store is connected.', 'woocommerce-ai-chat' ) . '</p>';
		}

		echo '</nav>';
	}

	/** The wizard URL for one post-activation step. */
	private function step_url( int $step ): string {
		return admin_url(
			sprintf( 'admin.php?page=%1$s&%2$s=%3$d', self::PAGE_SLUG, self::QUERY_STEP, $step )
		);
	}

	/**
	 * Handle the admin-post submit: validate nonce + capability, call the backend,
	 * persist tokens, refresh the gate, store an error if any. Always redirects
	 * back to the wizard page so a refresh does not resubmit.
	 */
	public function handle_activate_post(): void {
		if ( ! current_user_can( Panel::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'woocommerce-ai-chat' ) );
		}
		check_admin_referer( 'wcai_activate' );

		$license_key = $this->post_string( 'wcai_license_key' );
		$consent     = $this->post_bool( 'wcai_consent' );
		$site_url    = home_url();

		if ( '' === $license_key ) {
			$this->fail_with( __( 'A license key is required.', 'woocommerce-ai-chat' ) );
		}
		if ( ! $consent ) {
			$this->fail_with( __( 'You must accept the data-processing terms to activate WooCommerce AI Chat.', 'woocommerce-ai-chat' ) );
		}

		$outbound = Compatibility::check_outbound_https( $this->backend->get_base_url() );
		if ( ! $outbound['ok'] ) {
			$this->fail_with(
				sprintf(
					/* translators: 1: backend host, 2: error message. */
					__( 'Cannot reach the backend at %1$s: %2$s. The plugin needs outbound HTTPS to the SaaS backend.', 'woocommerce-ai-chat' ),
					$outbound['host'],
					$outbound['error']
				)
			);
		}

		$fingerprint = get_option( WAI_OPTION_SITE_FINGERPRINT );
		if ( ! is_string( $fingerprint ) || '' === $fingerprint ) {
			$fingerprint = wp_generate_uuid4();
			update_option( WAI_OPTION_SITE_FINGERPRINT, $fingerprint );
		}

		// Through `LicenseActivator`, which supplies the store token this install already
		// holds as proof of the existing binding — that is what lets a genuinely migrated
		// store re-activate on its own instead of needing an operator to unlock the
		// rebind. The token is deliberately read *there* and never here: this class also
		// builds the wizard's `wp_localize_script` payload, and NFR-019 keeps the
		// decrypted store token out of any file that does (see that class's docblock).
		$result = ( new LicenseActivator( $this->tokens, $this->backend ) )->activate( $license_key, $fingerprint, $site_url, WAI_VERSION );

		if ( 401 === $result['status'] ) {
			$this->fail_with( __( 'The license key you entered is not recognised. Check it and try again.', 'woocommerce-ai-chat' ) );
		}
		if ( 409 === $result['status'] ) {
			// The license is bound to a different store (D16). A plain-language message
			// is more useful than the operator's error envelope: "already activated
			// somewhere else" rather than "code: conflict".
			$this->fail_with( __( 'This license is already activated on another store. Contact support to reset the binding if the original store is no longer in use.', 'woocommerce-ai-chat' ) );
		}
		if ( $result['status'] < 200 || $result['status'] >= 300 ) {
			// `is_array(...)` means the backend sent `message` as an array (a malformed or
			// future-shaped error body) — fall back to the same default used when the key is
			// absent entirely, rather than an empty string. `fail_with()`'s renderer only
			// prints a banner when the message is non-empty, so `''` was a silent failure at
			// exactly the moment a merchant most needs to see why activation didn't work.
			$msg = is_array( $result['body']['message'] ?? null )
				? 'Activation failed.'
				: (string) ( $result['body']['message'] ?? 'Activation failed.' );
			$this->fail_with( $msg );
		}

		$body        = is_array( $result['body'] ) ? $result['body'] : array();
		$store_token = is_string( $body['store_token'] ?? null ) ? (string) $body['store_token'] : '';
		$widget_tok  = is_string( $body['widget_token'] ?? null ) ? (string) $body['widget_token'] : '';
		// The backend returns its own `store_token` plaintext; we never had the store
		// id before activation, so the response shape's `subscription.plan` is the
		// only durable fact we need to persist too. The store id itself arrives on the
		// next `/v1/auth/status` call but we record placeholders now — the gate refresh
		// runs immediately and surfaces them.
		if ( '' === $store_token || '' === $widget_tok ) {
			$this->fail_with( __( 'The backend returned a partial response. Try again or contact support.', 'woocommerce-ai-chat' ) );
		}

		$this->tokens->persist( $store_token, $widget_tok, /* store_id unknown until first /status */ '', $license_key );
		update_option(
			WAI_OPTION_CONSENT,
			array(
				'consented_at' => time(),
				'dpa_version'  => null, // populated when a DPA artefact version is wired.
			)
		);
		delete_option( 'wai_activation_error' );

		// Refresh the gate now so the merchant's first visit to the dashboard shows
		// the correct status pill rather than the brief "unknown" from a cold cache.
		$this->gate->refresh( true );

		// Kick the first sync now rather than waiting for tonight's manifest: step 4
		// tells the merchant their products are being read, and that is only true if
		// something started reading them. Idempotent — a reconnect with a walk already
		// in flight does not start a competing one (`IngestionScheduler`'s pending-head
		// check), and the empty-state promise of "a first sync usually finishes within
		// a few minutes" is only honest if the first sync is actually running.
		if ( null !== $this->ingestion ) {
			$this->ingestion->enqueue_full_resync();
		}

		// Open the guided flow at step 4. Writing this row is what makes the wizard
		// continue past activation rather than jumping to "you are all set" — without it
		// the rail's last three steps are a promise nothing keeps, which is exactly the
		// state this replaced. See `OPTION_GUIDED_STEP` on why its absence means "done".
		update_option( self::OPTION_GUIDED_STEP, self::STEP_FIRST_GUIDED );

		$this->redirect_to_wizard( self::STEP_FIRST_GUIDED );
	}

	/**
	 * Move between the post-activation steps, or leave the flow.
	 *
	 * One handler for both because they are one form: the forward button and the skip
	 * button submit the same fields and differ only in which `name` arrives. Splitting
	 * them would mean two nonces and two capability checks guarding the same write.
	 */
	public function handle_advance(): void {
		if ( ! current_user_can( Panel::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'woocommerce-ai-chat' ) );
		}
		check_admin_referer( self::NONCE_GUIDED );

		// A flow that is not active cannot be advanced. The row was deleted when the
		// merchant finished or skipped, and re-creating it here — from a stale step-4
		// form resubmitted out of browser history — would reopen guided setup on a
		// store that already left it. Redirecting without writing is the same response
		// a fresh visit to the wizard page gets.
		if ( 0 === $this->guided_step_reached() ) {
			$this->redirect_to_wizard();
		}

		if ( '' !== $this->post_string( 'wcai_skip' ) ) {
			$this->finish_guided_flow();
			return;
		}

		$next = (int) $this->post_string( 'wcai_next' );

		// Past the last step is the same act as finishing it — the forward button on step 6
		// posts `7`, and treating that as "clamp back to 6" would leave the merchant on the
		// colour screen having just pressed the button that ends setup.
		if ( $next > self::STEP_LAST_GUIDED ) {
			$this->finish_guided_flow();
			return;
		}

		$this->advance_to( $next );
	}

	/**
	 * Save the accent colour chosen on step 6, then finish.
	 *
	 * ## Why the whole settings array is written and not just the one field
	 *
	 * `WidgetSettings::save()` sanitizes a *complete* settings array, filling anything
	 * absent from its defaults — that is right for the Settings page, which posts every
	 * field, and catastrophic here, where the form has one. Passing only `primary_color`
	 * would silently reset the merchant's title, placeholder, position, triggers, and
	 * disclaimer to defaults as a side effect of picking a colour. Merging over `all()`
	 * first is what makes this a single-field edit.
	 */
	public function handle_colour_save(): void {
		if ( ! current_user_can( Panel::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'woocommerce-ai-chat' ) );
		}
		check_admin_referer( self::NONCE_GUIDED );

		// Skip has to be honoured here too: it is rendered inside *this* form on step 6, so
		// a merchant who presses it arrives at this handler, not `handle_advance()`.
		if ( '' !== $this->post_string( 'wcai_skip' ) ) {
			$this->finish_guided_flow();
			return;
		}

		// The auto-match checkbox wins over the picker's value, exactly as the Settings page
		// resolves the same pair: an empty `primary_color` is what makes `accent()`
		// re-detect the theme on every read, so "match my theme" *is* storing nothing.
		$colour = $this->post_bool( 'primary_color_auto' )
			? ''
			: $this->post_string( 'primary_color' );

		$this->widget->save(
			array_merge(
				$this->widget->all(),
				array( 'primary_color' => $colour )
			)
		);

		$this->finish_guided_flow();
	}

	/**
	 * Record that the merchant reached a step, and show it.
	 *
	 * The stored value only ever climbs. Stepping back through the rail to re-read an
	 * earlier screen is reviewing, not un-completing, and a cursor that fell back would
	 * make the rail forget the steps beyond it and re-lock links the merchant had earned.
	 */
	private function advance_to( int $step ): void {
		$target = max( self::STEP_FIRST_GUIDED, min( $step, self::STEP_LAST_GUIDED ) );

		update_option(
			self::OPTION_GUIDED_STEP,
			max( $this->guided_step_reached(), $target )
		);

		$this->redirect_to_wizard( $target );
	}

	/**
	 * Leave the guided flow, by finishing it or by skipping it.
	 *
	 * Deleting the row rather than writing a "done" sentinel: the flow is over in both
	 * cases, `guided_step_reached()` reads a missing row as "not mid-setup", and one fewer
	 * `wai_*` value is one fewer thing for `Lifecycle::uninstall()` to have to know about.
	 */
	private function finish_guided_flow(): void {
		delete_option( self::OPTION_GUIDED_STEP );
		$this->redirect_to_wizard();
	}

	/**
	 * Enqueue the wizard's CSS/JS only on its own admin page (so a merchant on /wp-admin
	 * reading orders, not onboarding, does not load them).
	 *
	 * @param string $hook The hook suffix WordPress sets for the current admin page.
	 */
	public function enqueue_step_assets( $hook ): void {
		// The hook prefix is derived from the *translated* parent menu title, so it
		// cannot be hard-coded — see `Panel::hook_matches_slug()` on the same problem.
		if ( ! self::is_wizard_hook( (string) $hook ) ) {
			return;
		}
		wp_enqueue_style(
			'wcai-design-system',
			WAI_PLUGIN_URL . 'admin/design-system.css',
			array(),
			WAI_VERSION
		);
		wp_enqueue_style(
			'wcai-wizard',
			WAI_PLUGIN_URL . 'admin/wizard.css',
			array( 'wcai-design-system' ),
			WAI_VERSION
		);
		wp_enqueue_script(
			'wcai-wizard',
			WAI_PLUGIN_URL . 'admin/wizard.js',
			array(),
			WAI_VERSION,
			true
		);
		wp_localize_script(
			'wcai-wizard',
			'wcaiWizard',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( self::NONCE_ACTION ),
				// Only the two states the probe can actually report. Strings for "valid"
				// and "invalid" were localized here at first and never used, because the
				// probe does not judge the key — shipping them would have been a
				// translator asked to translate a message no merchant can ever see.
				//
				// The step-4/5 strings below are the ones the *client* composes; every
				// other line on those screens is rendered by PHP and travels in the
				// markup, so it is not repeated here.
				'i18n'    => array(
					'checking'        => __( 'Checking connection…', 'woocommerce-ai-chat' ),
					'unreachable'     => __( "Can't reach the licensing service right now. Check your connection and try again.", 'woocommerce-ai-chat' ),
					'indexOffline'    => __( "Can't reach the AI service to check progress. Indexing carries on in the background.", 'woocommerce-ai-chat' ),
					'indexBackground' => __( 'Indexing is still running in the background. You can carry on with setup — the Knowledge Base page will show progress as it goes.', 'woocommerce-ai-chat' ),
					'overrideWorking' => __( 'Publishing…', 'woocommerce-ai-chat' ),
					'overrideFailed'  => __( "We couldn't record that just now. Try again in a moment.", 'woocommerce-ai-chat' ),
				),
			)
		);

		do_action( 'wcai_enqueue_wizard_assets' );
	}

	/**
	 * Whether an admin hook suffix belongs to the wizard page.
	 *
	 * Submenu hooks are `<sanitized-parent-title>_page_<slug>`, and the parent title is
	 * translated — so the prefix differs per locale and cannot be compared against a
	 * literal. Anchoring on the slug at the end of the string is locale-independent.
	 */
	private static function is_wizard_hook( string $hook ): bool {
		$needle = '_page_' . self::PAGE_SLUG;
		$at     = strrpos( $hook, $needle );

		return false !== $at && strlen( $hook ) === $at + strlen( $needle );
	}

	// -- rendering --------------------------------------------------------------


	private function render_step_subscribe(): void {
		$pricing_url = defined( 'WAI_PRICING_URL' ) ? WAI_PRICING_URL : 'https://wcai.example.invalid/pricing';

		echo '<section class="wcai-wizard-step">';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Subscribe to a plan', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="wcai-step-copy">' . esc_html__( 'AI Chat runs on a subscription managed on our pricing page. You will pick a plan there, then return here with your license key to finish setup.', 'woocommerce-ai-chat' ) . '</p>';
		printf(
			'<a class="button wcai-btn" target="_blank" rel="noopener noreferrer" href="%1$s">%2$s<span class="wcai-visually-hidden"> %3$s</span></a>',
			esc_url( $pricing_url ),
			esc_html__( 'Go to pricing', 'woocommerce-ai-chat' ),
			esc_html__( '(opens in a new tab)', 'woocommerce-ai-chat' )
		);
		echo '</section>';
	}

	/**
	 * Step 1, when the merchant arrived from the panel's "Reconnect this store" banner.
	 *
	 * Replaces the Subscribe step rather than adding to it. This merchant already bought a
	 * plan — their token was rotated or revoked, not their subscription — and opening the
	 * recovery flow with "Subscribe to a plan" and a link to pricing would read as being
	 * asked to pay twice.
	 *
	 * The license key is the one thing they must supply again, and it is the same key: the
	 * backend treats a repeat activate from the same site fingerprint as a rebind and
	 * re-issues both tokens (D17), which is precisely the recovery. It is worth saying so,
	 * because a merchant who assumes a *new* key is needed will go looking for one that
	 * does not exist and open a support ticket instead of finishing in ten seconds.
	 */
	private function render_step_reconnect(): void {
		echo '<section class="wcai-wizard-step">';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Reconnect this store', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="wcai-step-copy">' . esc_html__( "This store's connection to the AI service has expired, so the assistant is offline and the dashboard cannot load your data. Your subscription is unaffected — re-enter the same license key below to issue a fresh connection.", 'woocommerce-ai-chat' ) . '</p>';
		echo '</section>';
	}

	/**
	 * Step 2 — the license key, with the design's three inline states.
	 *
	 * The states are driven by `wizard.js` against `ajax_check_license()`; the markup
	 * here carries the containers and the server-rendered error from a *failed previous
	 * activation*, which is a different thing from the live probe: one is the outcome of
	 * a real binding attempt, the other is a pre-flight check.
	 *
	 * @param mixed $error The stored activation error, if the last attempt failed.
	 */
	private function render_step_license( $error ): void {
		echo '<section class="wcai-wizard-step">';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Enter your license key', 'woocommerce-ai-chat' ) . '</h2>';

		if ( is_string( $error ) && '' !== $error ) {
			echo '<div class="wcai-notice wcai-notice-err" role="alert"><p>' . esc_html( $error ) . '</p></div>';
		}

		echo '<div class="wcai-field">';
		echo '<label class="wcai-label" for="wcai_license_key">' . esc_html__( 'License key', 'woocommerce-ai-chat' ) . '</label>';
		echo '<input type="text" id="wcai_license_key" name="wcai_license_key" class="wcai-input wcai-input-mono" ';
		echo 'autocomplete="off" spellcheck="false" placeholder="WCAI-XXXX-XXXX-XXXX" ';
		echo 'aria-describedby="wcai-license-status" />';
		// `aria-live` so the probe's verdict is announced rather than only painted. It is
		// `polite`, not `assertive`: the merchant is still typing, and interrupting them
		// mid-field on every keystroke would be worse than silence.
		echo '<p class="wcai-help" id="wcai-license-status" data-wcai-license-status aria-live="polite"></p>';
		echo '</div>';

		echo '</section>';
	}

	private function render_step_consent(): void {
		$dpa_url = defined( 'WAI_DPA_URL' ) ? WAI_DPA_URL : 'https://wcai.example.invalid/dpa';

		echo '<section class="wcai-wizard-step">';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Data processing consent', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="wcai-step-copy">' . esc_html__( 'To answer shopper questions, AI Chat sends your store\'s product and policy content to our processing service, where it is indexed and used solely to generate replies for your storefront. Content is processed under our Data Processing Agreement and is not used to train external models. You can revoke consent and delete indexed data at any time from Settings.', 'woocommerce-ai-chat' ) . '</p>';

		echo '<label class="wcai-consent">';
		echo '<input type="checkbox" name="wcai_consent" value="1" data-wcai-consent required /> ';
		echo '<span>';
		echo wp_kses(
			sprintf(
				/* translators: %s: DPA URL. */
				__( 'I agree to the processing of my store data as described above, under the <a href="%s" target="_blank" rel="noopener noreferrer">Data Processing Agreement</a>.', 'woocommerce-ai-chat' ),
				esc_url( $dpa_url )
			),
			array(
				'a' => array(
					'href'   => array(),
					'target' => array(),
					'rel'    => array(),
				),
			)
		);
		echo '</span></label>';
		echo '</section>';
	}

	/**
	 * The submit control only. The surrounding <form> (and its nonce + action field)
	 * is opened by `render_page()` so that the license and consent inputs fall inside
	 * it; emitting a second form here would leave those inputs unsubmitted.
	 *
	 * The button starts disabled and `wizard.js` enables it once the key is non-empty and
	 * consent is ticked. That is a convenience, not the enforcement: `handle_activate_post()`
	 * re-checks both server-side, because a disabled attribute is a suggestion to a browser
	 * and nothing at all to a crafted POST.
	 */
	private function render_submit_button(): void {
		echo '<div class="wcai-wizard-actions">';
		echo '<button type="submit" class="button wcai-btn" data-wcai-submit disabled>';
		echo esc_html__( 'Activate', 'woocommerce-ai-chat' );
		echo '</button>';
		echo '</div>';
	}

	/**
	 * US-005 — activation bound a license but the subscription is not serving.
	 *
	 * Separated from the ordinary error path because the merchant's next action differs:
	 * there is nothing to re-type, so the useful controls are a retry and a route to
	 * support, not the license field again.
	 *
	 * @param mixed $error The stored activation error, if any.
	 */
	private function render_activation_failed( $error ): void {
		echo '<section class="wcai-wizard-step">';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Your subscription is not active yet', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="wcai-step-copy">' . esc_html__( 'This store is connected, but the subscription behind its license is not currently serving. The widget stays offline until it is.', 'woocommerce-ai-chat' ) . '</p>';

		if ( is_string( $error ) && '' !== $error ) {
			echo '<div class="wcai-notice wcai-notice-warn" role="alert"><p>' . esc_html( $error ) . '</p></div>';
		}

		echo '<div class="wcai-wizard-actions">';
		printf(
			'<a class="button wcai-btn" href="%1$s">%2$s</a>',
			esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&wcai_retry=1' ) ),
			esc_html__( 'Retry activation', 'woocommerce-ai-chat' )
		);
		printf(
			'<a class="button wcai-btn wcai-btn-secondary" href="%1$s">%2$s</a>',
			esc_url( admin_url( 'admin.php?page=' . Panel::HEALTH_CHECK_SLUG ) ),
			esc_html__( 'Open Health Check', 'woocommerce-ai-chat' )
		);
		echo '</div>';
		echo '</section>';
	}

	/**
	 * Step 4 — indexing progress.
	 *
	 * ## Why this screen renders before it knows anything
	 *
	 * The status line is filled by `wizard.js` polling `ajax_indexing()`, not by a read
	 * taken here. Indexing is the one thing on the wizard that *changes while the merchant
	 * watches it*: a store that has just activated is mid-first-push, so a number rendered
	 * server-side is stale by the time it is read and the screen would need a manual
	 * refresh to tell the truth. Polling also keeps a slow backend out of the page's own
	 * render path — the step paints, and the status arrives when it arrives.
	 *
	 * ## Why "Continue" is never disabled
	 *
	 * Indexing runs in the background and finishes on its own schedule; it is not a
	 * precondition for anything later in this flow, and the merchant does not have to sit
	 * and watch it. Gating the button on a completed index would trap a merchant behind a
	 * backend they cannot influence — exactly the dead end the rest of this class exists to
	 * avoid — and would do it on a store whose widget is already live.
	 *
	 */
	private function render_step_indexing(): void {
		echo '<section class="wcai-wizard-step">';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Indexing your store', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="wcai-step-copy">' . esc_html__( "We're reading your products, categories, and pages so the assistant can answer from them. This runs in the background and usually takes a few minutes — you can carry on with setup while it works.", 'woocommerce-ai-chat' ) . '</p>';

		// `aria-live="polite"`, because the content of this region is replaced by the poll
		// rather than by a navigation: without it a screen-reader user is never told the
		// count moved. Polite rather than assertive — progress is not an interruption.
		echo '<div class="wcai-index-status" data-wcai-index-status aria-live="polite">';

		echo '<div class="wcai-index-bar" data-wcai-index-bar>';
		echo '<span class="wcai-index-fill" data-wcai-index-fill style="width:0%"></span>';
		echo '</div>';

		// The server-rendered default is deliberately a statement about *this page*, not
		// about the store: until the first poll answers, "checking" is the only thing that
		// is actually known. A merchant with JavaScript off keeps this line, which is why it
		// has to read sensibly on its own rather than as a placeholder.
		echo '<p class="wcai-index-line" data-wcai-index-line>' . esc_html__( 'Checking indexing progress…', 'woocommerce-ai-chat' ) . '</p>';
		// Which phase is running and roughly how much longer, when the local walk record can
		// say (`KnowledgePage::resync_progress()`). Empty until then, and empty on the
		// backend-shaped fallback, which has no such detail to give.
		echo '<p class="wcai-index-detail" data-wcai-index-detail></p>';
		echo '<p class="wcai-index-count" data-wcai-index-count></p>';

		echo '</div>';
		echo '</section>';

		$this->render_guided_nav(
			self::STEP_INDEXING,
			__( 'Continue', 'woocommerce-ai-chat' )
		);
	}

	/**
	 * Step 5 — the content-quality gate (§5.2, D9/FR-014).
	 *
	 * ## Why this one reads the backend synchronously and step 4 does not
	 *
	 * A quality score is a verdict on a store's content, not a moving counter: it does not
	 * change while the merchant reads it, so there is nothing for a poll to keep up with.
	 * Rendering it server-side puts the number in the HTML — no empty card that fills a
	 * moment later, and a screen that still says something useful with JavaScript off. The
	 * read is bounded by `merchant_get()`'s 5s budget, and a failure degrades to the copy
	 * below rather than to a blank card.
	 *
	 * The shaping is `KnowledgePage`'s own `quality_block()` rather than a second reading of
	 * the same response. `passed` is the backend's answer and is never re-derived here —
	 * same rule the Knowledge Base page follows, and for the same reason: two places
	 * deciding whether a store may go live is one place too many.
	 *
	 */
	private function render_step_quality(): void {
		$response = $this->data->knowledge( 1, 0 );
		$body     = is_array( $response['body'] ?? null ) ? $response['body'] : array();
		$status   = (int) ( $response['status'] ?? 0 );
		$readable = $status >= 200 && $status < 300 && is_array( $body['quality'] ?? null );

		echo '<section class="wcai-wizard-step">';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Content quality check', 'woocommerce-ai-chat' ) . '</h2>';

		if ( ! $readable ) {
			// The score is the entire content of this step, so a failed read cannot be
			// papered over with a zero — a store shown "0/100" would believe its content is
			// unusable when all that happened is one request did not come back.
			echo '<p class="wcai-step-copy">' . esc_html__( "We couldn't reach the AI service to check your content quality just now. Your setup is not blocked by this — you can continue, and the score will be waiting on your Knowledge Base page.", 'woocommerce-ai-chat' ) . '</p>';
			echo '</section>';
			$this->render_guided_nav( self::STEP_QUALITY, __( 'Continue', 'woocommerce-ai-chat' ) );
			return;
		}

		$quality = $this->knowledge->quality_block( $body['quality'] );

		echo '<p class="wcai-step-copy">' . esc_html__( 'This is how much the assistant has to work with. A higher score means more of your shoppers get a real answer instead of being sent to contact you.', 'woocommerce-ai-chat' ) . '</p>';

		printf(
			'<div class="wcai-score %1$s"><p class="wcai-score-value">%2$s<span class="wcai-score-max">/100</span></p><p class="wcai-score-verdict">%3$s</p></div>',
			$quality['passed'] ? 'is-passing' : 'is-below',
			esc_html( number_format_i18n( (int) $quality['score'] ) ),
			esc_html( (string) $quality['verdict'] )
		);

		if ( ! empty( $quality['improvements'] ) ) {
			echo '<div class="wcai-score-improve">';
			echo '<h3 class="wcai-h3">' . esc_html__( 'How to improve your score', 'woocommerce-ai-chat' ) . '</h3>';
			echo '<ul>';
			foreach ( $quality['improvements'] as $line ) {
				echo '<li>' . esc_html( (string) $line ) . '</li>';
			}
			echo '</ul>';
			echo '</div>';
		}

		// The override, and only where it means something. `canOverride` is the backend's
		// "below the bar", and `overridden` is a standing decision the merchant already
		// made — offering it twice would invite them to fix something that is not broken.
		if ( ! empty( $quality['canOverride'] ) && empty( $quality['overridden'] ) ) {
			echo '<div class="wcai-score-override" data-wcai-override-box>';
			echo '<p>' . esc_html__( 'You can publish the assistant now and keep improving your content afterwards. Answers may be less accurate until your score improves.', 'woocommerce-ai-chat' ) . '</p>';
			echo '<button type="button" class="button wcai-btn wcai-btn-secondary" data-wcai-wizard-override>' . esc_html__( 'Publish anyway', 'woocommerce-ai-chat' ) . '</button>';
			echo '<p class="wcai-help" data-wcai-override-status role="status"></p>';
			echo '</div>';
		} elseif ( ! empty( $quality['overridden'] ) ) {
			echo '<p class="wcai-help">' . esc_html__( 'You chose to publish below the quality bar. The assistant is answering now.', 'woocommerce-ai-chat' ) . '</p>';
		}

		echo '</section>';

		$this->render_guided_nav( self::STEP_QUALITY, __( 'Continue', 'woocommerce-ai-chat' ) );
	}

	/**
	 * Step 6 — the widget's accent colour (US-007, AX-002).
	 *
	 * Writes the same `primary_color` setting the Settings page owns, through the same
	 * `WidgetSettings` sanitizer, so the wizard is a shortcut into that setting rather than
	 * a second copy of it. An empty value means "follow the theme", which is why the
	 * auto-match checkbox is a real state and not a UI convenience — see
	 * `WidgetSettings::accent()`.
	 *
	 * The swatch preview is drawn from the *resolved* accent, including AX-002's contrast
	 * darkening, because that is the colour the storefront will actually paint. Showing the
	 * merchant their raw pick next to a widget rendering a darker one is the surprise this
	 * avoids.
	 *
	 */
	private function render_step_colour(): void {
		$chosen = (string) $this->widget->get( 'primary_color' );
		$accent = $this->widget->accent();
		$auto   = '' === $chosen;

		// The form opens *outside* the step band and the band closes before the buttons, so
		// the actions land as a sibling of `.wcai-wizard-step` exactly as they do on steps 4
		// and 5. Nested inside it they lose their separator rule — `.wcai-wizard-step
		// .wcai-wizard-actions` zeroes the border and padding — and the buttons end up flush
		// against the colour picker while the other two steps have a rule above theirs.
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="wcai-wizard-form">';
		wp_nonce_field( self::NONCE_GUIDED );
		echo '<input type="hidden" name="action" value="wcai_wizard_colour" />';

		echo '<section class="wcai-wizard-step">';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Pick your widget colour', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="wcai-step-copy">' . esc_html__( 'This is the colour of the chat button and the panel header on your storefront. It starts matched to your theme — change it here if you want something different.', 'woocommerce-ai-chat' ) . '</p>';

		echo '<div class="wcai-colour-row">';
		printf(
			'<span class="wcai-colour-swatch" data-wcai-colour-swatch style="background:%s"></span>',
			esc_attr( $accent['color'] )
		);
		echo '<div class="wcai-colour-fields">';
		echo '<label class="wcai-label" for="wcai-wizard-colour">' . esc_html__( 'Widget colour', 'woocommerce-ai-chat' ) . '</label>';
		printf(
			'<input type="color" id="wcai-wizard-colour" name="primary_color" value="%s" data-wcai-colour-input />',
			esc_attr( '' !== $chosen ? $chosen : $accent['color'] )
		);
		printf(
			'<label class="wcai-inline-check"><input type="checkbox" name="primary_color_auto" value="1" %1$s data-wcai-colour-auto /> %2$s</label>',
			checked( $auto, true, false ),
			esc_html__( 'Match my theme automatically', 'woocommerce-ai-chat' )
		);
		echo '</div>';
		echo '</div>';

		// AX-002's darkening is stated rather than applied silently. A merchant who picks a
		// pale yellow and is shown a brown swatch with no explanation reads it as the
		// picker being broken.
		if ( ! empty( $accent['adjusted'] ) ) {
			printf(
				'<p class="wcai-help">%s</p>',
				esc_html(
					sprintf(
						/* translators: 1: the colour the merchant picked, 2: the darkened colour actually used. */
						__( 'Darkened from %1$s to %2$s so the text on it stays readable.', 'woocommerce-ai-chat' ),
						(string) $accent['original'],
						(string) $accent['color']
					)
				)
			);
		}

		echo '</section>';

		$this->render_guided_buttons(
			self::STEP_COLOUR,
			__( 'Save and finish', 'woocommerce-ai-chat' )
		);

		echo '</form>';
	}

	/**
	 * The navigation every post-activation step ends with, wrapped in its own form.
	 *
	 * Steps 4 and 5 have no inputs of their own, so the form exists only to carry the
	 * buttons. Step 6 has a colour field and opens its own form, so it calls
	 * `render_guided_buttons()` directly — the two must not nest.
	 *
	 * @param int    $current       The step being shown.
	 * @param string $primary_label The forward button's text.
	 */
	private function render_guided_nav( int $current, string $primary_label ): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="wcai-wizard-form">';
		wp_nonce_field( self::NONCE_GUIDED );
		echo '<input type="hidden" name="action" value="wcai_wizard_advance" />';
		$this->render_guided_buttons( $current, $primary_label );
		echo '</form>';
	}

	/**
	 * Forward, back, and skip.
	 *
	 * ## Why skip is a submit button and not a link
	 *
	 * Skipping *writes*: it deletes the guided-step row, which is what stops the flow
	 * re-opening on the next visit. A link would put that write behind a GET, where a
	 * browser prefetch or a link-scanning security plugin can fire it without the merchant
	 * clicking anything. Posting it through the same nonce'd form as the forward button
	 * costs one extra `name` attribute and closes that off entirely.
	 *
	 * @param int    $current       The step being shown.
	 * @param string $primary_label The forward button's text.
	 */
	private function render_guided_buttons( int $current, string $primary_label ): void {
		printf( '<input type="hidden" name="wcai_from" value="%d" />', (int) $current );

		echo '<div class="wcai-wizard-actions">';

		printf(
			'<button type="submit" class="button wcai-btn" name="wcai_next" value="%1$d">%2$s</button>',
			(int) min( $current + 1, self::STEP_LAST_GUIDED + 1 ),
			esc_html( $primary_label )
		);

		if ( $current > self::STEP_FIRST_GUIDED ) {
			printf(
				'<a class="button wcai-btn wcai-btn-secondary" href="%1$s">%2$s</a>',
				esc_url( $this->step_url( $current - 1 ) ),
				esc_html__( 'Back', 'woocommerce-ai-chat' )
			);
		}

		// Always offered, on every step, including the last. The merchant's store is
		// already live by this point — none of these three screens is a precondition for
		// anything — so there must never be a state in this flow with no way out of it.
		printf(
			'<button type="submit" class="wcai-step-skip" name="wcai_skip" value="1">%s</button>',
			esc_html__( 'Skip the rest of setup', 'woocommerce-ai-chat' )
		);

		echo '</div>';

		// Reassurance that "skip" is not "lose". Everything on these three screens has a
		// permanent home in the panel, and a merchant who does not know that will sit
		// through steps they did not need.
		printf(
			'<p class="wcai-help">%s</p>',
			esc_html__( 'You can change any of this later from your AI Chat dashboard.', 'woocommerce-ai-chat' )
		);
	}

	/**
	 * US-004 — the go-live confirmation.
	 *
	 * The design pairs the tick with the two things a merchant wants next: seeing the
	 * assistant on their own storefront, and the dashboard. Indexing progress is
	 * deliberately *not* claimed here — `MerchantHealthResponse.indexing` is still a
	 * hardcoded `idle/0/0` on the backend, and a progress bar wired to it would animate
	 * a number that no service is computing.
	 */
	private function render_activated(): void {
		$state = $this->gate->cached_state();

		echo '<div class="wcai-card wcai-activated">';
		echo '<div class="wcai-activated-mark" aria-hidden="true">&#10003;</div>';
		echo '<div>';
		echo '<h2 class="wcai-h2">' . esc_html__( 'Your store is connected and the chat widget is live.', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="wcai-muted">' . esc_html__( 'Shoppers can now ask questions on your storefront. Indexing continues in the background.', 'woocommerce-ai-chat' ) . '</p>';
		echo '<p class="wcai-muted">' . esc_html__( 'Next: the Knowledge Base page shows indexing progress and the content-quality score, and is where you can publish anyway if your score is still below the quality gate.', 'woocommerce-ai-chat' ) . '</p>';

		printf(
			'<p class="wcai-help">%s</p>',
			esc_html(
				sprintf(
					/* translators: %s: the subscription status, e.g. "active". */
					__( 'Subscription: %s', 'woocommerce-ai-chat' ),
					(string) $state['status']
				)
			)
		);

		echo '<div class="wcai-wizard-actions">';
		printf(
			// Routes to the Knowledge Base, not the generic Overview page — that's where
			// the rail's steps 4-5 (Indexing, Quality gate) actually live, so "next" after
			// activation lands the merchant on the next actionable screen rather than
			// leaving them to find it from the nav themselves.
			'<a class="button wcai-btn" href="%1$s">%2$s</a>',
			esc_url( admin_url( 'admin.php?page=' . Panel::KNOWLEDGE_SLUG ) ),
			esc_html__( 'Open the Knowledge Base', 'woocommerce-ai-chat' )
		);
		printf(
			'<a class="button wcai-btn wcai-btn-secondary" target="_blank" rel="noopener noreferrer" href="%1$s">%2$s<span class="wcai-visually-hidden"> %3$s</span></a>',
			esc_url( home_url( '/' ) ),
			esc_html__( 'Preview on my storefront', 'woocommerce-ai-chat' ),
			esc_html__( '(opens in a new tab)', 'woocommerce-ai-chat' )
		);
		echo '</div>';

		echo '</div></div>';
	}

	// -- helpers --------------------------------------------------------------


	/**
	 * Whether a `?flag=1` view-selector is present on the request.
	 *
	 * Both callers pick between views the current user is already permitted to see, and
	 * neither changes state, so there is nothing for a nonce to protect — see
	 * `render_page()`. The value is `sanitize_key`'d before comparison regardless.
	 */
	private function has_query_flag( string $key ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- view selection only; no state change. See docblock.
		$raw = $_GET[ $key ] ?? '';
		return is_string( $raw ) && '1' === sanitize_key( wp_unslash( $raw ) );
	}

	private function post_string( string $key ): string {
		$val = $_POST[ $key ] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in handle_submit().
		return is_string( $val ) ? sanitize_text_field( $val ) : '';
	}

	/**
	 * The nonce and capability are both checked in `handle_submit()` before either
	 * accessor runs, so the read is verified — the sniff just cannot follow that across
	 * the method boundary. Unlike `post_string()`, there is no `sanitize_*` call to
	 * clear the taint (a boolean cast is the sanitization), so the comparison on the
	 * return line is flagged too and needs its own suppression.
	 */
	private function post_bool( string $key ): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified in handle_submit().
		$val = $_POST[ $key ] ?? false;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- same read, still verified.
		return '1' === $val || true === $val || 1 === $val;
	}

	/**
	 * Record a plain-language failure message and redirect back to the wizard page,
	 * so the failure is shown as part of the form the merchant just tried to submit
	 * rather than a free-standing error page.
	 */
	private function fail_with( string $message ): void {
		update_option( 'wai_activation_error', $message );
		$this->redirect_to_wizard();
	}

	/**
	 * Back to the wizard, optionally at a named post-activation step.
	 *
	 * Every write in this class ends here rather than rendering its own result, so a
	 * refresh after any of them re-runs a GET instead of re-submitting the POST
	 * (post/redirect/get). That matters most on activation, where a resubmit is a second
	 * binding attempt against a license that only has one.
	 *
	 * @param int $step A post-activation step to land on, or 0 for the page's own routing.
	 */
	private function redirect_to_wizard( int $step = 0 ): void {
		$url = admin_url( 'admin.php?page=' . self::PAGE_SLUG );

		if ( $step >= self::STEP_FIRST_GUIDED && $step <= self::STEP_LAST_GUIDED ) {
			$url = $this->step_url( $step );
		}

		wp_safe_redirect( $url );
		exit;
	}
}
