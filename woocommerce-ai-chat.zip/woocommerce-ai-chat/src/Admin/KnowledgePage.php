<?php
/**
 * The Knowledge Base page (`add-content-ingestion-kb §5.1–5.6`, FR-013/014/016/035/036).
 *
 * What the assistant knows, and the merchant's controls over it: the indexed-item inventory
 * with status and last-sync, the content-quality score with its factor breakdown and
 * improvement checklist, a per-item include/exclude switch, manual knowledge injection, and
 * the manual full re-sync.
 *
 * Built to the Merchant Admin Panel mockup (`ux-design/Merchant Admin Panel.dc.html`, the
 * `pgKbEmpty`/`pgKbMain` blocks) — score card with a breakdown toggle, the item table with a
 * per-row switch, the two action buttons, and the re-index confirmation. *(The §5 header note
 * in `tasks.md` points at `_bmad-output/planning-artifacts/ux/ux-spec-v1.md`, which does not
 * exist; the `.dc.html` mockup is the artifact that does, and is what this was built to.)*
 *
 * ## This page is the only one that writes
 *
 * Overview, Analytics, and Unanswered are reads — this one has three actions that change
 * what the assistant knows, which makes the guard rails matter more here than anywhere else
 * on the panel. All three go through `Panel::guard_ajax()` (capability *and* nonce, NFR-021),
 * and none of them performs the work inline: exclude, manual entry, and re-sync each enqueue
 * an Action Scheduler job and return. That is the same NFR-030 rule the WooCommerce save
 * hooks follow, applied to a merchant clicking a button — a backend that is down must make a
 * toggle fail visibly, not hang `/wp-admin` for thirty seconds.
 *
 * The one exception is the manual entry, which pushes synchronously. It is a single item the
 * merchant is watching, and the honest answer to "did my FAQ entry save?" needs the
 * backend's verdict; deferring it to a job would report success for a push that has not
 * happened yet. `ContentPusher`'s 30s timeout bounds it.
 *
 * ## Exclude is a delete, not a flag
 *
 * FR-036 is explicit: excluding an item removes its chunks. So the toggle enqueues a
 * tombstoned delete (`IngestionScheduler::enqueue_delete`) rather than writing a "hidden"
 * bit the backend would have to learn to filter on. The merchant's decision is *also*
 * recorded locally, in the same `PageSelector` override the D-6 key-page heuristic reads, so
 * that a later re-sync does not helpfully push back the page the merchant just removed.
 * Those two halves are the whole feature: without the delete the content stays answerable,
 * and without the override the next nightly walk undoes the merchant.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

use WooAIChat\Sync\ContentCollector;

/**
 * Renders the Knowledge Base shell and shapes the backend's inventory + quality score for it.
 */
final class KnowledgePage {

	/**
	 * How many items one page of the inventory shows.
	 *
	 * Well under the contract's 200 cap. The table is scanned by eye, and a merchant looking
	 * for one product does it with the browser's find rather than by paging through 200 rows.
	 */
	public const PAGE_SIZE = 50;

	/**
	 * The Knowledge Base body: the score card, the action buttons, the table, ES-003.
	 *
	 * Emits no outbound HTTP — see `Panel`'s header on why every panel page renders a shell
	 * and fills it over AJAX (NFR-005, the 2s budget in §5.6).
	 */
	public function render(): void {
		echo '<div class="wcai-knowledge" data-wcai-page="knowledge">';
		echo '<p class="wcai-loading" data-wcai-loading="1">' . esc_html__( 'Loading your knowledge base…', 'woocommerce-ai-chat' ) . '</p>';

		// Page-level, not inside `[data-wcai-knowledge-body]`, and that placement is the
		// whole point. This box used to live in `render_actions()`, which renders *inside*
		// the body div — and that div stays `hidden` for as long as the store has nothing
		// indexed. So `kbNotice()` cleared the box's own `hidden` flag onto an element whose
		// ancestor was still hidden, and every confirmation in the empty state was written
		// into a subtree the merchant could not see.
		//
		// The empty state is exactly when that matters most: a store with nothing indexed is
		// the one whose merchant clicks "Re-index my store", and the reward for clicking was
		// a panel that closed over silence. Anchored above the fold here for the same reason
		// WordPress puts its own admin notices there.
		echo '<div class="wcai-kb-notice" data-wcai-kb-notice hidden></div>';

		// Page-level for the same reason the notice above is, and then some: the walk
		// crosses the empty→populated boundary. Rendered inside the empty state it would be
		// torn out of the DOM at the exact moment the first items land — mid-walk, with the
		// bar at 20% and most of the catalogue still to send — and the merchant would watch
		// progress disappear precisely when it started working.
		$this->render_progress();

		$this->render_empty_state();
		// Rendered immediately after the empty state and before the manual-entry form —
		// not last on the page — because "Re-index my store" is the empty state's own
		// button, and a merchant on a fresh store (no indexed items yet) is exactly who
		// clicks it. Anywhere later on the page puts the panel below content that is
		// still hidden at that point, with no visual link back to the button that opened
		// it (`admin/panel.js`'s reveal is a plain `hidden` toggle with no scroll or
		// positioning of its own — see that file for the scrollIntoView it now does).
		$this->render_resync_confirm();

		echo '<div data-wcai-knowledge-body hidden>';
		$this->render_quality_card();
		$this->render_actions();
		$this->render_table();
		echo '</div>';

		$this->render_manual_form();

		echo '</div>';
	}

	/**
	 * ES-003 — nothing indexed yet.
	 *
	 * Phrased as a next step rather than as an absence: a store that has just finished
	 * onboarding and is still walking its first `push_batch` sees this, and "no items" would
	 * read as breakage rather than as "give it a minute, or add something yourself".
	 */
	private function render_empty_state(): void {
		echo '<div class="wcai-empty" data-wcai-empty="knowledge" hidden>';
		echo '<h2>' . esc_html__( 'No indexed items yet', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p>' . esc_html__( 'Add store content for the assistant to draw on, or run an index of your products and pages. A first sync usually finishes within a few minutes of setup.', 'woocommerce-ai-chat' ) . '</p>';
		echo '<p>';
		echo '<button type="button" class="button button-primary" data-wcai-action="manual-open">' . esc_html__( 'Add first entry', 'woocommerce-ai-chat' ) . '</button> ';
		echo '<button type="button" class="button" data-wcai-action="resync-open">' . esc_html__( 'Re-index my store', 'woocommerce-ai-chat' ) . '</button>';
		echo '</p>';
		echo '</div>';
	}

	/**
	 * The live re-index progress panel (§5.5, FR-016).
	 *
	 * Rendered hidden and revealed by the client once `wcai_kb_progress` reports a walk is
	 * running — including on a page load *during* a walk the merchant started elsewhere (the
	 * onboarding wizard, another tab), which is why it is not gated on having clicked the
	 * button in this page's session.
	 *
	 * `<progress>` rather than a styled div: it is the element that means this, it announces
	 * itself to assistive technology with its value and max, and it keeps working before the
	 * stylesheet loads. The text line above it carries the same numbers for the same reason
	 * the pill does not rely on colour alone — a bar with no words is not a status.
	 *
	 * `aria-live="polite"` on the text, not on the bar: the numbers changing every few
	 * seconds should reach a screen reader, but at a rate a person can follow, and announcing
	 * each of a hundred bar increments would be unusable.
	 */
	private function render_progress(): void {
		echo '<div class="wcai-kb-progress" data-wcai-kb-progress hidden>';
		echo '<p class="wcai-kb-progress-text" data-wcai-field="progressText" aria-live="polite"></p>';
		echo '<progress class="wcai-kb-progress-bar" data-wcai-field="progressBar" max="100" value="0"></progress>';
		echo '<p class="wcai-kb-progress-detail" data-wcai-field="progressDetail"></p>';
		echo '</div>';
	}

	/**
	 * The content-quality score, its factor breakdown, and the improvement checklist (§5.2).
	 *
	 * The breakdown is rendered inside a `<details>` rather than behind a scripted toggle:
	 * the mockup's "Show breakdown" control is exactly what `<details>` is, it is keyboard
	 * operable and screen-reader announced without any of it being written here (AX), and it
	 * keeps working on the pass where the AJAX fill fails.
	 *
	 * The threshold line is only meaningful once the score is known, so it is filled by the
	 * client along with everything else.
	 */
	private function render_quality_card(): void {
		echo '<div class="wcai-quality-card">';

		echo '<div class="wcai-quality-headline">';
		echo '<h2>' . esc_html__( 'Content quality score', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="wcai-quality-score"><span data-wcai-field="qualityScore">—</span><span class="wcai-quality-max">/100</span></p>';
		echo '<p class="wcai-quality-verdict" data-wcai-field="qualityVerdict"></p>';
		echo '</div>';

		echo '<details class="wcai-quality-breakdown">';
		echo '<summary>' . esc_html__( 'Show score breakdown', 'woocommerce-ai-chat' ) . '</summary>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Factor', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Score', 'woocommerce-ai-chat' ) . '</th>';
		echo '</tr></thead><tbody data-wcai-field="qualityFactors"></tbody></table>';
		echo '</details>';

		// The improvement checklist (FR-014). Hidden when the backend sends none — a store
		// that is already passing should not be shown an empty "how to improve" heading.
		echo '<div class="wcai-quality-improvements" data-wcai-improvements hidden>';
		echo '<h3>' . esc_html__( 'How to improve your score', 'woocommerce-ai-chat' ) . '</h3>';
		echo '<ul data-wcai-field="qualityImprovements"></ul>';
		echo '</div>';

		// The go-live override (D9, FR-014, contract `overrideQualityGate`).
		//
		// Below the threshold the widget does not go live on its own, and until now the
		// checklist above was the *only* thing on this card — the merchant could read what to
		// improve and had no way to say "I have read it and I want to go live anyway", even
		// though the contract has defined that decision and the backend has implemented it
		// throughout. A store whose catalogue is genuinely thin (a handful of
		// made-to-order products, say) could never reach a passing score and so could never
		// turn the assistant on at all.
		//
		// Rendered after the checklist deliberately: the improvements are the recommendation
		// and this is the override of it, so the merchant reads the advice before the button
		// that skips it. Hidden by default and revealed by the client only when the backend
		// says the gate is actually shut.
		echo '<div class="wcai-quality-override" data-wcai-override hidden>';
		echo '<p>' . esc_html__( 'You can publish the assistant now and keep improving your content afterwards. Answers may be less accurate until your score improves.', 'woocommerce-ai-chat' ) . '</p>';
		echo '<button type="button" class="button" data-wcai-action="override-gate">' . esc_html__( 'Publish anyway', 'woocommerce-ai-chat' ) . '</button>';
		echo '</div>';

		echo '</div>';
	}

	/** The two page-level actions: manual entry (§5.4) and full re-sync (§5.5). */
	private function render_actions(): void {
		echo '<p class="wcai-kb-actions">';
		echo '<button type="button" class="button button-primary" data-wcai-action="manual-open">' . esc_html__( 'Add manual entry', 'woocommerce-ai-chat' ) . '</button> ';
		echo '<button type="button" class="button" data-wcai-action="resync-open">' . esc_html__( 'Manual re-index', 'woocommerce-ai-chat' ) . '</button>';
		echo '</p>';
	}

	/**
	 * The indexed-item inventory (§5.1) with its per-item switch (§5.3).
	 *
	 * `<tbody>` is filled by the client from `payload()`. The count line above it reports the
	 * store total rather than the page length, so a merchant on page one of six sees how much
	 * there is.
	 */
	private function render_table(): void {
		echo '<p class="wcai-kb-count" data-wcai-field="knowledgeCount"></p>';

		echo '<table class="widefat striped wcai-kb-table"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Title', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Type', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Last synced', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Status', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Included', 'woocommerce-ai-chat' ) . '</th>';
		echo '</tr></thead><tbody data-wcai-field="knowledgeRows"></tbody></table>';

		echo '<p class="wcai-kb-pager" data-wcai-pager hidden>';
		echo '<button type="button" class="button" data-wcai-action="page-prev">' . esc_html__( 'Previous', 'woocommerce-ai-chat' ) . '</button> ';
		echo '<button type="button" class="button" data-wcai-action="page-next">' . esc_html__( 'Next', 'woocommerce-ai-chat' ) . '</button>';
		echo '</p>';
	}

	/**
	 * The manual knowledge-entry form (§5.4, FR-035).
	 *
	 * Pre-filled from `?wcai_seed=` when the merchant arrived from the Unanswered page's
	 * "Add Answer" action — that round trip is the improvement loop `UnansweredPage` exists
	 * to close, and it only works if the question survives the hop. The seed originated with
	 * a *shopper*, so it is escaped here as the untrusted value it is (NFR-021).
	 */
	private function render_manual_form(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a display-only seed; the form's own submission is nonce-guarded via `Panel::guard_ajax()`.
		$raw_seed = isset( $_GET['wcai_seed'] ) ? wp_unslash( $_GET['wcai_seed'] ) : '';
		$seed     = is_string( $raw_seed ) ? sanitize_text_field( $raw_seed ) : '';

		// The Unanswered deep link carries `wcai_add=manual`, which opens the form on load so
		// the merchant lands in the field rather than hunting for the button that opens it.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag.
		$open = isset( $_GET['wcai_add'] ) && 'manual' === $_GET['wcai_add'];

		printf(
			'<div class="wcai-kb-panel" data-wcai-panel="manual"%s>',
			$open ? '' : ' hidden'
		);
		echo '<h2>' . esc_html__( 'Add a manual entry', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'Answers you write here are indexed alongside your store content and are given priority when the assistant answers a matching question.', 'woocommerce-ai-chat' ) . '</p>';

		echo '<p><label for="wcai-manual-title">' . esc_html__( 'Title or question', 'woocommerce-ai-chat' ) . '</label><br />';
		printf(
			'<input type="text" id="wcai-manual-title" class="regular-text" data-wcai-input="manualTitle" value="%s" />',
			esc_attr( $seed )
		);
		echo '</p>';

		echo '<p><label for="wcai-manual-body">' . esc_html__( 'Answer', 'woocommerce-ai-chat' ) . '</label><br />';
		echo '<textarea id="wcai-manual-body" class="large-text" rows="6" data-wcai-input="manualBody"></textarea></p>';

		echo '<p>';
		echo '<button type="button" class="button button-primary" data-wcai-action="manual-save">' . esc_html__( 'Save entry', 'woocommerce-ai-chat' ) . '</button> ';
		echo '<button type="button" class="button" data-wcai-action="panel-close">' . esc_html__( 'Cancel', 'woocommerce-ai-chat' ) . '</button>';
		echo '</p>';
		echo '</div>';
	}

	/**
	 * The full re-sync confirmation (§5.5, FR-016).
	 *
	 * Confirmed in the page rather than through `window.confirm`, because the thing a
	 * merchant needs before agreeing is the sentence about what it does and how long it
	 * takes, and a browser dialog cannot show it. Progress is reported afterwards from the
	 * backend's own `indexing` block — see `progress()`.
	 */
	private function render_resync_confirm(): void {
		echo '<div class="wcai-kb-panel" data-wcai-panel="resync" hidden>';
		echo '<h2>' . esc_html__( 'Re-index your store?', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p>' . esc_html__( 'This rebuilds the knowledge base from your current store content. It runs in the background and may take a few minutes — your assistant keeps answering from the existing index while it works.', 'woocommerce-ai-chat' ) . '</p>';
		echo '<p>';
		echo '<button type="button" class="button button-primary" data-wcai-action="resync-confirm">' . esc_html__( 'Start re-index', 'woocommerce-ai-chat' ) . '</button> ';
		echo '<button type="button" class="button" data-wcai-action="panel-close">' . esc_html__( 'Cancel', 'woocommerce-ai-chat' ) . '</button>';
		echo '</p>';
		echo '</div>';
	}

	// -- payload ------------------------------------------------------------------

	/**
	 * Shape a `MerchantKnowledgeResponse` into what the page renders.
	 *
	 * @param array<string, mixed> $body   A `MerchantKnowledgeResponse`.
	 * @param int                  $offset The offset this page was read at, so the client
	 *                                     can page without re-deriving it.
	 * @return array<string, mixed>
	 */
	public function payload( array $body, int $offset = 0 ): array {
		$rows  = $this->rows( is_array( $body['items'] ?? null ) ? $body['items'] : array() );
		$total = isset( $body['total'] ) ? (int) $body['total'] : 0;

		return array(
			// Emptiness is the *store's*, not the page's: a merchant who pages past the end
			// has an inventory, and showing them ES-003's "nothing indexed yet" would be a
			// lie about their store rather than a report about their offset.
			'isEmpty' => 0 === $total,
			'rows'    => $rows,
			'total'   => $total,
			'offset'  => $offset,
			'hasPrev' => $offset > 0,
			'hasNext' => ( $offset + self::PAGE_SIZE ) < $total,
			'count'   => $this->count_text( $total, $offset, count( $rows ) ),
			'quality' => $this->quality( is_array( $body['quality'] ?? null ) ? $body['quality'] : array() ),
		);
	}

	/**
	 * @param array<int, mixed> $items The response's `items` list.
	 * @return array<int, array<string, mixed>>
	 */
	private function rows( array $items ): array {
		$rows = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$object_type = is_string( $item['object_type'] ?? null ) ? (string) $item['object_type'] : '';
			$object_id   = isset( $item['object_id'] ) ? (int) $item['object_id'] : 0;
			if ( '' === $object_type || $object_id <= 0 ) {
				// Without both halves the row has no identity, so its switch would have
				// nothing to act on. Dropping it beats rendering a control that cannot work.
				continue;
			}

			$status = is_string( $item['status'] ?? null ) ? (string) $item['status'] : 'indexed';

			$rows[] = array(
				// Decoded because rows indexed before `ContentCollector::plain_name()`
				// existed carry stored entities ("Vases &amp; Candles"), and the client
				// renders titles as text nodes — correctly — so an encoded payload shows
				// the literal "&amp;". Decoding twice is safe: a decoded title has no
				// entities left for a second pass to change.
				'title'      => is_string( $item['title'] ?? null )
					? html_entity_decode( (string) $item['title'], ENT_QUOTES | ENT_HTML5, 'UTF-8' )
					: '',
				'objectType' => $object_type,
				'typeLabel'  => self::type_label( $object_type ),
				'objectId'   => $object_id,
				'lastSynced' => $this->format_date( $item['last_synced'] ?? null ),
				'status'     => $status,
				'statusText' => self::status_label( $status ),
				'included'   => ! empty( $item['included'] ),
				// The toggle acts on the *source* id — the WordPress post/term id the plugin
				// collects by — while the backend indexes under the namespaced id (see the §1
				// addendum in `design.md` on why non-product ids are offset). Both travel, so
				// the delete can name what the backend holds and the override can name what
				// WordPress knows, without either side re-deriving the other's id.
				'sourceId'   => ContentCollector::decode_object_id( $object_type, $object_id ),
			);
		}
		return $rows;
	}

	/**
	 * Shape the quality block: score, verdict, factor breakdown, checklist (§5.2).
	 *
	 * The verdict sentence is built from the backend's `passed` and `threshold` rather than
	 * from comparing the score here. §4's go-live gate reads the same `passed` field, and a
	 * page that re-derived the comparison could tell a merchant they are above the bar while
	 * the gate that actually withholds their widget disagrees.
	 *
	 * @param array<string, mixed> $quality The response's `quality` block.
	 * @return array<string, mixed>
	 */
	/**
	 * `quality()` for a caller outside this class.
	 *
	 * Public for the same reason `progress()` below is: `Panel::ajax_override_gate()` gets a
	 * fresh `QualityScore` back from the override write and has to render it through exactly
	 * the shaping the page's own read uses. A second shaper there would be a second place
	 * that decides how `passed` becomes a sentence, and the two would disagree the first
	 * time either changed.
	 *
	 * Note the argument is the `QualityScore` itself. The knowledge *read* nests it under a
	 * `quality` key; the override endpoint returns it bare, because the merchant asked one
	 * question and gets one answer.
	 *
	 * @param array<string, mixed> $quality A `QualityScore`.
	 * @return array<string, mixed>
	 */
	public function quality_block( array $quality ): array {
		return $this->quality( $quality );
	}

	private function quality( array $quality ): array {
		$score     = isset( $quality['score'] ) ? (int) $quality['score'] : 0;
		$threshold = isset( $quality['threshold'] ) ? (int) $quality['threshold'] : 0;
		$passed    = ! empty( $quality['passed'] );

		$factors = array();
		$rows    = is_array( $quality['categories'] ?? null ) ? $quality['categories'] : array();
		foreach ( $rows as $factor ) {
			if ( ! is_array( $factor ) ) {
				continue;
			}
			$name = is_string( $factor['category'] ?? null ) ? (string) $factor['category'] : '';
			if ( '' === $name ) {
				continue;
			}
			$factors[] = array(
				'label' => self::factor_label( $name ),
				'score' => isset( $factor['score'] ) ? (int) $factor['score'] : 0,
			);
		}

		$improvements = array();
		$listed       = is_array( $quality['improvements'] ?? null ) ? $quality['improvements'] : array();
		foreach ( $listed as $line ) {
			if ( is_string( $line ) && '' !== $line ) {
				$improvements[] = $line;
			}
		}
		// The backend's scoring categories each contribute tips independently, and on an
		// empty index several of them reach the same conclusion in the same words — the
		// checklist rendered "No products indexed." twice, which reads as a glitch rather
		// than as two scorers agreeing. Dedup by exact text, order preserved.
		$improvements = array_values( array_unique( $improvements ) );

		return array(
			'score'        => $score,
			'threshold'    => $threshold,
			'passed'       => $passed,
			// Relayed so the page can decide whether to offer the go-live override. Both
			// come from the backend and neither is re-derived: `canOverride` is the one
			// state where the button means anything — below the bar, and the merchant has
			// not already made this decision. `overridden` stays true after content later
			// climbs past the threshold on its own (it is a standing decision, not a patch
			// for one moment), which is exactly why "not passed" alone is not the condition.
			'overridden'   => ! empty( $quality['overridden'] ),
			'canOverride'  => ! $passed,
			'verdict'      => $this->verdict_text( $passed, $threshold ),
			'factors'      => $factors,
			'improvements' => $improvements,
		);
	}

	/** The sentence under the score, phrased by whether the store clears the gate. */
	private function verdict_text( bool $passed, int $threshold ): string {
		if ( $passed ) {
			return sprintf(
				/* translators: %s: the quality threshold the store must clear, e.g. "40". */
				__( 'Your content clears the %s/100 bar needed for the assistant to go live.', 'woocommerce-ai-chat' ),
				number_format_i18n( $threshold )
			);
		}

		return sprintf(
			/* translators: %s: the quality threshold the store must clear, e.g. "40". */
			__( 'Your assistant stays off until this reaches %s/100. The checklist below is the fastest way there.', 'woocommerce-ai-chat' ),
			number_format_i18n( $threshold )
		);
	}

	/** "Showing 1–50 of 340 items", or the whole-store count when it all fits on one page. */
	private function count_text( int $total, int $offset, int $shown ): string {
		if ( 0 === $total ) {
			return '';
		}

		if ( $shown >= $total ) {
			return sprintf(
				/* translators: %s: the number of indexed items. */
				_n( '%s indexed item', '%s indexed items', $total, 'woocommerce-ai-chat' ),
				number_format_i18n( $total )
			);
		}

		return sprintf(
			/* translators: 1: first row shown, 2: last row shown, 3: total indexed items. */
			__( 'Showing %1$s–%2$s of %3$s indexed items', 'woocommerce-ai-chat' ),
			number_format_i18n( $offset + 1 ),
			number_format_i18n( $offset + $shown ),
			number_format_i18n( $total )
		);
	}

	/**
	 * The backend's re-sync progress, relayed for the §5.5 progress line (FR-016).
	 *
	 * Read from `MerchantHealthResponse.indexing`, which is where the contract puts it. The
	 * backend currently reports `idle/0/0` honestly (it has no queue to relay yet — see that
	 * handler's docstring), so this renders "queued" from the *plugin's* own scheduling
	 * confirmation and defers to the backend the moment it reports anything else. Showing a
	 * merchant "nothing is happening" right after they pressed the button would read as the
	 * click having failed.
	 *
	 * @param array<string, mixed> $indexing An `IndexingProgress` block.
	 * @return array{state: string, text: string}
	 */
	public function progress( array $indexing ): array {
		// An empty block means the health read itself failed — there is no `IndexingProgress`
		// to relay, which is a different fact from the backend reporting `idle`. The default
		// branch's "Re-index scheduled…" is written for the post-click confirmation flow;
		// shown here it would claim work is queued on the strength of a request that failed.
		if ( array() === $indexing ) {
			return array(
				'state' => 'idle',
				'text'  => __( 'Indexing status is unavailable right now.', 'woocommerce-ai-chat' ),
			);
		}

		$state     = is_string( $indexing['state'] ?? null ) ? (string) $indexing['state'] : 'idle';
		$processed = isset( $indexing['processed'] ) ? (int) $indexing['processed'] : 0;
		$total     = isset( $indexing['total'] ) ? (int) $indexing['total'] : 0;

		// The plugin's own post-click confirmation, distinct from the backend's `idle`
		// report. `Panel::ajax_resync()` has *just* queued the job, so it states the one
		// fact the plugin knows without asking the backend — the empty-array branch above
		// is for a health read that failed, and relaying that here would tell a merchant
		// who pressed "Start re-index" that their click may not have worked.
		if ( 'queued' === $state ) {
			return array(
				'state' => $state,
				'text'  => __( 'Re-index scheduled. It runs in the background; this page will show progress as it goes.', 'woocommerce-ai-chat' ),
			);
		}

		if ( 'running' === $state && $total > 0 ) {
			return array(
				'state' => $state,
				'text'  => sprintf(
					/* translators: 1: items indexed so far, 2: total items to index. */
					__( 'Re-indexing: %1$s of %2$s items done.', 'woocommerce-ai-chat' ),
					number_format_i18n( $processed ),
					number_format_i18n( $total )
				),
			);
		}

		if ( 'failed' === $state ) {
			return array(
				'state' => $state,
				'text'  => __( 'The last re-index did not finish. Open Health Check to see why.', 'woocommerce-ai-chat' ),
			);
		}

		return array(
			'state' => $state,
			'text'  => __( 'Re-index scheduled. It runs in the background; this page will show progress as it goes.', 'woocommerce-ai-chat' ),
		);
	}

	/**
	 * Shape the plugin's own re-index record into the page's progress block (§5.5, FR-016).
	 *
	 * Distinct from `progress()` above, which relays the *backend's* `IndexingProgress` and
	 * has no real numbers behind it yet. This one reads `IndexingProgress` — the record the
	 * walk itself writes — so it can report counts, the phase, a percentage and an estimate.
	 *
	 * ## What the numbers mean, and the copy that keeps that honest
	 *
	 * `processed` counts rows this site has *sent*, not rows the backend has finished making
	 * searchable. Those differ, and the difference is not this page's to hide: the label says
	 * "sent" rather than "indexed" so a merchant whose bar reads full but whose table is
	 * still filling in is reading an accurate account of both. The table remains the record
	 * of what landed.
	 *
	 * The estimate is deliberately coarse — "about a minute", "a few minutes" — rather than a
	 * countdown. Rate is measured from elapsed time over processed rows, and it varies with
	 * batch jitter, retry backoff and backend latency; a per-second countdown computed from
	 * that would visibly jump around and read as broken. Rounded language degrades honestly.
	 *
	 * @param array<string, mixed> $record An `IndexingProgress::read()` record.
	 * @return array{state: string, text: string, detail: string, percent: int, processed: int, total: int, isActive: bool}
	 */
	public function resync_progress( array $record ): array {
		$idle = array(
			'state'     => 'idle',
			'text'      => '',
			'detail'    => '',
			'percent'   => 0,
			'processed' => 0,
			'total'     => 0,
			'isActive'  => false,
		);

		if ( array() === $record ) {
			return $idle;
		}

		$state     = is_string( $record['state'] ?? null ) ? (string) $record['state'] : 'idle';
		$processed = max( 0, (int) ( $record['processed'] ?? 0 ) );
		$total     = max( 0, (int) ( $record['total'] ?? 0 ) );

		if ( 'idle' === $state ) {
			return $idle;
		}

		if ( 'done' === $state ) {
			$accepted = max( 0, (int) ( $record['accepted'] ?? 0 ) );
			$rejected = max( 0, (int) ( $record['rejected'] ?? 0 ) );

			// The walk finished but the backend refused everything it was sent — a plan
			// whose memory quota is exhausted or zero answers each push with HTTP 200 and
			// `rejected: N`, so from the cursor's point of view nothing went wrong. Reported
			// as `failed` rather than `done` because to the merchant it is the same outcome
			// as a walk that never ran: the assistant has nothing to answer from. Saying
			// "Re-index complete" here is how a zero-quota store came to show a triumphant
			// full bar directly above an empty inventory.
			if ( $rejected > 0 && 0 === $accepted ) {
				return array(
					'state'     => 'failed',
					'text'      => __( 'Re-index finished, but your plan could not store any of your content.', 'woocommerce-ai-chat' ),
					'detail'    => sprintf(
						/* translators: %s: number of items the plan rejected. */
						_n(
							'%s item was rejected by your subscription’s content limit. Check the Health Check page, then re-index once your plan has capacity.',
							'%s items were rejected by your subscription’s content limit. Check the Health Check page, then re-index once your plan has capacity.',
							$rejected,
							'woocommerce-ai-chat'
						),
						number_format_i18n( $rejected )
					),
					'percent'   => 100,
					'processed' => $total,
					'total'     => $total,
					'isActive'  => false,
				);
			}

			// Some rows landing and some refused is the partial-quota case — the bar is
			// honest at full (the walk did finish) but the detail carries both numbers.
			if ( $rejected > 0 ) {
				return array(
					'state'     => 'done',
					'text'      => __( 'Re-index complete — with some items left out.', 'woocommerce-ai-chat' ),
					'detail'    => sprintf(
						/* translators: 1: items the backend stored, 2: items the plan rejected. */
						__( '%1$s items stored; %2$s rejected by your subscription’s content limit.', 'woocommerce-ai-chat' ),
						number_format_i18n( $accepted ),
						number_format_i18n( $rejected )
					),
					'percent'   => 100,
					'processed' => $total,
					'total'     => $total,
					'isActive'  => false,
				);
			}

			return array(
				'state'     => 'done',
				'text'      => __( 'Re-index complete.', 'woocommerce-ai-chat' ),
				'detail'    => sprintf(
					/* translators: %s: number of items sent. */
					_n( '%s item sent to the assistant.', '%s items sent to the assistant.', $total, 'woocommerce-ai-chat' ),
					number_format_i18n( $total )
				),
				'percent'   => 100,
				'processed' => $total,
				'total'     => $total,
				'isActive'  => false,
			);
		}

		// A store with nothing to walk still gets a truthful answer rather than a division by
		// zero: the walk was queued, there is simply nothing in it.
		if ( 0 === $total ) {
			return array(
				'state'     => $state,
				'text'      => __( 'Preparing your store content…', 'woocommerce-ai-chat' ),
				'detail'    => '',
				'percent'   => 0,
				'processed' => 0,
				'total'     => 0,
				'isActive'  => true,
			);
		}

		$percent = (int) floor( ( $processed / $total ) * 100 );
		$percent = max( 0, min( 100, $percent ) );

		return array(
			'state'     => $state,
			'text'      => sprintf(
				/* translators: 1: items sent so far, 2: total items to send. */
				__( 'Indexing your store — %1$s of %2$s items sent', 'woocommerce-ai-chat' ),
				number_format_i18n( $processed ),
				number_format_i18n( $total )
			),
			'detail'    => $this->progress_detail( $record, $processed, $total ),
			'percent'   => $percent,
			'processed' => $processed,
			'total'     => $total,
			'isActive'  => true,
		);
	}

	/**
	 * The second line under the bar: which phase is running, and roughly how much longer.
	 *
	 * Returns the phase alone until enough of the walk has completed to estimate from. A
	 * remaining-time figure derived from one batch would be wrong by a wide margin on the
	 * exact screen where the merchant is deciding whether to wait or leave.
	 *
	 * @param array<string, mixed> $record    The progress record.
	 * @param int                  $processed Rows sent so far.
	 * @param int                  $total     Rows in the walk.
	 */
	private function progress_detail( array $record, int $processed, int $total ): string {
		$phase = is_string( $record['phase'] ?? null ) ? (string) $record['phase'] : '';
		$label = '' !== $phase ? self::phase_label( $phase ) : '';

		$started = (int) ( $record['started_at'] ?? 0 );
		$elapsed = $started > 0 ? max( 0, time() - $started ) : 0;

		// Below this the sample is too short to extrapolate from — see the docblock.
		if ( $processed < 10 || $elapsed < 5 ) {
			return $label;
		}

		$per_item  = $elapsed / $processed;
		$remaining = (int) ceil( ( $total - $processed ) * $per_item );
		if ( $remaining <= 0 ) {
			return $label;
		}

		if ( $remaining < 90 ) {
			$estimate = __( 'about a minute left', 'woocommerce-ai-chat' );
		} elseif ( $remaining < 600 ) {
			$estimate = sprintf(
				/* translators: %s: whole minutes remaining. */
				__( 'about %s minutes left', 'woocommerce-ai-chat' ),
				number_format_i18n( (int) round( $remaining / 60 ) )
			);
		} else {
			$estimate = __( 'this may take a while', 'woocommerce-ai-chat' );
		}

		if ( '' === $label ) {
			return $estimate;
		}

		return sprintf(
			/* translators: 1: what is being indexed now, 2: rough time remaining. */
			_x( '%1$s · %2$s', 'indexing phase and time estimate', 'woocommerce-ai-chat' ),
			$label,
			$estimate
		);
	}

	/**
	 * The merchant-facing name for a walk phase.
	 *
	 * Phrased as what is happening ("Indexing products") rather than as the phase's internal
	 * name, and kept separate from `type_label()` — that one names a *row's* type in the
	 * inventory table, which is a different sentence in several languages even where it is
	 * the same word in English.
	 */
	private static function phase_label( string $phase ): string {
		if ( ContentCollector::TYPE_PRODUCT === $phase ) {
			return __( 'Indexing products', 'woocommerce-ai-chat' );
		}
		if ( ContentCollector::TYPE_CATEGORY === $phase ) {
			return __( 'Indexing categories', 'woocommerce-ai-chat' );
		}
		if ( ContentCollector::TYPE_PAGE === $phase ) {
			return __( 'Indexing pages', 'woocommerce-ai-chat' );
		}
		return '';
	}

	// -- labels -------------------------------------------------------------------

	/**
	 * The merchant-facing name for a contract `ObjectType`.
	 *
	 * Unknown types fall through to the raw value for the same reason `Panel::state_label()`
	 * does: a backend that indexes a type this plugin predates should name it, not erase it.
	 */
	public static function type_label( string $object_type ): string {
		$labels = array(
			'product'  => __( 'Product', 'woocommerce-ai-chat' ),
			'category' => __( 'Category', 'woocommerce-ai-chat' ),
			'page'     => __( 'Page', 'woocommerce-ai-chat' ),
			'post'     => __( 'Post', 'woocommerce-ai-chat' ),
			'manual'   => __( 'Manual entry', 'woocommerce-ai-chat' ),
		);

		return $labels[ $object_type ] ?? $object_type;
	}

	/** The merchant-facing label for a `KnowledgeItem.status`. */
	public static function status_label( string $status ): string {
		$labels = array(
			'indexed'  => __( 'Indexed', 'woocommerce-ai-chat' ),
			'pending'  => __( 'Pending', 'woocommerce-ai-chat' ),
			'failed'   => __( 'Failed', 'woocommerce-ai-chat' ),
			'excluded' => __( 'Excluded', 'woocommerce-ai-chat' ),
		);

		return $labels[ $status ] ?? $status;
	}

	/**
	 * The merchant-facing name for a quality factor.
	 *
	 * The backend's factor keys (`description_completeness`, `inventory_signal`) are rubric
	 * names, not merchant language. A checklist that says "inventory_signal: 40" tells a
	 * merchant nothing about what to go and fix.
	 */
	public static function factor_label( string $factor ): string {
		$labels = array(
			'coverage'                 => __( 'Catalogue coverage', 'woocommerce-ai-chat' ),
			'description_completeness' => __( 'Product descriptions', 'woocommerce-ai-chat' ),
			'policy_coverage'          => __( 'Shipping, returns & policy pages', 'woocommerce-ai-chat' ),
			'freshness'                => __( 'Content freshness', 'woocommerce-ai-chat' ),
			'inventory_signal'         => __( 'Price & stock information', 'woocommerce-ai-chat' ),
		);

		return $labels[ $factor ] ?? $factor;
	}

	/**
	 * A contract timestamp in the site's own date format.
	 *
	 * @param mixed $value An ISO-8601 string from the contract, or anything else.
	 */
	private function format_date( $value ): string {
		if ( ! is_string( $value ) || '' === $value ) {
			return __( 'Never', 'woocommerce-ai-chat' );
		}
		$timestamp = strtotime( $value );
		if ( false === $timestamp ) {
			return __( 'Never', 'woocommerce-ai-chat' );
		}
		return date_i18n( (string) get_option( 'date_format' ), $timestamp );
	}
}
