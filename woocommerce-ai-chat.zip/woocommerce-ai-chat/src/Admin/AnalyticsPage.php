<?php
/**
 * The Analytics page (`add-merchant-insight-ops §2.2–§2.3`, FR-015, FR-091).
 *
 * Total conversations (all-time and windowed), answer versus deflection rate, the top-N
 * questions, a deflection-rate-over-time series, and the per-language breakdown whose
 * > 30% rows carry an alert.
 *
 * ## Why the per-language alert is the point of this page
 *
 * A store's blended deflection rate can sit at a healthy 8% while its German shoppers are
 * being failed 45% of the time, because the blend is dominated by whichever language has
 * the most traffic. FR-091 exists for that: the alert is raised **per detected language**,
 * on `detected_locale` — what the shopper actually spoke — not on the store's configured
 * language, which would report every store as monolingual. The backend decides the alert
 * (`LocaleDeflection.alert`) and this page renders it; re-testing `rate > 0.30` here would
 * put the threshold in two places.
 *
 * ## The chart is rendered as an inline SVG, not by a charting library
 *
 * A sparkline of one series over ≤ 90 points does not justify shipping a charting bundle
 * into `/wp-admin`, and the NFR-005 budget is the page's, not just the backend's. The
 * series is drawn in PHP as a polyline and shipped inside the payload, so the page has one
 * script and no third-party JS. The same data is emitted as a table underneath — that is
 * the accessible reading of a chart, and here it is also the one a merchant can copy.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

/**
 * Renders the Analytics shell and shapes `/v1/merchant/analytics` for it.
 */
final class AnalyticsPage {

	/** Top-N questions shown. The backend already ranks and truncates; this is a guard. */
	private const TOP_N = 10;

	/** The chart's viewBox, in user units. Kept small — CSS scales it to the container. */
	private const CHART_W = 600;
	private const CHART_H = 160;

	/** The Analytics body: headline stats, the chart, top questions, per-language table. */
	public function render(): void {
		echo '<div class="wcai-analytics" data-wcai-page="analytics">';
		echo '<p class="wcai-loading" data-wcai-loading="1">' . esc_html__( 'Loading your analytics…', 'woocommerce-ai-chat' ) . '</p>';

		// ES-002 — live, but no conversations to analyse yet.
		echo '<div class="wcai-empty" data-wcai-empty="conversations" hidden>';
		echo '<h2>' . esc_html__( 'No conversations yet', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p>' . esc_html__( 'Once shoppers start asking questions, this page shows how many the assistant answered, which questions come up most, and where it is falling short.', 'woocommerce-ai-chat' ) . '</p>';
		echo '</div>';

		echo '<div data-wcai-analytics-body hidden>';

		echo '<div class="wcai-cards">';
		$this->render_stat( 'conversationsTotal', __( 'Conversations (all time)', 'woocommerce-ai-chat' ) );
		$this->render_stat( 'conversationsWindow', __( 'Conversations (30 days)', 'woocommerce-ai-chat' ) );
		$this->render_stat( 'answerRate', __( 'Answered', 'woocommerce-ai-chat' ) );
		$this->render_stat( 'deflectionRate', __( 'Could not answer', 'woocommerce-ai-chat' ) );
		echo '</div>';

		echo '<h2>' . esc_html__( 'Deflection rate over time', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<div class="wcai-chart" data-wcai-field="deflectionChart"></div>';
		echo '<table class="widefat striped wcai-chart-data"><caption class="screen-reader-text">';
		echo esc_html__( 'Deflection rate by day', 'woocommerce-ai-chat' );
		echo '</caption><thead><tr><th scope="col">' . esc_html__( 'Date', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Could not answer', 'woocommerce-ai-chat' ) . '</th></tr></thead>';
		echo '<tbody data-wcai-field="deflectionRows"></tbody></table>';

		echo '<h2>' . esc_html__( 'By shopper language', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'A healthy overall rate can hide one language failing badly, so each is measured on its own.', 'woocommerce-ai-chat' ) . '</p>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Language', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Conversations', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Could not answer', 'woocommerce-ai-chat' ) . '</th>';
		echo '</tr></thead><tbody data-wcai-field="localeRows"></tbody></table>';

		echo '<h2>' . esc_html__( 'Most-asked questions (30 days)', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Question', 'woocommerce-ai-chat' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Times asked', 'woocommerce-ai-chat' ) . '</th>';
		echo '</tr></thead><tbody data-wcai-field="topQuestionRows"></tbody></table>';

		echo '</div></div>';
	}

	/**
	 * One headline stat.
	 *
	 * @param string $field The `payload()` key that fills it.
	 * @param string $label The translated heading.
	 */
	private function render_stat( string $field, string $label ): void {
		printf(
			'<div class="wcai-card"><h3>%1$s</h3><p class="wcai-card-value" data-wcai-field="%2$s">%3$s</p></div>',
			esc_html( $label ),
			esc_attr( $field ),
			esc_html( '—' )
		);
	}

	/**
	 * Shape `/v1/merchant/analytics` into the fields `render()`'s markup names.
	 *
	 * Pure apart from the locale-aware formatters, so §6.1 can assert the alert and the
	 * chart geometry against a contract-shaped array without WordPress running.
	 *
	 * @param array<string, mixed> $body A `MerchantAnalyticsResponse`.
	 * @return array<string, mixed>
	 */
	public function payload( array $body ): array {
		$total  = isset( $body['conversations_total'] ) ? (int) $body['conversations_total'] : 0;
		$window = isset( $body['conversations_window'] ) ? (int) $body['conversations_window'] : 0;
		$series = $this->series( is_array( $body['deflection_over_time'] ?? null ) ? $body['deflection_over_time'] : array() );

		return array(
			// Drives ES-002 on this page. Keyed on the all-time count: a store with a quiet
			// month but a year of history should see its (empty) window, not the "nothing
			// has happened yet" state, which would be wrong and would hide the drop.
			'isEmpty'             => 0 === $total,
			'conversationsTotal'  => number_format_i18n( $total ),
			'conversationsWindow' => number_format_i18n( $window ),
			'answerRate'          => $this->percent( $body['answer_rate'] ?? 0 ),
			'deflectionRate'      => $this->percent( $body['deflection_rate'] ?? 0 ),
			'deflectionChart'     => $this->chart_svg( $series ),
			'deflectionRows'      => $series,
			'localeRows'          => $this->locale_rows( is_array( $body['deflection_by_locale'] ?? null ) ? $body['deflection_by_locale'] : array() ),
			'topQuestionRows'     => $this->top_questions( is_array( $body['top_questions'] ?? null ) ? $body['top_questions'] : array() ),
			// Consumed by the *Overview*, not by this page: its "Top unanswered" card is
			// filled from this same response rather than a third request. The response
			// already carried `unanswered` for the Unanswered screen; this payload simply
			// never passed any of it on, so the card had nothing to render and sat at its
			// em-dash placeholder permanently.
			'topUnanswered'       => $this->top_unanswered( is_array( $body['unanswered'] ?? null ) ? $body['unanswered'] : array() ),
		);
	}

	/**
	 * The most-asked unanswered question, quoted, for the Overview's card.
	 *
	 * The backend returns the list most-asked first, so the first entry carrying a question
	 * is the top one. Returns `''` when there is nothing to show — the card's em-dash is
	 * the right display for a store with full coverage, and the script leaves it in place.
	 *
	 * @param array<int, mixed> $unanswered The response's `unanswered` list.
	 */
	private function top_unanswered( array $unanswered ): string {
		foreach ( $unanswered as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$question = is_string( $item['question'] ?? null ) ? trim( (string) $item['question'] ) : '';
			if ( '' !== $question ) {
				/* translators: %s: a shopper's question, shown quoted on the Overview card. */
				return sprintf( __( '“%s”', 'woocommerce-ai-chat' ), $question );
			}
		}

		return '';
	}

	/**
	 * The daily series as `[{date, rate, label, percent}]`, oldest first.
	 *
	 * @param array<int, mixed> $points The response's `deflection_over_time`.
	 * @return array<int, array{date: string, rate: float, label: string, percent: string}>
	 */
	private function series( array $points ): array {
		$rows = array();
		foreach ( $points as $point ) {
			if ( ! is_array( $point ) ) {
				continue;
			}
			$date      = is_string( $point['date'] ?? null ) ? (string) $point['date'] : '';
			$rate      = is_numeric( $point['rate'] ?? null ) ? (float) $point['rate'] : 0.0;
			$timestamp = '' === $date ? false : strtotime( $date );
			$rows[]    = array(
				'date'    => $date,
				'rate'    => $rate,
				'label'   => false === $timestamp ? $date : date_i18n( (string) get_option( 'date_format' ), $timestamp ),
				'percent' => $this->percent( $rate ),
			);
		}
		return $rows;
	}

	/**
	 * The per-language rows, carrying the backend's alert verdict (FR-091).
	 *
	 * @param array<int, mixed> $locales The response's `deflection_by_locale`.
	 * @return array<int, array{locale: string, language: string, conversations: string, percent: string, alert: bool, alertText: string}>
	 */
	private function locale_rows( array $locales ): array {
		$rows = array();
		foreach ( $locales as $locale ) {
			if ( ! is_array( $locale ) ) {
				continue;
			}
			$code  = is_string( $locale['detected_locale'] ?? null ) ? (string) $locale['detected_locale'] : '';
			$alert = ! empty( $locale['alert'] );

			$rows[] = array(
				'locale'        => $code,
				'language'      => $this->language_name( $code ),
				'conversations' => number_format_i18n( isset( $locale['conversations'] ) ? (int) $locale['conversations'] : 0 ),
				'percent'       => $this->percent( $locale['rate'] ?? 0 ),
				'alert'         => $alert,
				// The alert has to be actionable, not just red (SR-005). What fixes a
				// language-specific deflection spike is content in that language, and the
				// unanswered log filtered to it is where the merchant sees which.
				'alertText'     => $alert
					? __( 'Shoppers in this language are frequently not getting an answer. Check the unanswered log for what they are asking.', 'woocommerce-ai-chat' )
					: '',
			);
		}
		return $rows;
	}

	/**
	 * The top-N questions, truncated defensively.
	 *
	 * @param array<int, mixed> $questions The response's `top_questions`.
	 * @return array<int, array{question: string, count: string}>
	 */
	private function top_questions( array $questions ): array {
		$rows = array();
		foreach ( array_slice( $questions, 0, self::TOP_N ) as $question ) {
			if ( ! is_array( $question ) ) {
				continue;
			}
			$rows[] = array(
				'question' => is_string( $question['question'] ?? null ) ? (string) $question['question'] : '',
				'count'    => number_format_i18n( isset( $question['count'] ) ? (int) $question['count'] : 0 ),
			);
		}
		return $rows;
	}

	/**
	 * The deflection series as an inline SVG polyline.
	 *
	 * Returns '' for fewer than two points: a one-point "trend" is a dot, and drawing it
	 * would suggest a line that is not there. The page's table still shows the value.
	 *
	 * The y-axis is fixed to 0–100%, not scaled to the data. An auto-scaled axis makes a
	 * store that improved from 4% to 5% look like a catastrophe, which is precisely the
	 * misreading a dashboard must not manufacture.
	 *
	 * @param array<int, array{date: string, rate: float, label: string, percent: string}> $series
	 */
	private function chart_svg( array $series ): string {
		$count = count( $series );
		if ( $count < 2 ) {
			return '';
		}

		$step   = self::CHART_W / ( $count - 1 );
		$points = array();
		foreach ( array_values( $series ) as $i => $row ) {
			$x = $i * $step;
			// Rates arrive as 0..1; clamp before projecting so a malformed value cannot
			// draw outside the viewBox.
			$rate     = max( 0.0, min( 1.0, (float) $row['rate'] ) );
			$y        = self::CHART_H - ( $rate * self::CHART_H );
			$points[] = round( $x, 2 ) . ',' . round( $y, 2 );
		}

		// The 30% alert line, so a merchant reads the chart against the same threshold
		// FR-091 raises the per-language alert on.
		$threshold_y = self::CHART_H - ( 0.30 * self::CHART_H );

		return sprintf(
			'<svg class="wcai-sparkline" viewBox="0 0 %1$d %2$d" preserveAspectRatio="none" role="img" aria-label="%3$s">' .
				'<line class="wcai-threshold" x1="0" y1="%4$s" x2="%1$d" y2="%4$s" />' .
				'<polyline class="wcai-series" fill="none" points="%5$s" />' .
			'</svg>',
			self::CHART_W,
			self::CHART_H,
			esc_attr__( 'Deflection rate over time. The table below lists the same figures.', 'woocommerce-ai-chat' ),
			round( $threshold_y, 2 ),
			esc_attr( implode( ' ', $points ) )
		);
	}

	/**
	 * A rate in 0..1 as a locale-formatted percentage.
	 *
	 * One decimal place: the difference between 8% and 8.4% is noise to a merchant, but
	 * the difference between 0% and 0.4% is "it never fails" versus "it sometimes does",
	 * and rounding to whole numbers erases that.
	 *
	 * @param mixed $rate
	 */
	private function percent( $rate ): string {
		$value = is_numeric( $rate ) ? (float) $rate * 100 : 0.0;
		return sprintf(
			/* translators: %s: a percentage value, already locale-formatted. */
			__( '%s%%', 'woocommerce-ai-chat' ),
			number_format_i18n( $value, 1 )
		);
	}

	/**
	 * A human-readable language name for a detected locale code.
	 *
	 * WordPress has no locale-name table available without the translation install, so the
	 * code is shown as-is when unmapped — `de` is more useful to a merchant than a blank
	 * cell, and this list covers the launch locales. Unmapped codes are not an error state.
	 */
	private function language_name( string $code ): string {
		$base = strtolower( substr( $code, 0, 2 ) );

		$names = array(
			'en' => __( 'English', 'woocommerce-ai-chat' ),
			'fr' => __( 'French', 'woocommerce-ai-chat' ),
			'de' => __( 'German', 'woocommerce-ai-chat' ),
			'es' => __( 'Spanish', 'woocommerce-ai-chat' ),
			'it' => __( 'Italian', 'woocommerce-ai-chat' ),
			'nl' => __( 'Dutch', 'woocommerce-ai-chat' ),
			'pt' => __( 'Portuguese', 'woocommerce-ai-chat' ),
			'ar' => __( 'Arabic', 'woocommerce-ai-chat' ),
		);

		if ( ! isset( $names[ $base ] ) ) {
			return '' === $code ? __( 'Unknown', 'woocommerce-ai-chat' ) : $code;
		}

		return $names[ $base ];
	}
}
