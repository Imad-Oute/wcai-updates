<?php
/**
 * The Settings page (`add-merchant-insight-ops §3.2–3.4`, FR-012).
 *
 * Widget appearance, widget behaviour, the locale override, and the two compliance toggles
 * (RC-006 age/content disclaimer, RC-009 child-audience retention). Built to the Merchant
 * Admin Panel mockup's `pgSettings` block — the same five sections, in the same order, laid
 * out in the WordPress admin's own `form-table` idiom rather than the mockup's cards.
 *
 * `§3.1` (plan, usage bars, Stripe portal link) is a separate task and reads
 * `/v1/merchant/overview` over AJAX like the rest of the panel; the section slot for it is
 * marked below so it lands in the right place rather than at the bottom.
 *
 * ## Why this page posts a form rather than saving over AJAX
 *
 * Every other page on the panel reads, and reads asynchronously so the backend's latency
 * stays out of the 2s render budget (NFR-005, design D-1). This one writes, and writes only
 * to `wp_options` — there is no outbound HTTP in a save, so the argument for AJAX does not
 * apply. What does apply is that `admin_post` + a full round trip is the pattern a merchant's
 * browser, their password manager, and their screen reader all already understand: the form
 * works with JavaScript disabled, the "Settings saved" notice is the core one, and there is
 * no half-saved state to reconcile if the request is interrupted.
 *
 * The one thing the page does fetch is the accent preview, and it does not fetch it at all —
 * `WidgetSettings::accent()` resolves the theme colour locally.
 *
 * ## §3.4 — the no-AI-field audit
 *
 * There is no field here for an AI provider, model, API key, or vector backend, and there is
 * no code path that could add one: `WidgetSettings::sanitize()` drops every key outside its
 * own whitelist, so even a POST carrying `openai_api_key` writes nothing. That is design D1 —
 * the store is a thin client and every AI call belongs to the backend — and it is enforced as
 * a source-level rule by `NoAiFieldAuditTest` rather than left to review.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

/**
 * Renders the Settings form and handles its submission.
 */
final class SettingsPage {

	/** The `admin_post` action the form submits to. */
	public const ACTION = 'wcai_save_settings';

	/** The nonce action guarding that submission (NFR-019). */
	public const NONCE_ACTION = 'wcai_settings_save';

	private WidgetSettings $settings;

	public function __construct( ?WidgetSettings $settings = null ) {
		$this->settings = $settings ?? new WidgetSettings();
	}

	/** The settings store, for callers that need to read what this page wrote. */
	public function settings(): WidgetSettings {
		return $this->settings;
	}

	/**
	 * The Settings body.
	 *
	 * Renders synchronously from local options — no network call, so the page is inside the
	 * budget by construction rather than by measurement.
	 */
	public function render(): void {
		$values = $this->settings->all();
		$accent = $this->settings->accent();

		echo '<div class="wcai-settings" data-wcai-page="settings">';

		$this->render_saved_notice();

		// §3.1's slot — plan, usage bars, and the Stripe portal link belong above the
		// widget configuration, which is the mockup's order and the useful one: a merchant
		// arriving to check their plan should not scroll past four sections of appearance.

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		printf( '<input type="hidden" name="action" value="%s" />', esc_attr( self::ACTION ) );
		wp_nonce_field( self::NONCE_ACTION );

		$this->render_appearance( $values, $accent );
		$this->render_behavior( $values );
		$this->render_language( $values );
		$this->render_disclaimers( $values );

		submit_button( __( 'Save settings', 'woocommerce-ai-chat' ) );
		echo '</form>';

		echo '</div>';
	}

	/**
	 * The post-save confirmation, and the AX-002 notice when the accent was darkened.
	 *
	 * The two are separate notices because they are separate facts: one says the write
	 * happened, the other says the plugin changed a value the merchant chose. Folding the
	 * second into the first would let it be dismissed as boilerplate, and AX-002 requires
	 * the adjustment to be *surfaced* — a silently corrected colour is a merchant who thinks
	 * their brand colour is on the widget when it is not.
	 */
	private function render_saved_notice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display flag; the write it reports was nonce-checked in `handle_save()`.
		$saved = isset( $_GET['wcai_saved'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['wcai_saved'] ) ) : '';

		if ( '1' !== $saved ) {
			return;
		}

		echo '<div class="notice notice-success is-dismissible"><p>';
		echo esc_html__( 'Settings saved.', 'woocommerce-ai-chat' );
		echo '</p></div>';

		$accent = $this->settings->accent();
		if ( ! $accent['adjusted'] ) {
			return;
		}

		echo '<div class="notice notice-warning"><p>';
		printf(
			/* translators: 1: the colour the merchant chose, 2: the darker colour actually used. */
			esc_html__( '%1$s did not have enough contrast against the widget\'s white text, so the widget uses %2$s instead. Pick a darker colour to use your own exactly.', 'woocommerce-ai-chat' ),
			'<code>' . esc_html( $accent['original'] ) . '</code>',
			'<code>' . esc_html( $accent['color'] ) . '</code>'
		);
		echo '</p></div>';
	}

	// -- §3.2 appearance --------------------------------------------------------


	/**
	 * Widget appearance: position, primary colour, title, placeholder (§3.2).
	 *
	 * @param array<string, mixed>                                               $values
	 * @param array{color: string, source: string, adjusted: bool, original: string} $accent
	 */
	private function render_appearance( array $values, array $accent ): void {
		echo '<h2>' . esc_html__( 'Widget appearance', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<table class="form-table" role="presentation"><tbody>';

		// Position. Radios rather than the mockup's four corner buttons: two options do not
		// need a custom control, and a radio group is keyboard-operable and announced as a
		// group by screen readers without any of that being written here (AX-001).
		echo '<tr><th scope="row">' . esc_html__( 'Position', 'woocommerce-ai-chat' ) . '</th><td>';
		echo '<fieldset><legend class="screen-reader-text">' . esc_html__( 'Widget position', 'woocommerce-ai-chat' ) . '</legend>';
		foreach ( self::position_labels() as $value => $label ) {
			printf(
				'<label class="wcai-radio"><input type="radio" name="position" value="%1$s" %2$s /> %3$s</label>',
				esc_attr( $value ),
				checked( $values['position'], $value, false ),
				esc_html( $label )
			);
		}
		echo '</fieldset></td></tr>';

		// Primary colour (US-007, AX-002). `type="color"` degrades to a text field on the
		// browsers that lack it, and the value is `#rrggbb` either way — which is why
		// `WidgetSettings::sanitize_color()` normalises the 3-digit form on the way in.
		echo '<tr><th scope="row"><label for="wcai-primary-color">' . esc_html__( 'Primary color', 'woocommerce-ai-chat' ) . '</label></th><td>';
		printf(
			'<input type="color" id="wcai-primary-color" name="primary_color" value="%1$s" /> ',
			esc_attr( '' !== $values['primary_color'] ? (string) $values['primary_color'] : $accent['color'] )
		);
		printf(
			'<label class="wcai-inline-check"><input type="checkbox" name="primary_color_auto" value="1" %1$s /> %2$s</label>',
			checked( '' === $values['primary_color'], true, false ),
			esc_html__( 'Match my theme automatically', 'woocommerce-ai-chat' )
		);
		echo '<p class="description">';
		echo esc_html( $this->accent_description( $accent ) );
		echo '</p></td></tr>';

		$this->render_text_field(
			'title',
			__( 'Title text', 'woocommerce-ai-chat' ),
			(string) $values['title'],
			__( 'The heading shown at the top of the chat panel. Leave blank to use your store name.', 'woocommerce-ai-chat' )
		);

		$this->render_text_field(
			'placeholder',
			__( 'Placeholder text', 'woocommerce-ai-chat' ),
			(string) $values['placeholder'],
			__( 'The hint shown inside the message box before a shopper types.', 'woocommerce-ai-chat' )
		);

		echo '</tbody></table>';
	}

	/**
	 * The line under the colour picker, which says where the colour came from and whether
	 * AX-002 changed it.
	 *
	 * @param array{color: string, source: string, adjusted: bool, original: string} $accent
	 */
	private function accent_description( array $accent ): string {
		if ( $accent['adjusted'] ) {
			return sprintf(
				/* translators: 1: the colour chosen or detected, 2: the darker colour the widget uses. */
				__( '%1$s does not have enough contrast against white text, so the widget darkens it to %2$s to stay readable.', 'woocommerce-ai-chat' ),
				$accent['original'],
				$accent['color']
			);
		}

		if ( 'theme' === $accent['source'] ) {
			return sprintf(
				/* translators: %s: the hex colour detected from the active theme. */
				__( 'Auto-detected from your theme (%s). Untick the box above to set your own.', 'woocommerce-ai-chat' ),
				$accent['color']
			);
		}

		if ( 'fallback' === $accent['source'] ) {
			return __( 'Your theme does not publish an accent color, so the widget uses the WordPress default. Untick the box above to set your own.', 'woocommerce-ai-chat' );
		}

		return __( 'The color of the chat button and the send button.', 'woocommerce-ai-chat' );
	}

	// -- §3.3 behaviour ---------------------------------------------------------


	/**
	 * Widget behaviour: enable/disable, trigger delay, scroll depth, fallback URL (§3.3).
	 *
	 * The two trigger fields carry `min`/`max` matching the clamps in
	 * `WidgetSettings::sanitize()`. That is a convenience for the merchant, not the
	 * validation — the browser attribute is advisory and the server clamp is what holds.
	 *
	 * @param array<string, mixed> $values
	 */
	private function render_behavior( array $values ): void {
		echo '<h2>' . esc_html__( 'Widget behavior', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<table class="form-table" role="presentation"><tbody>';

		echo '<tr><th scope="row">' . esc_html__( 'Enable chat widget', 'woocommerce-ai-chat' ) . '</th><td>';
		printf(
			'<label class="wcai-inline-check"><input type="checkbox" name="enabled" value="1" %1$s /> %2$s</label>',
			checked( ! empty( $values['enabled'] ), true, false ),
			esc_html__( 'Show the assistant on my storefront', 'woocommerce-ai-chat' )
		);
		// The honest phrasing: turning this off is the merchant's own switch, and it is not
		// the only thing that can hide the widget (a lapsed subscription and a filled quota
		// both do too, per FR-026's composite gate). Saying "shows on your storefront"
		// unconditionally would promise something this checkbox does not decide alone.
		echo '<p class="description">' . esc_html__( 'Turning this off removes the widget from your storefront. Your content and settings are kept.', 'woocommerce-ai-chat' ) . '</p>';
		echo '</td></tr>';

		$this->render_number_field(
			'trigger_delay',
			__( 'Trigger delay (seconds)', 'woocommerce-ai-chat' ),
			(int) $values['trigger_delay'],
			0,
			WidgetSettings::MAX_TRIGGER_DELAY,
			__( 'How long to wait before the chat button appears. 0 shows it immediately.', 'woocommerce-ai-chat' )
		);

		$this->render_number_field(
			'trigger_scroll',
			__( 'Scroll-depth trigger (%)', 'woocommerce-ai-chat' ),
			(int) $values['trigger_scroll'],
			0,
			100,
			__( 'Show the chat button once a shopper has scrolled this far down the page. 0 ignores scrolling.', 'woocommerce-ai-chat' )
		);

		$this->render_text_field(
			'fallback_url',
			__( 'Fallback contact URL', 'woocommerce-ai-chat' ),
			(string) $values['fallback_url'],
			__( 'Where shoppers are sent when the assistant cannot answer. Your contact or support page.', 'woocommerce-ai-chat' ),
			'url'
		);

		echo '</tbody></table>';
	}

	/**
	 * The widget-chrome locale override (§3.3, FR-012).
	 *
	 * Offers the locales that actually have a translation installed rather than a fixed list
	 * of five: an option a merchant can pick that then renders in English is worse than not
	 * offering it. `get_available_languages()` is what WordPress uses for its own site-
	 * language selector, so the list here and the one in Settings → General agree.
	 *
	 * What the stored value actually drives is the *storefront widget's* chrome — its title,
	 * buttons, and hints — via `WidgetSettings::widget_config()` → `Widget\Enqueue`. An
	 * earlier revision labelled this field "Admin panel language" and promised it changed
	 * only the admin pages, which the code has never done (nothing calls
	 * `switch_to_locale()` anywhere in the plugin): a merchant picking Español saw no admin
	 * change and unknowingly pinned their shoppers' widget UI to Spanish. The label now
	 * says what the setting does. The *answers* are unaffected either way — the assistant
	 * replies in each shopper's own detected language (FR-089), a per-conversation backend
	 * decision no store-wide setting should be able to pin.
	 *
	 * @param array<string, mixed> $values
	 */
	private function render_language( array $values ): void {
		echo '<h2>' . esc_html__( 'Language', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<table class="form-table" role="presentation"><tbody>';

		echo '<tr><th scope="row"><label for="wcai-locale">' . esc_html__( 'Chat widget language', 'woocommerce-ai-chat' ) . '</label></th><td>';
		echo '<select id="wcai-locale" name="locale">';
		printf(
			'<option value="" %1$s>%2$s</option>',
			selected( '', (string) $values['locale'], false ),
			esc_html__( 'Same as my site language', 'woocommerce-ai-chat' )
		);
		foreach ( $this->available_locales() as $locale ) {
			printf(
				'<option value="%1$s" %2$s>%3$s</option>',
				esc_attr( $locale ),
				selected( $locale, (string) $values['locale'], false ),
				esc_html( $this->locale_label( $locale ) )
			);
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( 'Sets the language of the chat window itself — its title, buttons, and hints on your storefront. The assistant always replies to each shopper in their own language automatically.', 'woocommerce-ai-chat' ) . '</p>';
		echo '</td></tr>';

		echo '</tbody></table>';
	}

	/**
	 * The locales with a translation installed on this site.
	 *
	 * @return array<int, string>
	 */
	private function available_locales(): array {
		if ( ! function_exists( 'get_available_languages' ) ) {
			return array();
		}
		$languages = get_available_languages();
		return is_array( $languages ) ? $languages : array();
	}

	/**
	 * A locale's own name for itself, falling back to the code.
	 *
	 * "Español" reads to the merchant who wants it; "es_ES" reads to nobody. The translation
	 * install may not carry a name, hence the fallback.
	 */
	private function locale_label( string $locale ): string {
		if ( ! function_exists( 'wp_get_available_translations' ) ) {
			return $locale;
		}

		$translations = wp_get_available_translations();
		if ( is_array( $translations ) && isset( $translations[ $locale ]['native_name'] ) ) {
			return (string) $translations[ $locale ]['native_name'];
		}

		return $locale;
	}

	/**
	 * The two compliance toggles (§3.3, RC-006 and RC-009).
	 *
	 * Both are given their legal footing in the description rather than presented as
	 * preferences. RC-009 in particular carries an explicit warning, because a merchant
	 * turning it on loses the unanswered-questions log and the analytics that depend on
	 * retained conversations — and discovering that from an empty Analytics page a week later
	 * is the support ticket this sentence exists to prevent.
	 *
	 * @param array<string, mixed> $values
	 */
	private function render_disclaimers( array $values ): void {
		echo '<h2>' . esc_html__( 'Disclaimers and audience', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<table class="form-table" role="presentation"><tbody>';

		// RC-006 — the age/content disclaimer.
		echo '<tr><th scope="row">' . esc_html__( 'Age or content disclaimer', 'woocommerce-ai-chat' ) . '</th><td>';
		echo '<fieldset>';
		printf(
			'<label class="wcai-inline-check"><input type="checkbox" name="disclaimer_on" value="1" %1$s /> %2$s</label>',
			checked( ! empty( $values['disclaimer_on'] ), true, false ),
			esc_html__( 'Show a notice before the assistant answers questions about restricted products', 'woocommerce-ai-chat' )
		);
		printf(
			'<p><label for="wcai-disclaimer-text" class="screen-reader-text">%1$s</label>' .
			'<textarea id="wcai-disclaimer-text" name="disclaimer_text" rows="3" class="large-text">%2$s</textarea></p>',
			esc_html__( 'Disclaimer text', 'woocommerce-ai-chat' ),
			esc_textarea( (string) $values['disclaimer_text'] )
		);
		echo '<p class="description">' . esc_html__( 'For age-restricted or regulated products. This is a notice only — it does not verify a shopper\'s age. The disclaimer stays off until you write one.', 'woocommerce-ai-chat' ) . '</p>';
		echo '</fieldset></td></tr>';

		// RC-009 — child-audience mode.
		echo '<tr><th scope="row">' . esc_html__( 'Child-audience mode', 'woocommerce-ai-chat' ) . '</th><td>';
		printf(
			'<label class="wcai-inline-check"><input type="checkbox" name="child_audience" value="1" %1$s /> %2$s</label>',
			checked( ! empty( $values['child_audience'] ), true, false ),
			esc_html__( 'My store is directed at children', 'woocommerce-ai-chat' )
		);
		// The retention gate this text was waiting on has shipped: the backend now writes no
		// `chat_logs` row at all for a turn carrying this flag (RC-009, contract
		// `ChatRequest.child_audience`). So the description says what the flag does, and the
		// previous "not active yet" warning is gone because it is no longer true.
		//
		// It still stops short of "this makes you COPPA compliant", and the restraint is the
		// same one that motivated the earlier weakening: what we control is whether *we*
		// keep a record of the conversation. A merchant's obligations under COPPA and GDPR
		// Article 8 are wider than that, and telling them a checkbox discharged those
		// obligations would be the one kind of inaccuracy in this panel that could expose
		// them rather than merely confuse them.
		//
		// The analytics consequence is stated because a merchant will otherwise report it as
		// a bug: an empty dashboard is the visible effect of this setting working.
		echo '<p class="description">' . esc_html__( 'The AI service keeps no record of conversations from this store — no chat history, no analytics, and no unanswered-questions list. This covers what we store on your behalf; it does not verify a shopper\'s age or, on its own, make your store COPPA or GDPR Article 8 compliant.', 'woocommerce-ai-chat' ) . '</p>';
		echo '</td></tr>';

		echo '</tbody></table>';
	}

	// -- field helpers ----------------------------------------------------------


	/** One `form-table` text row. */
	private function render_text_field( string $name, string $label, string $value, string $description, string $type = 'text' ): void {
		printf(
			'<tr><th scope="row"><label for="wcai-%1$s">%2$s</label></th><td>' .
			'<input type="%3$s" id="wcai-%1$s" name="%1$s" value="%4$s" class="regular-text" />' .
			'<p class="description">%5$s</p></td></tr>',
			esc_attr( $name ),
			esc_html( $label ),
			esc_attr( $type ),
			esc_attr( $value ),
			esc_html( $description )
		);
	}

	/** One `form-table` number row, with the server's own clamp as the input bounds. */
	private function render_number_field( string $name, string $label, int $value, int $min, int $max, string $description ): void {
		printf(
			'<tr><th scope="row"><label for="wcai-%1$s">%2$s</label></th><td>' .
			'<input type="number" id="wcai-%1$s" name="%1$s" value="%3$d" min="%4$d" max="%5$d" step="1" class="small-text" />' .
			'<p class="description">%6$s</p></td></tr>',
			esc_attr( $name ),
			esc_html( $label ),
			(int) $value,
			(int) $min,
			(int) $max,
			esc_html( $description )
		);
	}

	/**
	 * The two positions, translated.
	 *
	 * @return array<string, string>
	 */
	private static function position_labels(): array {
		return array(
			'bottom-right' => __( 'Bottom right', 'woocommerce-ai-chat' ),
			'bottom-left'  => __( 'Bottom left', 'woocommerce-ai-chat' ),
		);
	}

	// -- save -------------------------------------------------------------------


	/**
	 * `admin_post_wcai_save_settings` — persist the form (§3.2–3.3).
	 *
	 * Capability *and* nonce, in that order, for the same reason `Panel::guard_ajax()` does
	 * it that way: an editor who reaches this URL should be told they are not permitted
	 * rather than shown a nonce failure that reads like a bug (NFR-019).
	 *
	 * The submitted array goes to `WidgetSettings::sanitize()` whole rather than field by
	 * field here. That is what makes §3.4 structural: this method names no setting, so it
	 * cannot be the place a provider or key field is quietly added, and any key outside the
	 * whitelist is dropped before it reaches the options table.
	 */
	public function handle_save(): void {
		// `capability()`, not the raw constant: a site that widens access through
		// `wcai_admin_capability` would otherwise get a Settings page it can open and fill
		// in but whose save `wp_die()`s — the menu would honour the filter and the write
		// would not.
		if ( ! current_user_can( Panel::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to change these settings.', 'woocommerce-ai-chat' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified immediately above.
		$posted = wp_unslash( $_POST );
		$posted = is_array( $posted ) ? $posted : array();

		// "Match my theme automatically" is the absence of a stored colour, not a stored
		// flag: an empty `primary_color` is what makes `accent()` re-detect on every read,
		// so a merchant who re-themes is followed rather than pinned to the old accent.
		if ( ! empty( $posted['primary_color_auto'] ) ) {
			$posted['primary_color'] = '';
		}

		$this->settings->save( $posted );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'       => 'wcai-settings',
					'wcai_saved' => '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
