<?php
/**
 * The Merchant Admin Panel shell (`add-merchant-insight-ops §1.1–§1.3`, FR-011/017).
 *
 * One top-level admin menu — Overview → Knowledge Base → Unanswered → Analytics →
 * Settings → Health Check (DUX-001) — with a header the pages share: the plugin title, the
 * always-visible status pill, and the sub-nav. Each page contributes only its body; the
 * chrome is rendered once, here, so the pill cannot exist on five pages in four states.
 *
 * ## Why the pages fetch over AJAX instead of rendering server-side
 *
 * NFR-005 gives the panel a 2s render budget, and every number on it lives behind an
 * outbound HTTPS call to the SaaS. Rendering server-side would put the backend's latency —
 * and its outages — directly into `/wp-admin`'s response time, which is the one place a
 * merchant must always be able to reach (that is also what makes the FR-039 renewal prompt
 * reachable when the widget is off). So `render_page()` emits the shell synchronously and
 * nothing else: the shell is static markup plus one cached read, it hits no network, and
 * the data arrives afterwards through `admin-ajax` (design D-1).
 *
 * The one exception is the status pill, which renders from `SubscriptionGate`'s cached
 * state — already local, already non-blocking — so the header is never blank on first
 * paint. The AJAX response then corrects it from the backend's own `state` field, which is
 * rendered verbatim (FR-017): the plugin does not re-derive "live" from parts it can see.
 *
 * ## Capability and nonce
 *
 * `manage_options` (filterable via `wcai_admin_capability`) on the menu registration is
 * what WordPress enforces for the page itself; the AJAX endpoints re-check it, because a
 * menu capability says nothing about who can POST to `admin-ajax.php` (NFR-019). Both
 * checks, plus the nonce, live in `guard_ajax()` so a new panel endpoint cannot forget
 * one.
 *
 * ## Every endpoint answers in JSON, including when it breaks
 *
 * The guard and a catch-all are combined in `respond()`, which every AJAX handler runs
 * through. The client does `fetch(...).then(r => r.json())`, so a `Throwable` escaping a
 * handler is not an error message — it is an HTML fatal page, a rejected `json()`, an
 * unhandled promise, and a panel that renders nothing at all with no explanation. The most
 * likely trigger is also the least exotic: `BackendClient` throws when `WAI_BACKEND_URL` is
 * undefined or set to plain http, which is precisely the state a store is in while it is
 * still being configured and the merchant is on this panel trying to find out why.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

use WooAIChat\Auth\BackendApi;
use WooAIChat\Auth\BackendUrl;
use WooAIChat\Auth\BackendClient;
use WooAIChat\Auth\SubscriptionGate;
use WooAIChat\Auth\TokenStore;
use WooAIChat\Sync\ContentCollector;
use WooAIChat\Sync\IndexingProgress;
use WooAIChat\Sync\IngestionQueue;
use WooAIChat\Sync\ManualEntryRegistry;
use WooAIChat\Sync\PageFilter;
use WooAIChat\Sync\PageSelector;

/**
 * Registers the panel's menu tree, renders the shared chrome, and owns the AJAX seam the
 * pages read their data through.
 */
final class Panel {

	/**
	 * The panel's own top-level menu slug.
	 *
	 * This used to be `'woocommerce'` — every page was a `add_submenu_page` child of
	 * WooCommerce's menu. That coupled the plugin's entire admin surface to another
	 * plugin's menu existing under a known slug, and the failure was silent: if
	 * WooCommerce was inactive, or a security plugin or admin-menu editor moved or
	 * renamed its entry, our six pages vanished with no notice and no error. A merchant
	 * saw a plugin that installed and activated cleanly and then appeared to do nothing.
	 *
	 * A top-level menu removes that whole failure class. WooCommerce is still a hard
	 * dependency of the *product* — `Requires Plugins: woocommerce` in the header, the
	 * `Compatibility::wc_ok()` guard at activation, and the catalogue this thing indexes
	 * — but the merchant's route to the settings, the health check, and the renewal
	 * prompt no longer depends on another plugin's chrome.
	 */
	public const MENU_SLUG = 'wcai-overview';

	/**
	 * The capability every panel page and AJAX endpoint requires (NFR-019).
	 *
	 * `manage_options`, not `manage_woocommerce`. The panel is no longer inside
	 * WooCommerce's menu, and `manage_woocommerce` is a capability WooCommerce itself
	 * registers — gating a top-level menu on it would reintroduce, as a permissions bug,
	 * exactly the dependency the menu move removes: with WooCommerce deactivated the
	 * capability is not granted to anyone and the pages become unreachable for every user
	 * including the administrator.
	 *
	 * It is also the stricter of the two. These pages accept a license key, show billing
	 * state, and expose a data-erasure path; `manage_options` is the capability WordPress
	 * uses for exactly that class of setting, and it excludes the Shop Manager role that
	 * `manage_woocommerce` would have admitted. Sites that want Shop Managers to reach the
	 * panel can widen it through the filter below rather than by us shipping the wider
	 * default to everyone.
	 */
	public const CAPABILITY = 'manage_options';

	/**
	 * The capability required for the panel, filterable as `wcai_admin_capability`.
	 *
	 * The filter exists so a site can grant the panel to Shop Managers (or to a custom
	 * role) without editing the plugin, which is the supported way to do this in
	 * WordPress. It is read on every check rather than cached, because a role plugin may
	 * register its capabilities after this class is constructed.
	 */
	public static function capability(): string {
		$capability = apply_filters( 'wcai_admin_capability', self::CAPABILITY );

		// A filter that returns something unusable must not lock the merchant out of
		// their own settings, and must not accidentally *widen* access either: falling
		// back to the constant is the only safe reading of a malformed value.
		return is_string( $capability ) && '' !== $capability ? $capability : self::CAPABILITY;
	}

	/** The nonce action shared by the panel's AJAX endpoints. */
	public const NONCE_ACTION = 'wcai_panel';

	/**
	 * The Health Check page's `?page=` slug. `Ops\FailureNotice::HEALTH_CHECK_SLUG` is the
	 * canonical copy — this one aliases it rather than declaring it here, since `Admin`
	 * already depends on `Ops` (see `HealthCheckPage`'s `use WooAIChat\Ops\FailureClass`) and
	 * a dependency the other direction would be a new coupling this class doesn't need.
	 */
	public const HEALTH_CHECK_SLUG = \WooAIChat\Ops\FailureNotice::HEALTH_CHECK_SLUG;

	/**
	 * The Knowledge Base page's `?page=` slug.
	 *
	 * Named here, not just inlined in `nav()`, because `OnboardingWizard::render_activated()`
	 * also needs it: the wizard's "Open the dashboard" link routes here rather than to the
	 * generic Overview page, since indexing and the quality gate — the wizard's steps 4-5 —
	 * are Knowledge Base controls, not Overview ones.
	 */
	public const KNOWLEDGE_SLUG = 'wcai-knowledge';

	/**
	 * The nav, in DUX-001 order. Overview is first because it is the post-onboarding
	 * landing page; the order is data here rather than six `add_submenu_page` calls so
	 * that the sub-nav in the header and the WordPress menu cannot disagree.
	 *
	 * `page` is the `?page=` slug; `handler` names the class that renders the body, which
	 * is resolved lazily in `render_page()` — a page whose class has not landed yet shows
	 * the "not available" body rather than fatalling the whole menu.
	 *
	 * @return array<int, array{page: string, label: string, handler: ?callable}>
	 */
	private function nav(): array {
		return array(
			array(
				'page'    => 'wcai-overview',
				'label'   => __( 'Overview', 'woocommerce-ai-chat' ),
				'handler' => array( $this->overview, 'render' ),
			),
			array(
				'page'    => self::KNOWLEDGE_SLUG,
				'label'   => __( 'Knowledge Base', 'woocommerce-ai-chat' ),
				'handler' => array( $this->knowledge, 'render' ),
			),
			array(
				'page'    => 'wcai-unanswered',
				'label'   => __( 'Unanswered', 'woocommerce-ai-chat' ),
				'handler' => array( $this->unanswered, 'render' ),
			),
			array(
				'page'    => 'wcai-analytics',
				'label'   => __( 'Analytics', 'woocommerce-ai-chat' ),
				'handler' => array( $this->analytics, 'render' ),
			),
			array(
				'page'    => 'wcai-settings',
				'label'   => __( 'Settings', 'woocommerce-ai-chat' ),
				'handler' => array( $this->settings, 'render' ),
			),
			array(
				'page'    => self::HEALTH_CHECK_SLUG,
				'label'   => __( 'Health Check', 'woocommerce-ai-chat' ),
				'handler' => array( $this->health, 'render' ),
			),
		);
	}

	/**
	 * The backend reads. Held as `MerchantData` rather than as a `TokenStore` +
	 * `BackendApi` pair so this class never names a store-token accessor — see that
	 * class' header on why NFR-019's audit makes that a structural requirement and not
	 * a stylistic one.
	 */
	private MerchantData $data;

	private SubscriptionGate $gate;
	private OverviewPage $overview;
	private AnalyticsPage $analytics;
	private UnansweredPage $unanswered;
	private KnowledgePage $knowledge;
	private SettingsPage $settings;
	private HealthCheckPage $health;

	/**
	 * The Knowledge Base's write actions (`add-content-ingestion-kb §5.3–5.5`).
	 *
	 * Optional so the panel can be constructed without the ingestion layer — the page's
	 * *reads* work regardless, and a null scheduler makes the toggles report that the sync
	 * layer is unavailable rather than fatalling the page. Production always passes one.
	 */
	private ?IngestionQueue $ingestion;

	private PageFilter $pages;

	/**
	 * The local record of pushed manual entries (`ManualEntryRegistry`'s header explains
	 * why one must exist). The panel is its writer: `ajax_manual_entry()` records each
	 * successful push, and `ajax_toggle_item()` re-pushes from it / removes from it.
	 */
	private ManualEntryRegistry $manual;

	public function __construct(
		TokenStore $tokens,
		SubscriptionGate $gate,
		?BackendApi $backend = null,
		?IngestionQueue $ingestion = null,
		?PageFilter $pages = null,
		?ManualEntryRegistry $manual = null
	) {
		$this->data       = new MerchantData( $tokens, $backend );
		$this->gate       = $gate;
		$this->overview   = new OverviewPage();
		$this->analytics  = new AnalyticsPage();
		$this->unanswered = new UnansweredPage();
		$this->knowledge  = new KnowledgePage();
		$this->settings   = new SettingsPage();
		$this->health     = new HealthCheckPage();
		$this->ingestion  = $ingestion;
		$this->pages      = $pages ?? new PageSelector();
		$this->manual     = $manual ?? new ManualEntryRegistry();
	}

	/** Register the menu tree, the page assets, and the AJAX endpoints. */
	public function register(): void {
		add_action( 'admin_menu', array( $this, 'add_menu_pages' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		// Panel data reads. `wp_ajax_` only (never `wp_ajax_nopriv_`): these return a
		// store's private analytics, and the unauthenticated variant would serve them to
		// anyone who could guess the action name.
		add_action( 'wp_ajax_wcai_panel_overview', array( $this, 'ajax_overview' ) );
		add_action( 'wp_ajax_wcai_panel_analytics', array( $this, 'ajax_analytics' ) );
		add_action( 'wp_ajax_wcai_panel_knowledge', array( $this, 'ajax_knowledge' ) );
		add_action( 'wp_ajax_wcai_panel_health', array( $this, 'ajax_health' ) );
		// The Knowledge Base's three write actions (`add-content-ingestion-kb §5.3–5.5`).
		// Same `wp_ajax_` rule as the reads, and doubly so: these change what the assistant
		// knows, and the unauthenticated variant would let anyone who guessed the action name
		// delete a store's content.
		add_action( 'wp_ajax_wcai_kb_toggle_item', array( $this, 'ajax_toggle_item' ) );
		add_action( 'wp_ajax_wcai_kb_manual_entry', array( $this, 'ajax_manual_entry' ) );
		add_action( 'wp_ajax_wcai_kb_resync', array( $this, 'ajax_resync' ) );
		// The re-index progress poll (§5.5). A read, but it lives with the writes because it
		// only means anything next to `wcai_kb_resync` — it reports on the job that one
		// starts. Same guard as the rest: how much of a store's catalogue exists is not
		// something to answer for an unauthenticated caller.
		add_action( 'wp_ajax_wcai_kb_progress', array( $this, 'ajax_progress' ) );
		// The go-live-below-threshold decision (D9/FR-014). Same `guard_ajax()` capability +
		// nonce path as its three siblings above — it changes whether a storefront serves an
		// assistant, which is not a lesser write than excluding a page.
		add_action( 'wp_ajax_wcai_kb_override_gate', array( $this, 'ajax_override_gate' ) );
		add_action( 'admin_post_wcai_export_unanswered', array( $this, 'handle_unanswered_export' ) );
		// The Settings form (§3.2–3.3). A full form POST rather than AJAX — see
		// `SettingsPage`'s header on why the one page that *writes* is the one that does not
		// need the async treatment the reads get.
		add_action( 'admin_post_' . SettingsPage::ACTION, array( $this->settings, 'handle_save' ) );
	}

	/**
	 * The widget configuration the merchant has set (FR-012).
	 *
	 * Exposed so the storefront enqueue (`add-shopper-chat §4.2`) reads the same resolved
	 * values the Settings page wrote — including the AX-002 accent correction, which lives on
	 * `WidgetSettings::accent()` precisely so the widget cannot ship the merchant's raw
	 * pre-darkening colour.
	 */
	public function widget_settings(): WidgetSettings {
		return $this->settings->settings();
	}

	/**
	 * Register the six submenu pages in DUX-001 order.
	 *
	 * WordPress orders submenu entries by registration, so iterating `nav()` is what makes
	 * the menu order and the header sub-nav the same fact rather than two lists to keep
	 * aligned.
	 */
	public function add_menu_pages(): void {
		$capability = self::capability();

		// The top-level entry. Its slug is the Overview page's, which is what makes
		// clicking "AI Chat" land on Overview: WordPress renders the parent's callback
		// for the first submenu item, and giving them the same slug means one entry in
		// the submenu list rather than a duplicated "AI Chat → AI Chat".
		add_menu_page(
			__( 'AI Chat', 'woocommerce-ai-chat' ),
			__( 'AI Chat', 'woocommerce-ai-chat' ),
			$capability,
			self::MENU_SLUG,
			function (): void {
				$this->render_page( self::MENU_SLUG );
			},
			self::menu_icon(),
			// Just below WooCommerce's own 55.5. A float, because integer positions
			// collide with other plugins' menus and WordPress resolves a collision by
			// silently dropping one of them.
			56.4
		);

		foreach ( $this->nav() as $entry ) {
			// The first nav entry shares the parent's slug, and that submenu must be
			// registered with an **empty callback**.
			//
			// `get_plugin_page_hookname()` resolves a submenu whose slug matches a
			// registered top-level menu to `toplevel_page_<slug>` — the very same hook
			// `add_menu_page()` just bound its own callback to. `add_submenu_page()` skips
			// its `add_action()` only when the callback is empty, so passing one here
			// registers a *second* callback on that hook, and `admin.php`'s
			// `do_action( $page_hook )` fires both: two page shells, two headers, two
			// status pills, on the panel's landing page. `panel.js` then updates only the
			// first pill it finds and leaves the second reading a stale state.
			//
			// Sharing the slug is deliberate — it is what stops WordPress rendering a
			// duplicated "AI Chat → AI Chat" entry in the sidebar — so the empty callback
			// is the other half of that decision, not an omission.
			$is_parent_alias = self::MENU_SLUG === $entry['page'];

			add_submenu_page(
				self::MENU_SLUG,
				sprintf(
					/* translators: %s: the panel page name, e.g. "Overview". */
					__( 'AI Chat — %s', 'woocommerce-ai-chat' ),
					$entry['label']
				),
				$entry['label'],
				$capability,
				$entry['page'],
				$is_parent_alias
					? ''
					: function () use ( $entry ): void {
						$this->render_page( $entry['page'] );
					}
			);
		}
	}

	/**
	 * The menu icon, as an inline base64 SVG data URI.
	 *
	 * A data URI rather than a file under `assets/`: `assets/` is gitignored build output
	 * and is the directory whose staleness already shipped a broken widget once, so an
	 * icon that lives there would be one more thing that can silently go missing from a
	 * release zip. Inlining makes the icon a property of the code.
	 *
	 * `currentColor` is what lets WordPress paint it for the focused/active menu states;
	 * a hard-coded fill would stay grey while every other icon in the menu highlighted.
	 */
	private static function menu_icon(): string {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
			. 'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
			. '<path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-3.9-.9L3 20l1.4-4.6a8.5 8.5 0 0 1-.9-3.9'
			. 'A8.38 8.38 0 0 1 12 3a8.38 8.38 0 0 1 9 8.5Z"/></svg>';

		// Not obfuscation: `add_menu_page()` takes an icon as a data URI, and a data URI
		// carrying raw SVG has to be encoded to survive attribute quoting. The payload is
		// the literal above — it is readable in this file and is never decoded or executed.
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	/**
	 * Render one panel page: the shared chrome, then the page's own body.
	 *
	 * Emits no outbound HTTP. The body each page contributes is its *shell* — headings,
	 * skeleton, and empty-state markup — which the AJAX response then fills. That is what
	 * keeps the 2s budget a property of the code rather than of the backend's mood.
	 *
	 * @param string $slug The `?page=` slug being rendered.
	 */
	public function render_page( string $slug ): void {
		if ( ! current_user_can( self::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'woocommerce-ai-chat' ) );
		}

		// ES-007: before the store has activated there is nothing to show but the
		// onboarding path, and a blank dashboard would read as breakage. The wizard owns
		// that view, so the panel points at it rather than rendering its own version.
		//
		// A *revoked* store token is not this case, even though it also leaves
		// `get_store_token()` empty: that store has a widget token and a history, and
		// `SubscriptionGate::needs_reauth()` is the state that distinguishes them. Sending
		// it to "continue setup" would tell a paying merchant they never onboarded.
		if ( $this->is_pre_activation() ) {
			$this->render_pre_activation();
			return;
		}

		echo '<div class="wcai-root"><div class="wcai-shell wcai-panel">';
		$this->render_header( $slug );

		$handler = null;
		foreach ( $this->nav() as $entry ) {
			if ( $entry['page'] === $slug ) {
				$handler = $entry['handler'];
				break;
			}
		}

		if ( is_callable( $handler ) ) {
			call_user_func( $handler );
		} else {
			$this->render_unbuilt_page();
		}

		echo '</div></div>';
	}

	// -- chrome -----------------------------------------------------------------


	/**
	 * The shared header: title, status pill, sub-nav.
	 *
	 * @param string $slug The current page, so the sub-nav can mark it.
	 */
	private function render_header( string $slug ): void {
		$label = '';
		foreach ( $this->nav() as $entry ) {
			if ( $entry['page'] === $slug ) {
				$label = $entry['label'];
				break;
			}
		}

		echo '<header class="wcai-panel-header">';
		echo '<div class="wcai-panel-titles">';
		echo '<p class="wcai-eyebrow">' . esc_html( get_bloginfo( 'name' ) ) . '</p>';
		echo '<h1 class="wcai-h1">' . esc_html( '' !== $label ? $label : __( 'AI Chat', 'woocommerce-ai-chat' ) ) . '</h1>';
		echo '</div>';
		$this->render_status_pill();
		echo '</header>';

		// `aria-current="page"` rather than the active class alone: the tab highlight is
		// colour, and colour is not available to a screen reader (NFR-045).
		echo '<nav class="wcai-panel-nav" aria-label="' . esc_attr__( 'AI Chat sections', 'woocommerce-ai-chat' ) . '">';
		foreach ( $this->nav() as $entry ) {
			$active = $entry['page'] === $slug;
			printf(
				'<a class="wcai-tab%1$s" href="%2$s"%3$s>%4$s</a>',
				$active ? ' is-active' : '',
				esc_url( admin_url( 'admin.php?page=' . $entry['page'] ) ),
				$active ? ' aria-current="page"' : '',
				esc_html( $entry['label'] )
			);
		}
		echo '</nav>';
	}

	/**
	 * The always-visible status pill (FR-017, DUX-002).
	 *
	 * Rendered from the *cached* subscription state so the header paints immediately; the
	 * AJAX overview response then replaces its text with the backend's `state` field
	 * verbatim. The two can briefly disagree — a store whose quota filled since the last
	 * gate refresh shows "Live" for one paint — and correcting it from the authoritative
	 * read is exactly right: inventing "quota reached" locally would need the plugin to
	 * hold its own copy of the quota rules, which is the divergence D1 exists to prevent.
	 */
	private function render_status_pill(): void {
		$state = $this->local_state();

		printf(
			'<span class="wcai-pill wcai-pill-%1$s" data-wcai-pill="1" data-state="%1$s">'
				. '<span class="wcai-visually-hidden">%2$s </span>%3$s</span>',
			esc_attr( $state ),
			esc_html__( 'Status:', 'woocommerce-ai-chat' ),
			esc_html( self::state_label( $state ) )
		);
	}

	/**
	 * The best state the plugin can name without calling the backend.
	 *
	 * Deliberately conservative: it distinguishes only what the local cache actually
	 * knows — a lapsed subscription and "everything looks fine" — because the remaining
	 * states (indexing, quota reached) are backend facts. Guessing them from local data
	 * would put a second definition of each in the plugin.
	 */
	private function local_state(): string {
		if ( ! $this->gate->is_widget_available() ) {
			return 'subscription_lapsed';
		}
		return 'live';
	}

	/**
	 * The merchant-facing label for a backend `WidgetState`.
	 *
	 * The contract's five states are translated here and nowhere else, so the pill, the
	 * AJAX payload, and any later surface that names a state read one table. An unknown
	 * state — a backend newer than this plugin — falls through to the raw value rather
	 * than to "unknown": showing what the backend said is more useful to a merchant on
	 * the phone with support than erasing it.
	 */
	public static function state_label( string $state ): string {
		$labels = array(
			'live'                => __( 'Live', 'woocommerce-ai-chat' ),
			'indexing'            => __( 'Indexing', 'woocommerce-ai-chat' ),
			'paused'              => __( 'Paused', 'woocommerce-ai-chat' ),
			'quota_reached'       => __( 'Quota reached', 'woocommerce-ai-chat' ),
			'subscription_lapsed' => __( 'Subscription lapsed', 'woocommerce-ai-chat' ),
		);

		return $labels[ $state ] ?? $state;
	}

	/**
	 * Whether this store has never completed activation (ES-007).
	 *
	 * The token check itself lives on `MerchantData` (only the boolean crosses back here),
	 * and `needs_reauth()` carves out the revoked-token store, which has activation
	 * material and belongs on the re-auth path rather than back at step one.
	 */
	private function is_pre_activation(): bool {
		if ( $this->gate->needs_reauth() ) {
			return false;
		}
		return ! $this->data->has_activation_material();
	}

	/** ES-007 — the store has never activated; the wizard is the whole content. */
	private function render_pre_activation(): void {
		echo '<div class="wcai-root"><div class="wcai-shell wcai-panel">';
		echo '<h1 class="wcai-h1">' . esc_html__( 'AI Chat', 'woocommerce-ai-chat' ) . '</h1>';
		echo '<p class="wcai-sub">' . esc_html__( 'Finish setup to see your dashboard. It takes about two minutes.', 'woocommerce-ai-chat' ) . '</p>';
		echo '<div class="wcai-card wcai-preactivation">';
		echo '<p>' . esc_html__( 'Your store is not connected to the AI service yet. The setup wizard walks through choosing a plan, entering your license key, and granting data-processing consent.', 'woocommerce-ai-chat' ) . '</p>';
		printf(
			'<p><a class="button wcai-btn" href="%1$s">%2$s</a></p>',
			esc_url( admin_url( 'admin.php?page=' . OnboardingWizard::PAGE_SLUG ) ),
			esc_html__( 'Continue setup', 'woocommerce-ai-chat' )
		);
		echo '</div>';
		echo '</div></div>';
	}

	/** A nav slot whose body belongs to a change that has not landed yet. */
	private function render_unbuilt_page(): void {
		echo '<div class="wcai-notice"><p>';
		echo esc_html__( 'This page is not available in your version of AI Chat yet.', 'woocommerce-ai-chat' );
		echo '</p></div>';
	}

	// -- assets -----------------------------------------------------------------


	/**
	 * Enqueue the panel's CSS/JS on its own pages only.
	 *
	 * `wp_localize_script` carries the nonce and the AJAX URL, so the browser never needs
	 * a nonce printed into the page body where a stray `esc_html` could mangle it.
	 *
	 * @param string $hook The hook suffix WordPress sets for the current admin page.
	 */
	public function enqueue_assets( $hook ): void {
		if ( ! $this->is_panel_hook( (string) $hook ) ) {
			return;
		}

		// Served from `admin/`, not `assets/`: `assets/` is build output and is gitignored
		// (it holds the esbuild widget bundle). The panel's CSS/JS are hand-written source
		// with no build step, so they live in a committed directory.
		wp_enqueue_style(
			'wcai-design-system',
			WAI_PLUGIN_URL . 'admin/design-system.css',
			array(),
			WAI_VERSION
		);
		wp_enqueue_style(
			'wcai-panel',
			WAI_PLUGIN_URL . 'admin/panel.css',
			array( 'wcai-design-system' ),
			WAI_VERSION
		);
		wp_enqueue_script(
			'wcai-panel',
			WAI_PLUGIN_URL . 'admin/panel.js',
			array(),
			WAI_VERSION,
			true
		);
		wp_localize_script(
			'wcai-panel',
			'wcaiPanel',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( self::NONCE_ACTION ),
				// The Knowledge Base pager steps by this; see the client's note on why it is
				// not a literal there.
				'pageSize' => KnowledgePage::PAGE_SIZE,
				'i18n'     => array(
					'loadFailed'        => __( 'Could not load this data. Refresh to try again.', 'woocommerce-ai-chat' ),
					'addAnswer'         => __( 'Add Answer', 'woocommerce-ai-chat' ),
					'included'          => __( 'Included', 'woocommerce-ai-chat' ),
					'excluded'          => __( 'Excluded', 'woocommerce-ai-chat' ),
					'includeLabel'      => __( 'Include this item in the knowledge base', 'woocommerce-ai-chat' ),
					'saving'            => __( 'Saving…', 'woocommerce-ai-chat' ),
					'actionFailed'      => __( 'That change could not be saved. Try again in a moment.', 'woocommerce-ai-chat' ),
					// Health Check's re-sync CTA (§4.4) — a link, not a button, so the label
					// names the destination rather than an action this page does not perform.
					'openKnowledgeBase' => __( 'Open Knowledge Base', 'woocommerce-ai-chat' ),
				),
			)
		);
	}

	/**
	 * Whether a hook suffix belongs to one of the panel's pages.
	 *
	 * A top-level menu produces two hook shapes, and both have to match or the panel
	 * loads unstyled on exactly one page. The parent entry is `toplevel_page_<slug>`;
	 * every submenu is `<sanitized-parent-title>_page_<slug>`, where the parent title is
	 * run through `sanitize_title()` — and it is the *translated* title, so hard-coding
	 * `ai-chat_page_` would break on every locale but English.
	 *
	 * Matching on the slug suffix rather than reconstructing the prefix sidesteps both
	 * problems: the slugs are ours, they are unique, and a page added to `nav()` is styled
	 * without a second edit here.
	 */
	private function is_panel_hook( string $hook ): bool {
		if ( 'toplevel_page_' . self::MENU_SLUG === $hook ) {
			return true;
		}

		foreach ( $this->nav() as $entry ) {
			if ( self::hook_matches_slug( $hook, $entry['page'] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether an admin hook suffix belongs to the given `?page=` slug.
	 *
	 * WordPress builds a submenu hook as `<prefix>_page_<slug>`. Comparing the segment
	 * after the *last* `_page_` is what makes this locale-independent, and anchoring to
	 * the end prevents `wcai-overview` from matching a hypothetical
	 * `..._page_wcai-overview-extra`.
	 */
	private static function hook_matches_slug( string $hook, string $slug ): bool {
		$needle = '_page_' . $slug;
		$at     = strrpos( $hook, $needle );

		return false !== $at && strlen( $hook ) === $at + strlen( $needle );
	}

	// -- AJAX -------------------------------------------------------------------


	/**
	 * `wp_ajax_wcai_panel_overview` — the Overview page's data (§2.1) and the pill's
	 * authoritative state (§1.2).
	 */
	public function ajax_overview(): void {
		$this->respond(
			function (): void {

				$result = $this->data->overview();
				$body   = $this->unwrap( $result );

				if ( null === $body ) {
					wp_send_json_error( $this->transport_error( $result ), 200 );
					return;
				}

				$state = is_string( $body['state'] ?? null ) ? (string) $body['state'] : 'paused';

				wp_send_json_success(
					array(
						'state'      => $state,
						'stateLabel' => self::state_label( $state ),
						'overview'   => $this->overview->payload( $body ),
					)
				);
			}
		);
	}

	/** `wp_ajax_wcai_panel_analytics` — Analytics (§2.2, §2.3) and Unanswered (§2.4). */
	public function ajax_analytics(): void {
		$this->respond(
			function (): void {

				$result = $this->data->analytics( $this->window_days() );
				$body   = $this->unwrap( $result );

				if ( null === $body ) {
					wp_send_json_error( $this->transport_error( $result ), 200 );
					return;
				}

				wp_send_json_success(
					array(
						'analytics'  => $this->analytics->payload( $body ),
						'unanswered' => $this->unanswered->payload( $body ),
					)
				);
			}
		);
	}

	/**
	 * `wp_ajax_wcai_panel_knowledge` — the Knowledge Base's inventory and quality score
	 * (`add-content-ingestion-kb §5.1–5.2`).
	 */
	public function ajax_knowledge(): void {
		$this->respond(
			function (): void {

				$offset = $this->offset();
				$result = $this->data->knowledge( KnowledgePage::PAGE_SIZE, $offset );
				$body   = $this->unwrap( $result );

				if ( null === $body ) {
					wp_send_json_error( $this->transport_error( $result ), 200 );
					return;
				}

				wp_send_json_success(
					array( 'knowledge' => $this->knowledge->payload( $body, $offset ) )
				);
			}
		);
	}

	/**
	 * `wp_ajax_wcai_panel_health` — the Health Check page's six checks + indexing progress
	 * (`add-merchant-insight-ops §4.1/§4.4`).
	 *
	 * The indexing-progress shaping is `KnowledgePage::progress()`, the same method
	 * `ajax_resync()` already calls — one formatting of `IndexingProgress`, read by both the
	 * page that triggers a re-sync and the page a merchant checks its outcome on.
	 *
	 * A failed read (§4.2) still returns success, not the usual `transport_error()` — the
	 * point of consulting the status surface is to give this specific page a *diagnosis*
	 * instead of the generic "could not reach" every other page falls back to, and
	 * `HealthCheckPage::payload()` renders that diagnosis as its own `connectivity` row.
	 * `$result['status'] === 401` still isn't this: an unauthorised store isn't unreachable,
	 * it's revoked, so that case keeps the ordinary re-auth `transport_error()`.
	 */
	public function ajax_health(): void {
		$this->respond(
			function (): void {

				$result = $this->data->health();
				$body   = $this->unwrap( $result );

				if ( null === $body ) {
					if ( 401 === $result['status'] ) {
						wp_send_json_error( $this->transport_error( $result ), 200 );
						return;
					}

					wp_send_json_success(
						array(
							'health'   => $this->health->payload( array(), $this->gate->failure_class(), BackendUrl::canonical() ),
							'indexing' => $this->knowledge->progress( array() ),
						)
					);
					return;
				}

				$indexing = is_array( $body['indexing'] ?? null ) ? $body['indexing'] : array();

				wp_send_json_success(
					array(
						'health'   => $this->health->payload( $body, null, BackendUrl::canonical() ),
						'indexing' => $this->knowledge->progress( $indexing ),
					)
				);
			}
		);
	}

	/**
	 * `wp_ajax_wcai_kb_toggle_item` — per-item include/exclude (§5.3, FR-013/036).
	 *
	 * Excluding removes the item's chunks (FR-036), so the enqueued job is a *delete* rather
	 * than a flag write; re-including re-collects and pushes the item. Both go through the
	 * scheduler for the NFR-030 reason in `KnowledgePage`'s header — a toggle must not put an
	 * outbound HTTP call in the merchant's click.
	 *
	 * The local override is recorded either way, and recorded *first*: it is what stops the
	 * next nightly walk from re-pushing a page the merchant just excluded (design D-6c). If
	 * the enqueue then fails, the store's stated intent still survives, and the nightly
	 * manifest-diff reconciles the index to it within 24h (D-7). The reverse order would let
	 * a failed option write leave a delete already in flight with nothing recording why.
	 */
	public function ajax_toggle_item(): void {
		$this->respond(
			function (): void {

				$object_type = $this->posted_string( 'object_type' );
				$object_id   = $this->posted_int( 'object_id' );
				$source_id   = $this->posted_int( 'source_id' );
				$include     = '1' === $this->posted_string( 'included' );

				if ( '' === $object_type || $object_id <= 0 ) {
					wp_send_json_error(
						array( 'message' => __( 'That item could not be identified. Refresh the page and try again.', 'woocommerce-ai-chat' ) ),
						200
					);
					return;
				}

				// Manual entries have no WordPress object behind them, so the re-collect path below
				// cannot serve them: `collect_by_type()` returns null for `manual`, and the single-push
				// job reads null as "gone → delete" — which made re-*including* a manual entry delete
				// it. They get their own path, driven by the local registry of pushed entries.
				if ( 'manual' === $object_type ) {
					$this->toggle_manual_entry( $object_id, $include );
					return;
				}

				// The store-identity row (`collect_store_identity()`, the reserved page-namespace
				// slot for source id 0) and any object type the collector cannot re-collect must
				// not fall through to the queue: an include would re-collect nothing and turn into
				// a delete, and an excluding delete would be resurrected by the next nightly
				// manifest anyway. Rejecting is the only answer that leaves plugin and backend
				// agreeing on what exists.
				$recollectable = in_array(
					$object_type,
					array( ContentCollector::TYPE_PRODUCT, ContentCollector::TYPE_CATEGORY, ContentCollector::TYPE_PAGE ),
					true
				);
				if ( ! $recollectable
				|| ( ContentCollector::TYPE_PAGE === $object_type
					&& ContentCollector::encode_object_id( ContentCollector::TYPE_PAGE, 0 ) === $object_id )
				) {
					wp_send_json_error(
						array( 'message' => __( 'This item is managed automatically and cannot be toggled here.', 'woocommerce-ai-chat' ) ),
						200
					);
					return;
				}

				// Only pages carry a merchant override: the D-6 heuristic it feeds is page selection,
				// and there is no equivalent question for a product — a published product is in the
				// catalogue by definition. Excluding a product is a delete and nothing more, which
				// the nightly walk will honour only until that product is next edited. That is a
				// known limit of the override store, noted rather than silently papered over.
				if ( ContentCollector::TYPE_PAGE === $object_type && $source_id > 0 ) {
					$this->pages->set_override( $source_id, $include );
				}

				if ( null === $this->ingestion ) {
					wp_send_json_error(
						array( 'message' => __( 'The content sync layer is not available on this site, so this change was not applied.', 'woocommerce-ai-chat' ) ),
						200
					);
					return;
				}

				if ( $include ) {
					$this->ingestion->enqueue_single( $object_type, $source_id > 0 ? $source_id : $object_id );
				} else {
					// The tombstone version is `time()`, matching what the hook layer stamps, so the
					// last-writer-wins comparison treats a merchant's exclusion exactly as it treats
					// a save: whichever happened later is the one that stands (D13).
					$this->ingestion->enqueue_delete( $object_type, $object_id, time() );
				}

				wp_send_json_success(
					array(
						'included' => $include,
						'message'  => $include
							? __( 'Item queued for indexing.', 'woocommerce-ai-chat' )
							: __( 'Item removed from the knowledge base.', 'woocommerce-ai-chat' ),
					)
				);
			}
		);
	}

	/**
	 * Include/exclude for a manual entry, driven by the `ManualEntryRegistry`.
	 *
	 * **Exclude** removes the entry from the registry *first*, then queues the delete. The
	 * order matters for the same reason `ajax_toggle_item()` records the page override
	 * first: the registry is what the nightly manifest re-lists, and the backend answers a
	 * manifest id it does not hold with `request_full` — so a registry row left behind
	 * would resurrect an entry the merchant deleted. Removed-but-undelivered is the benign
	 * failure: the next nightly manifest omits the id and the backend tombstones it.
	 *
	 * **Include** re-pushes the stored entry synchronously through the same
	 * `push_manual_entry()` path the original save used (see `ajax_manual_entry()`'s
	 * header on why manual entries do not go through the queue), stamped with a fresh
	 * version so last-writer-wins dates the re-include after the exclusion's tombstone
	 * (D-3). The hash is the one recorded at push time, so an unchanged entry is not
	 * re-embedded.
	 */
	private function toggle_manual_entry( int $object_id, bool $should_include ): void {
		if ( ! $should_include ) {
			$this->manual->forget( $object_id );

			if ( null === $this->ingestion ) {
				wp_send_json_error(
					array( 'message' => __( 'The content sync layer is not available on this site, so this change was not applied.', 'woocommerce-ai-chat' ) ),
					200
				);
				return;
			}

			// The tombstone version is `time()`, matching the other exclude path, so the
			// backend's last-writer-wins treats the exclusion as the latest write (D13).
			$this->ingestion->enqueue_delete( 'manual', $object_id, time() );

			wp_send_json_success(
				array(
					'included' => false,
					'message'  => __( 'Item removed from the knowledge base.', 'woocommerce-ai-chat' ),
				)
			);
			return;
		}

		$version = time();
		$item    = $this->manual->push_item( $object_id, $version );

		if ( null === $item ) {
			// Excluding removed it from the registry (or it predates the registry), so
			// there is no stored content to re-push. Anything but this error would either
			// lie or — worse, the old behaviour — push a delete while reporting success.
			wp_send_json_error(
				array( 'message' => __( 'This answer is no longer stored on this site. Re-add it from the Unanswered page.', 'woocommerce-ai-chat' ) ),
				200
			);
			return;
		}

		$result = $this->data->push_manual_entry( $item );
		if ( null === $this->unwrap( $result ) ) {
			wp_send_json_error( $this->transport_error( $result ), 200 );
			return;
		}

		// Record the new version so the nightly manifest carries what was just pushed.
		$entry = $this->manual->get( $object_id );
		if ( null !== $entry ) {
			$this->manual->remember( $object_id, $entry['title'], $entry['content'], (string) $item['content_hash'], $version );
		}

		wp_send_json_success(
			array(
				'included' => true,
				'message'  => __( 'Entry re-added to the knowledge base.', 'woocommerce-ai-chat' ),
			)
		);
	}

	/**
	 * `wp_ajax_wcai_kb_manual_entry` — manual knowledge injection (§5.4, FR-035).
	 *
	 * Pushed synchronously — see `KnowledgePage`'s header on why this one action does not go
	 * through the queue.
	 *
	 * The entry is pushed as `object_type: manual`, which is what the contract and the
	 * chunker recognise. **The retrieval-priority half of FR-035 is not implemented
	 * backend-side** — `manual` is an object type and a chunk prefix today, and nothing
	 * ranks it above crawled content at query time. That belongs to the RAG path
	 * (`add-shopper-chat`) and is recorded in this change's `tasks.md` so it is not mistaken
	 * for done.
	 */
	public function ajax_manual_entry(): void {
		$this->respond(
			function (): void {

				$title   = $this->posted_string( 'title' );
				$content = $this->posted_text( 'content' );

				if ( '' === $title || '' === $content ) {
					wp_send_json_error(
						array( 'message' => __( 'Give the entry both a title and an answer before saving it.', 'woocommerce-ai-chat' ) ),
						200
					);
					return;
				}

				$body = $title . "\n\n" . $content;

				// Derived from the title so re-saving the same entry replaces it rather than
				// accumulating near-duplicates the merchant cannot tell apart. The id lives in the
				// registry's reserved band above every catalogue namespace — the manifest keys on
				// `object_id` alone, so a manual id landing in the product or page id space (as the
				// old `crc32 % 2e9` did) made the nightly reconciliation cross items up.
				$object_id = $this->manual->id_for_title( $title );
				$hash      = hash( 'sha256', $body );
				$version   = time();

				$result = $this->data->push_manual_entry(
					array(
						'object_type'  => 'manual',
						'object_id'    => $object_id,
						'content'      => $body,
						'content_hash' => $hash,
						'version'      => $version,
						'source'       => 'manual',
						'meta'         => array( 'title' => $title ),
					)
				);

				if ( null === $this->unwrap( $result ) ) {
					wp_send_json_error( $this->transport_error( $result ), 200 );
					return;
				}

				// Recorded only after the backend accepted the push (see `ManualEntryRegistry`).
				// Without this row the entry would vanish twice over: the nightly manifest could
				// not list it (the backend would tombstone it within 24h), and the include toggle
				// would have nothing to re-push it from.
				$this->manual->remember( $object_id, $title, $content, $hash, $version );

				wp_send_json_success(
					array( 'message' => __( 'Entry saved. It will answer questions as soon as indexing finishes.', 'woocommerce-ai-chat' ) )
				);
			}
		);
	}

	/**
	 * `wp_ajax_wcai_kb_resync` — the manual full re-sync (§5.5, FR-016).
	 *
	 * The confirmation is the page's (see `KnowledgePage::render_resync_confirm()`); by the
	 * time this runs the merchant has agreed. `enqueue_full_resync()` is idempotent against a
	 * double-click — a walk already in flight is not restarted — so an impatient second press
	 * cannot put two cursors over the same catalogue.
	 *
	 * Progress is read from `/v1/merchant/health`, which is where the contract carries
	 * `IndexingProgress`. A failure to read it is *not* a failure of the re-sync: the job is
	 * already queued, so the response reports the scheduling honestly and lets the page
	 * re-poll rather than telling the merchant their re-index did not start.
	 */
	public function ajax_resync(): void {
		$this->respond(
			function (): void {

				if ( null === $this->ingestion ) {
					wp_send_json_error(
						array( 'message' => __( 'The content sync layer is not available on this site, so a re-index could not be started.', 'woocommerce-ai-chat' ) ),
						200
					);
					return;
				}

				$this->ingestion->enqueue_full_resync();

				// The job is queued on the strength of the enqueue above — a fact the plugin
				// owns — so the response reports that, not the backend's (unread) queue
				// state. The old `progress( array() )` here hit the method's "the health
				// read failed" branch and answered the merchant's click with "Indexing
				// status is unavailable right now.", which reads as the re-index not having
				// started. `queued` is the plugin's own scheduling confirmation.
				wp_send_json_success(
					array( 'progress' => $this->knowledge->progress( array( 'state' => 'queued' ) ) )
				);
			}
		);
	}

	/**
	 * `wp_ajax_wcai_kb_progress` — how far the running re-index has got (§5.5, FR-016).
	 *
	 * Answers from the *plugin's* record (`IndexingProgress`), not the backend's health
	 * block, because the queue being reported on is the plugin's: `IngestionScheduler`
	 * walks the catalogue in Action Scheduler jobs and is the only component that knows
	 * the cursor. See that class's header for why this is local and what it does not claim.
	 *
	 * Deliberately cheap — one non-autoloaded option read, no outbound HTTP. The page polls
	 * this every few seconds while a walk is running, and a poll that cost a backend round
	 * trip would spend the §5.6 latency budget on watching a progress bar.
	 */
	public function ajax_progress(): void {
		$this->respond(
			function (): void {
				wp_send_json_success(
					array( 'progress' => $this->knowledge->resync_progress( ( new IndexingProgress() )->read() ) )
				);
			}
		);
	}

	/**
	 * `wp_ajax_wcai_kb_override_gate` — go live with a below-threshold quality score
	 * (§5.2, D9/FR-014, contract `overrideQualityGate`).
	 *
	 * ## Why this is a synchronous call and not an enqueued job
	 *
	 * Every other write on this page defers to Action Scheduler, for the NFR-030 reason in
	 * `KnowledgePage`'s header — a merchant's click must not wait on a backend that might be
	 * down. This one is the documented exception, and it is the same exception the manual
	 * entry makes: the merchant is asking a question the backend alone can answer ("is my
	 * widget live now?"), and an enqueued job would have to answer "probably, later". The
	 * 8s client timeout bounds it.
	 *
	 * ## Why a failure must not be softened
	 *
	 * The backend returns 503 when it cannot record the decision, deliberately, rather than
	 * a false 200 — a merchant told "done" for a write that never happened believes their
	 * widget is live while the gate is still shut, and the next thing that happens is a
	 * support ticket about a storefront with no chat on it. So this reports the failure and
	 * does not update the card.
	 *
	 * The response carries the recomputed `QualityScore`, so the page re-renders from the
	 * backend's verdict rather than optimistically flipping `passed` in the browser. Same
	 * rule as `KnowledgePage::quality()`: `passed` is read, never re-derived.
	 */
	public function ajax_override_gate(): void {
		$this->respond(
			function (): void {

				$result = $this->data->override_quality_gate();
				$body   = $this->unwrap( $result );

				if ( null === $body ) {
					wp_send_json_error( $this->transport_error( $result ), 200 );
					return;
				}

				wp_send_json_success(
					array(
						'quality' => $this->knowledge->quality_block( $body ),
						'message' => __( 'Your assistant is now live on your storefront.', 'woocommerce-ai-chat' ),
					)
				);
			}
		);
	}

	/**
	 * `admin_post_wcai_export_unanswered` — the unanswered log as CSV (§2.4, DUX-006).
	 *
	 * A full page POST rather than AJAX: the browser has to receive a file, and
	 * `admin-post.php` is where WordPress expects a handler that sends its own headers.
	 */
	public function handle_unanswered_export(): void {
		if ( ! current_user_can( self::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'woocommerce-ai-chat' ) );
		}
		check_admin_referer( self::NONCE_ACTION );

		$result = $this->data->analytics( $this->window_days() );
		$body   = $this->unwrap( $result );

		if ( null === $body ) {
			// The export cannot be half a file. Bounce back to the page, where the panel's
			// own unreachable-notice explains it, rather than downloading an empty CSV a
			// merchant might read as "no unanswered questions".
			wp_safe_redirect( admin_url( 'admin.php?page=wcai-unanswered&wcai_export=failed' ) );
			exit;
		}

		$this->unanswered->send_csv( $body );
	}

	/**
	 * The capability + nonce check every panel AJAX endpoint runs first (NFR-019).
	 *
	 * `check_ajax_referer` with `false` for `$die` would let the handler continue on a bad
	 * nonce, so the default (die) is what we want — but the capability is checked *first*,
	 * so an unprivileged user gets "not permitted" rather than a nonce error that reads
	 * like a bug to them.
	 */
	private function guard_ajax(): void {
		if ( ! current_user_can( self::capability() ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to view this data.', 'woocommerce-ai-chat' ) ),
				403
			);
			return;
		}
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
	}

	/**
	 * Run one AJAX handler behind the guard, and behind a catch-all.
	 *
	 * Every panel endpoint goes through here for the same reason they all go through
	 * `guard_ajax()`: a new endpoint must not be able to forget it. The two are combined into
	 * one call so there is a single thing to remember rather than two.
	 *
	 * ## Why a catch-all is not lazy here
	 *
	 * The panel's client does `fetch(...).then(r => r.json())`. A `Throwable` escaping a
	 * handler makes `admin-ajax.php` emit a PHP fatal — an HTML page, or nothing at all when
	 * `display_errors` is off — and `r.json()` then rejects. The rejection is unhandled, no
	 * branch runs, no notice renders: the merchant gets a permanently empty panel with no
	 * message, and the only trace is a line in a PHP error log they cannot see.
	 *
	 * This is not hypothetical. `BackendClient::require_base_url()` throws `RuntimeException`
	 * for the two most likely misconfigurations there are — `WAI_BACKEND_URL` undefined, or
	 * defined over plain http (NFR-014's transport rule) — and both are exactly the state a
	 * store is in while someone is still setting it up, which is when they are most likely to
	 * be looking at this panel to find out what is wrong.
	 *
	 * Catching `Throwable` rather than `Exception`: a `TypeError` from a malformed backend
	 * response blanks the panel just as thoroughly as a `RuntimeException`, and the handler
	 * has nothing useful to do with either beyond saying so.
	 */
	private function respond( callable $handler ): void {
		$this->guard_ajax();

		try {
			$handler();
		} catch ( \Throwable $e ) {
			$this->fail_with_exception( $e );
		}
	}

	/**
	 * Turn an escaped `Throwable` into the panel's ordinary error envelope.
	 *
	 * Same shape `transport_error()` returns, so the client renders it through the existing
	 * notice path rather than needing a branch for "the plugin itself broke".
	 *
	 * The exception message is *not* sent to the browser. It can name a file path, a
	 * constant, or a chunk of a request, and this response is readable by anyone holding the
	 * capability. What the merchant gets instead is the one thing they can act on: a pointer
	 * to the Health Check page, which reads the configured URL and says whether it is usable.
	 *
	 * The detail goes to the PHP error log, and only under `WP_DEBUG`. That is the WordPress
	 * convention for a reason that applies here — a production site's error log is often
	 * shipped somewhere shared, and a handler that can be triggered by any capable user is a
	 * handler that can be made to write to it repeatedly. Under `WP_DEBUG` the site owner has
	 * asked for exactly this, which is the situation a developer diagnosing a blank panel is
	 * in.
	 */
	private function fail_with_exception( \Throwable $e ): void {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- WP_DEBUG-gated diagnostic; see the docblock.
			error_log(
				sprintf(
					'WCAI panel: %s in %s:%d — %s',
					get_class( $e ),
					$e->getFile(),
					$e->getLine(),
					$e->getMessage()
				)
			);
		}

		wp_send_json_error(
			array(
				'reason'      => 'plugin_error',
				'message'     => __( 'This panel could not load because the plugin is not configured correctly. Open Health Check for the details.', 'woocommerce-ai-chat' ),
				'action'      => admin_url( 'admin.php?page=' . self::HEALTH_CHECK_SLUG ),
				'actionLabel' => __( 'Open Health Check', 'woocommerce-ai-chat' ),
			),
			200
		);
	}

	/**
	 * The rolling window the analytics reads use.
	 *
	 * Read from the request so the page can offer a range selector, clamped to the
	 * contract's bounds by `BackendClient::merchant_analytics()`. The nonce is verified in
	 * `guard_ajax()` / `check_admin_referer()` before either caller reaches this.
	 */
	private function window_days(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- verified by the caller's guard.
		$raw = $_REQUEST['window_days'] ?? 30;
		return is_numeric( $raw ) ? (int) $raw : 30;
	}

	/**
	 * The Knowledge Base page offset the client asked for (§5.1).
	 *
	 * Clamped at zero here and at the contract's ceiling in `BackendClient`; the nonce is
	 * verified by `guard_ajax()` before any caller reaches this.
	 */
	private function offset(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- verified by the caller's guard.
		$raw = $_REQUEST['offset'] ?? 0;
		return is_numeric( $raw ) ? max( 0, (int) $raw ) : 0;
	}

	/**
	 * A single-line POST field, sanitized (NFR-021).
	 *
	 * Every caller is behind `guard_ajax()`, so the nonce and capability are already
	 * established; what this adds is that no raw request value reaches an option write, a
	 * job argument, or the backend. `sanitize_text_field` also strips the newlines that make
	 * a "title" into two lines of content.
	 */
	private function posted_string( string $key ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by the caller's guard.
		$raw = $_POST[ $key ] ?? '';
		return is_string( $raw ) ? sanitize_text_field( wp_unslash( $raw ) ) : '';
	}

	/**
	 * A multi-line POST field, sanitized (NFR-021).
	 *
	 * `sanitize_textarea_field` rather than `sanitize_text_field`: a manual knowledge answer
	 * is prose with paragraphs, and collapsing its newlines would run the merchant's list of
	 * shipping zones into one sentence before it was ever chunked.
	 *
	 * This is *not* the injection defence. Content pushed here is sanitized index-time by the
	 * backend so retrieved chunks are data and not instructions (design D14) — the same
	 * treatment a product description gets, and for the same reason. This is input hygiene.
	 */
	private function posted_text( string $key ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by the caller's guard.
		$raw = $_POST[ $key ] ?? '';
		return is_string( $raw ) ? sanitize_textarea_field( wp_unslash( $raw ) ) : '';
	}

	/** An integer POST field, or 0 when absent or non-numeric. */
	private function posted_int( string $key ): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified by the caller's guard.
		$raw = $_POST[ $key ] ?? 0;
		return is_numeric( $raw ) ? (int) $raw : 0;
	}

	/**
	 * The response body on success, or null on any non-2xx / unusable envelope.
	 *
	 * @param array{status: int, body: mixed} $result
	 * @return array<string, mixed>|null
	 */
	private function unwrap( array $result ): ?array {
		if ( $result['status'] < 200 || $result['status'] >= 300 ) {
			return null;
		}
		return is_array( $result['body'] ) ? $result['body'] : null;
	}

	/**
	 * The merchant-facing failure payload for a backend read that did not answer.
	 *
	 * The distinction the panel must not get wrong is 401 versus everything else: a 401 is
	 * the backend telling us this store's token is dead, which needs re-activation, while a
	 * timeout is a connectivity question whose verdict belongs to the status surface (D15,
	 * §4.2). This reports which of the two it is and leaves the *outage class* to the
	 * Health Check page, so the two surfaces cannot publish contradicting diagnoses.
	 *
	 * The 401 arm has one side effect, and it is the point: it tells the gate what this
	 * read just learnt. Naming a fact in a banner and not recording it left the plugin
	 * disagreeing with itself — the pill above the banner still said **Live**, the widget
	 * stayed enqueued against a rejected token, and the wizard on the far end of the
	 * "Reconnect" link still believed the store was connected, which is what made that link
	 * a dead end. `record_unauthorized()` is idempotent, so repeating it on every failing
	 * read costs one option write and converges.
	 *
	 * @param array{status: int, body: mixed} $result
	 * @return array<string, mixed>
	 */
	private function transport_error( array $result ): array {
		if ( 401 === $result['status'] ) {
			$this->gate->record_unauthorized( 'merchant_read_401' );

			return array(
				'reason'      => 'unauthorized',
				'message'     => __( 'This store is no longer authorised with the AI service. Re-enter your license key to reconnect.', 'woocommerce-ai-chat' ),
				// The reconnect flag, not the bare page: without it the wizard renders
				// whichever state it infers, and "connected" is one of the answers.
				'action'      => admin_url(
					'admin.php?page=' . OnboardingWizard::PAGE_SLUG . '&' . OnboardingWizard::QUERY_RECONNECT . '=1'
				),
				'actionLabel' => __( 'Reconnect this store', 'woocommerce-ai-chat' ),
			);
		}

		return array(
			'reason'      => 'unreachable',
			'message'     => __( 'Could not reach the AI service. Open Health Check to see whether this is your site or the platform.', 'woocommerce-ai-chat' ),
			'action'      => admin_url( 'admin.php?page=' . self::HEALTH_CHECK_SLUG ),
			'actionLabel' => __( 'Open Health Check', 'woocommerce-ai-chat' ),
		);
	}
}
