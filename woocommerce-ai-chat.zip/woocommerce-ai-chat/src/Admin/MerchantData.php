<?php
/**
 * The panel's backend reads (`add-merchant-insight-ops §1.3`).
 *
 * A thin wrapper over the `/v1/merchant/*` calls that exists for one reason: it is the only
 * place in the admin panel that touches the decrypted **store token**, and it never emits
 * anything to the browser.
 *
 * `StoreTokenLeakAuditTest` enforces NFR-019 as a file-level rule — no source file may
 * contain both `wp_localize_script` and a store-token accessor — and that rule is
 * deliberately blunt: it does not try to follow whether a particular file's token happens to
 * reach its localized array, because a guard that reasons about data flow is a guard that can
 * be argued with. `Panel` localizes (it has a nonce and an AJAX URL to hand the browser), so
 * `Panel` must not be able to read a token. This class is that boundary made structural.
 *
 * Everything it returns is already the backend's public-facing response body; the token is
 * consumed as an `Authorization` header inside `BackendClient` and never leaves this file.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

use WooAIChat\Auth\BackendApi;
use WooAIChat\Auth\BackendClient;
use WooAIChat\Auth\TokenStore;

/**
 * Reads the merchant surfaces on the panel's behalf.
 */
final class MerchantData {

	private TokenStore $tokens;
	private BackendApi $backend;

	public function __construct( TokenStore $tokens, ?BackendApi $backend = null ) {
		$this->tokens  = $tokens;
		$this->backend = $backend ?? new BackendClient();
	}

	/**
	 * `GET /v1/merchant/overview` (§1.2, §2.1).
	 *
	 * @return array{status: int, body: mixed}
	 */
	public function overview(): array {
		return $this->backend->merchant_overview( $this->tokens->get_store_token() );
	}

	/**
	 * `GET /v1/merchant/analytics` (§2.2–2.4).
	 *
	 * @param int $window_days The rolling window the rates are computed over.
	 * @return array{status: int, body: mixed}
	 */
	public function analytics( int $window_days = 30 ): array {
		return $this->backend->merchant_analytics( $this->tokens->get_store_token(), $window_days );
	}

	/**
	 * `GET /v1/merchant/knowledge` (`add-content-ingestion-kb §5.1–5.2`).
	 *
	 * @param int $limit  Page size.
	 * @param int $offset Row offset into the store's inventory.
	 * @return array{status: int, body: mixed}
	 */
	public function knowledge( int $limit = 50, int $offset = 0 ): array {
		return $this->backend->merchant_knowledge( $this->tokens->get_store_token(), $limit, $offset );
	}

	/**
	 * `GET /v1/merchant/health` (`add-merchant-insight-ops §4.1`).
	 *
	 * @return array{status: int, body: mixed}
	 */
	public function health(): array {
		return $this->backend->merchant_health( $this->tokens->get_store_token() );
	}

	/**
	 * `POST /v1/index/push` for one merchant-authored entry (§5.4, FR-035).
	 *
	 * The one *write* on this class, and it is here for the same NFR-019 reason as the
	 * reads: it needs the store token, and `Panel` — which localizes a nonce to the browser
	 * — must remain unable to name a token accessor. Only the envelope crosses back.
	 *
	 * @param array<string, mixed> $item A `PushItem`-shaped manual entry.
	 * @return array{status: int, body: mixed}
	 */
	public function push_manual_entry( array $item ): array {
		return $this->backend->push_index_items( $this->tokens->get_store_token(), array( $item ) );
	}

	/**
	 * `POST /v1/merchant/knowledge/override` — the go-live-below-threshold decision
	 * (§5.2, D9/FR-014).
	 *
	 * Here for the same NFR-019 reason as everything else on this class: it needs the store
	 * token, and `Panel` localizes a nonce to the browser and must therefore stay unable to
	 * name a token accessor. Only the response envelope crosses back.
	 *
	 * @return array{status: int, body: mixed}
	 */
	public function override_quality_gate(): array {
		return $this->backend->override_quality_gate( $this->tokens->get_store_token() );
	}

	/**
	 * Whether this store has ever completed activation (ES-007).
	 *
	 * Lives here rather than on `Panel` for the same NFR-019 reason as the reads: answering
	 * it requires looking at the store token. Only the boolean crosses back.
	 */
	public function has_activation_material(): bool {
		return '' !== $this->tokens->get_store_token() && '' !== $this->tokens->get_widget_token();
	}
}
