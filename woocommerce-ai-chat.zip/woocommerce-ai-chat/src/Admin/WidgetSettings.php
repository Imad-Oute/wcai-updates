<?php
/**
 * The merchant's widget configuration (`add-merchant-insight-ops §3.2–3.3`, FR-012).
 *
 * One `wp_options` row holding everything the Settings page writes: appearance (position,
 * primary colour, title, placeholder), behaviour (enabled, trigger delay, scroll depth,
 * fallback URL), the locale override, and the two compliance toggles (RC-006 age/content
 * disclaimer, RC-009 child-audience retention). The storefront widget reads it back through
 * `widget_config()` as the `waiConfig` payload TR-022 describes.
 *
 * ## Why the sanitizer, not the form, is the contract
 *
 * `sanitize()` takes an arbitrary array and returns a valid settings array — every value
 * clamped, every enum checked against its own whitelist, every unknown key dropped. The
 * Settings form is one caller; WP-CLI, a migration, or a future REST write would be others,
 * and each of them would otherwise need its own copy of "a trigger delay is 0–120 seconds".
 * Nothing here trusts that a `<select>` only submits the four options it renders.
 *
 * A field that fails validation falls back to its **default**, not to the previously stored
 * value. A merchant who types `-5` into the delay gets 0 and sees it, which is a state they
 * can then correct; silently keeping the old value would show them a form that disagrees
 * with what they just submitted.
 *
 * ## AX-002 — the accent is contrast-checked, not merely stored
 *
 * The primary colour is auto-detected from the active theme (US-007), and a theme's accent
 * is chosen for a page background, not for white text on a 56px button. `accent()` therefore
 * returns the *used* colour: the merchant's choice darkened in 15% steps until white text on
 * it clears WCAG AA's 4.5:1, and the Settings page tells them it happened. This is a
 * functional safeguard, not styling — NFR-045 makes WCAG 2.1 AA a legal obligation in the
 * EU, and auto-detection that can yield an inaccessible widget would breach it without
 * anybody choosing to.
 *
 * The merchant's raw choice is what is *stored*; the darkening is applied on read. So a
 * merchant who later switches to a light widget background is not left with a colour we
 * silently rewrote, and the swatch in the form always shows what they actually picked.
 *
 * ## What is deliberately absent
 *
 * No AI provider, model, key, or vector-backend field — anywhere, at any layer (design D1,
 * §3.4). The store is a thin client; every AI call belongs to the backend, and a field here
 * would be the first step to a store holding an API key it must then protect.
 * `NoAiFieldAuditTest` enforces that as a source-level rule rather than a convention.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

/**
 * Reads, sanitizes, and persists the widget configuration.
 */
final class WidgetSettings {

	/** Widget corner placements (WUX-002 defaults to bottom-right). */
	public const POSITIONS = array( 'bottom-right', 'bottom-left' );

	/** The longest a merchant may defer the widget's entrance, in seconds. */
	public const MAX_TRIGGER_DELAY = 120;

	/** WCAG AA's contrast floor for normal text (AX-002). */
	public const CONTRAST_FLOOR = 4.5;

	/** How far one auto-darken step moves the accent (AX-002's "15%"). */
	private const DARKEN_STEP = 0.15;

	/**
	 * A ceiling on the darkening loop. Six 15% steps take any colour below 40% of its
	 * original luminance, which clears 4.5:1 against white for every hue; the bound exists
	 * so a pathological input cannot spin, not because step seven would be useful.
	 */
	private const DARKEN_MAX_STEPS = 6;

	/**
	 * The fallback accent when the theme exposes none — WordPress admin blue, which is
	 * already AA against white and is the colour a merchant who has never opened Settings
	 * has implicitly been shown everywhere else in `/wp-admin`.
	 */
	public const FALLBACK_ACCENT = '#2271b1';

	/**
	 * The stored shape, with every default.
	 *
	 * `primary_color` is empty rather than pre-filled: an empty value means "follow the
	 * theme", so a merchant who re-themes their store gets the new accent without having to
	 * remember that Settings pinned the old one. `accent()` resolves it at read time.
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults(): array {
		return array(
			// -- appearance (§3.2) ------------------------------------------------
			'position'        => 'bottom-right',
			'primary_color'   => '',
			'title'           => '',
			'placeholder'     => '',

			// -- behaviour (§3.3) -------------------------------------------------
			'enabled'         => true,
			'trigger_delay'   => 0,
			'trigger_scroll'  => 0,
			'fallback_url'    => '',
			'locale'          => '',

			// -- compliance (§3.3, RC-006/RC-009) ---------------------------------
			'disclaimer_on'   => false,
			'disclaimer_text' => '',
			'child_audience'  => false,
		);
	}

	/**
	 * The stored settings, merged over the defaults.
	 *
	 * Merged rather than returned raw so a row written by an older version — one field
	 * short — reads as a complete array here instead of producing an undefined-index notice
	 * at every call site.
	 *
	 * @return array<string, mixed>
	 */
	public function all(): array {
		$stored = get_option( WAI_OPTION_WIDGET_SETTINGS, array() );

		if ( ! is_array( $stored ) ) {
			return self::defaults();
		}

		return array_merge( self::defaults(), array_intersect_key( $stored, self::defaults() ) );
	}

	/** One setting, or its default when the row has never been written. */
	public function get( string $key ) {
		$all = $this->all();
		return $all[ $key ] ?? null;
	}

	/**
	 * Persist a submitted settings array after sanitizing it.
	 *
	 * Returns the sanitized array so the caller can re-render the form from what was
	 * actually stored rather than from what was submitted — the two differ exactly when a
	 * value was clamped, and that is the case where showing the submitted value would lie.
	 *
	 * @param array<string, mixed> $input Raw submitted values.
	 * @return array<string, mixed> The stored settings.
	 */
	public function save( array $input ): array {
		$clean = self::sanitize( $input );
		update_option( WAI_OPTION_WIDGET_SETTINGS, $clean );
		return $clean;
	}

	/**
	 * Coerce an arbitrary array into a valid settings array (NFR-021).
	 *
	 * Static and free of WordPress state beyond the sanitizing helpers, so the clamping
	 * rules are directly testable without a form or an options table (§6.1).
	 *
	 * @param array<string, mixed> $input
	 * @return array<string, mixed>
	 */
	public static function sanitize( array $input ): array {
		$defaults = self::defaults();

		$position = is_string( $input['position'] ?? null ) ? (string) $input['position'] : '';
		$locale   = is_string( $input['locale'] ?? null ) ? (string) $input['locale'] : '';

		$disclaimer_text = is_string( $input['disclaimer_text'] ?? null )
			? sanitize_text_field( (string) $input['disclaimer_text'] )
			: '';

		return array(
			'position'        => in_array( $position, self::POSITIONS, true ) ? $position : $defaults['position'],
			'primary_color'   => self::sanitize_color( $input['primary_color'] ?? '' ),
			'title'           => is_string( $input['title'] ?? null ) ? sanitize_text_field( (string) $input['title'] ) : '',
			'placeholder'     => is_string( $input['placeholder'] ?? null ) ? sanitize_text_field( (string) $input['placeholder'] ) : '',

			'enabled'         => ! empty( $input['enabled'] ),
			'trigger_delay'   => self::clamp_int( $input['trigger_delay'] ?? 0, 0, self::MAX_TRIGGER_DELAY ),
			// A scroll-depth trigger is a percentage of the page, so 100 is its own ceiling;
			// 0 means "do not wait for a scroll", which is the default and not a disabled
			// state to encode separately.
			'trigger_scroll'  => self::clamp_int( $input['trigger_scroll'] ?? 0, 0, 100 ),
			'fallback_url'    => self::sanitize_url( $input['fallback_url'] ?? '' ),
			// `sanitize_locale_name` rejects anything outside `[A-Za-z0-9_]`, which is what
			// stops a submitted locale from reaching `switch_to_locale()` as a path.
			'locale'          => '' === $locale ? '' : sanitize_locale_name( $locale ),

			// RC-006 — the disclaimer is only *on* when there is something to show. A
			// checked box with an empty textarea would append an empty notice to every
			// reply, which is worse than the toggle quietly not applying.
			'disclaimer_on'   => ! empty( $input['disclaimer_on'] ) && '' !== $disclaimer_text,
			'disclaimer_text' => $disclaimer_text,
			'child_audience'  => ! empty( $input['child_audience'] ),
		);
	}

	// -- appearance resolution --------------------------------------------------


	/**
	 * The colour the widget actually renders with (US-007, AX-002).
	 *
	 * Three steps, in order: the merchant's explicit choice, else the theme's accent, else
	 * admin blue — then the AA darkening. The merchant's choice is darkened too: AX-002 is a
	 * property of the rendered widget, and a hand-picked pale yellow fails the same 4.5:1 an
	 * auto-detected one does.
	 *
	 * @return array{color: string, source: string, adjusted: bool, original: string}
	 */
	public function accent(): array {
		$chosen = (string) $this->get( 'primary_color' );

		if ( '' !== $chosen ) {
			$source   = 'merchant';
			$original = $chosen;
		} else {
			$detected = self::detect_theme_accent();
			$source   = '' === $detected ? 'fallback' : 'theme';
			$original = '' === $detected ? self::FALLBACK_ACCENT : $detected;
		}

		$used = self::ensure_contrast( $original );

		return array(
			'color'    => $used,
			'source'   => $source,
			'adjusted' => strtolower( $used ) !== strtolower( $original ),
			'original' => $original,
		);
	}

	/**
	 * The active theme's accent colour, or `''` when it exposes none.
	 *
	 * Block themes carry it in `theme.json`'s palette, which `wp_get_global_settings()`
	 * reads; classic themes carry it as a theme mod under one of a handful of conventional
	 * names. Neither is guaranteed, and a theme that names its palette entries something
	 * else is not a failure — it is the case `FALLBACK_ACCENT` exists for.
	 *
	 * The palette lookup takes the first entry whose slug names a primary/accent role
	 * rather than the palette's first colour, which in most themes is a background.
	 */
	public static function detect_theme_accent(): string {
		if ( function_exists( 'wp_get_global_settings' ) ) {
			$settings = wp_get_global_settings( array( 'color', 'palette' ) );
			$palette  = array();

			// Theme-supplied entries outrank core's default palette: core's slugs are
			// generic (`vivid-cyan-blue`) and would match ahead of the theme's own accent.
			foreach ( array( 'theme', 'custom', 'default' ) as $origin ) {
				if ( isset( $settings[ $origin ] ) && is_array( $settings[ $origin ] ) ) {
					$palette = array_merge( $palette, $settings[ $origin ] );
				}
			}

			foreach ( $palette as $entry ) {
				if ( ! is_array( $entry ) || ! isset( $entry['slug'], $entry['color'] ) ) {
					continue;
				}
				if ( ! preg_match( '/^(primary|accent|brand)/', (string) $entry['slug'] ) ) {
					continue;
				}
				$color = self::sanitize_color( (string) $entry['color'] );
				if ( '' !== $color ) {
					return $color;
				}
			}
		}

		foreach ( array( 'accent_color', 'primary_color', 'link_color' ) as $mod ) {
			$color = self::sanitize_color( (string) get_theme_mod( $mod, '' ) );
			if ( '' !== $color ) {
				return $color;
			}
		}

		return '';
	}

	/**
	 * Darken a colour in 15% steps until white text on it clears WCAG AA (AX-002).
	 *
	 * Returns the input unchanged when it already passes — the common case, and the one
	 * where touching the merchant's colour would be the bug.
	 */
	public static function ensure_contrast( string $hex ): string {
		$color = self::sanitize_color( $hex );
		if ( '' === $color ) {
			return self::FALLBACK_ACCENT;
		}

		for ( $step = 0; $step < self::DARKEN_MAX_STEPS; $step++ ) {
			if ( self::contrast_with_white( $color ) >= self::CONTRAST_FLOOR ) {
				return $color;
			}
			$color = self::darken( $color, self::DARKEN_STEP );
		}

		return $color;
	}

	/**
	 * The WCAG 2.1 contrast ratio between a colour and white.
	 *
	 * White, not the page background, because the widget's accent is the fill *behind* its
	 * own white label (WUX-008's `--aica-text-on-primary`) — that pairing is what AX-002's
	 * 4.5:1 is about, and it is the one the plugin controls both halves of.
	 */
	public static function contrast_with_white( string $hex ): float {
		$luminance = self::relative_luminance( $hex );
		// WCAG's formula, with white's luminance (1.0) as the lighter term.
		return ( 1.0 + 0.05 ) / ( $luminance + 0.05 );
	}

	/**
	 * WCAG 2.1's relative luminance for an `#rrggbb` colour.
	 *
	 * The sRGB gamma expansion is not decorative: the naive average-of-channels version
	 * passes colours that are visibly illegible, which would make the AX-002 guard worse
	 * than useless — it would certify the widget as accessible while it is not.
	 */
	public static function relative_luminance( string $hex ): float {
		[ $r, $g, $b ] = self::to_rgb( $hex );

		$channel = static function ( int $value ): float {
			$srgb = $value / 255;
			return $srgb <= 0.03928
				? $srgb / 12.92
				: pow( ( $srgb + 0.055 ) / 1.055, 2.4 );
		};

		return 0.2126 * $channel( $r ) + 0.7152 * $channel( $g ) + 0.0722 * $channel( $b );
	}

	/** Scale every channel toward black by `$amount` (0–1). */
	private static function darken( string $hex, float $amount ): string {
		[ $r, $g, $b ] = self::to_rgb( $hex );
		$factor        = 1.0 - $amount;

		return sprintf(
			'#%02x%02x%02x',
			(int) max( 0, floor( $r * $factor ) ),
			(int) max( 0, floor( $g * $factor ) ),
			(int) max( 0, floor( $b * $factor ) )
		);
	}

	/**
	 * `#rrggbb` (or `#rgb`) to three 0–255 channels.
	 *
	 * @return array{0: int, 1: int, 2: int}
	 */
	private static function to_rgb( string $hex ): array {
		$hex = ltrim( trim( $hex ), '#' );

		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}

		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			// Only reachable when a caller skips `sanitize_color()`; black is the safe
			// answer because it passes contrast rather than silently failing it.
			return array( 0, 0, 0 );
		}

		return array(
			(int) hexdec( substr( $hex, 0, 2 ) ),
			(int) hexdec( substr( $hex, 2, 2 ) ),
			(int) hexdec( substr( $hex, 4, 2 ) ),
		);
	}

	// -- field sanitizers -------------------------------------------------------


	/**
	 * A `#rrggbb` colour, or `''` for anything else.
	 *
	 * `sanitize_hex_color` is WordPress's own and accepts the 3- and 6-digit forms; the
	 * expansion to 6 digits afterwards is so the stored value, the `<input type="color">`
	 * (which only accepts 6), and the contrast maths all see one format.
	 */
	public static function sanitize_color( $value ): string {
		if ( ! is_string( $value ) || '' === trim( $value ) ) {
			return '';
		}

		$color = sanitize_hex_color( trim( $value ) );
		if ( ! is_string( $color ) || '' === $color ) {
			return '';
		}

		$digits = ltrim( $color, '#' );
		if ( 3 === strlen( $digits ) ) {
			$color = '#' . $digits[0] . $digits[0] . $digits[1] . $digits[1] . $digits[2] . $digits[2];
		}

		return strtolower( $color );
	}

	/**
	 * The deflection fallback URL, restricted to http(s).
	 *
	 * `esc_url_raw` with an explicit protocol whitelist: the value is rendered into the
	 * storefront widget as a link the shopper clicks, so allowing `javascript:` here would
	 * turn a merchant settings field into stored XSS on every product page.
	 */
	public static function sanitize_url( $value ): string {
		if ( ! is_string( $value ) || '' === trim( $value ) ) {
			return '';
		}

		return (string) esc_url_raw( trim( $value ), array( 'http', 'https' ) );
	}

	/** An integer clamped into an inclusive range; non-numeric input reads as `$min`. */
	private static function clamp_int( $value, int $min, int $max ): int {
		if ( ! is_numeric( $value ) ) {
			return $min;
		}
		return (int) min( $max, max( $min, (int) $value ) );
	}

	// -- storefront handoff -----------------------------------------------------


	/**
	 * The `waiConfig` payload the storefront widget is localized with (TR-022).
	 *
	 * Built here rather than in the widget module so the resolution rules — which accent
	 * wins, whether the disclaimer applies — have exactly one implementation, and so the
	 * enqueue side cannot accidentally ship the merchant's raw pre-darkening colour.
	 *
	 * The **store token is not in it**, and cannot be: this class never reads one. Only the
	 * public widget token belongs in a page the shopper can view source on (NFR-019).
	 *
	 * @return array<string, mixed>
	 */
	public function widget_config(): array {
		$settings = $this->all();
		$accent   = $this->accent();

		return array(
			'enabled'       => (bool) $settings['enabled'],
			'position'      => (string) $settings['position'],
			'accentColor'   => $accent['color'],
			'title'         => (string) $settings['title'],
			'placeholder'   => (string) $settings['placeholder'],
			'triggerDelay'  => (int) $settings['trigger_delay'],
			'triggerScroll' => (int) $settings['trigger_scroll'],
			'fallbackUrl'   => (string) $settings['fallback_url'],
			'locale'        => (string) $settings['locale'],
			'disclaimer'    => $settings['disclaimer_on'] ? (string) $settings['disclaimer_text'] : '',
			// RC-009. Sent to the backend with each turn rather than only honoured
			// client-side: the retention decision is made where the log is written, and a
			// flag the browser could drop would be a compliance control that fails open.
			'childAudience' => (bool) $settings['child_audience'],
		);
	}
}
