<?php
/**
 * The Overview page (`add-merchant-insight-ops §2.1`, FR-015, DUX-003).
 *
 * Four metric cards — Conversations (30d), Answer Rate, Top Unanswered, Quality Score —
 * plus a usage bar for each of the two metered dimensions (chat replies, memory items).
 *
 * The class is split the way every page in the panel is: `render()` emits the *shell* with
 * no network call (NFR-005), and `payload()` shapes the backend's response for the script
 * that fills it. Keeping the shaping in PHP rather than in the browser is what lets the
 * numbers be formatted with WordPress's own locale helpers (`number_format_i18n`) and the
 * labels translated (FR-090) — a percentage rendered in JS would be `12.5%` in every
 * locale, including the ones that write it `12,5 %`.
 *
 * ## Two cards read from a different endpoint than the other two
 *
 * Conversations and Answer Rate live on `/v1/merchant/analytics`; Quality Score and the
 * usage bars live on `/v1/merchant/overview`. The page loads the overview first because it
 * also carries the status pill's authoritative state, and fills the analytics cards on the
 * second response — so a slow analytics query never delays the pill. The cards it is
 * waiting on show their skeleton, not a zero, because a zero that later becomes 400 is
 * worse than an obvious placeholder.
 *
 * ## ES-001 and ES-002
 *
 * A store with nothing indexed shows a single progress card and no metrics at all
 * (ES-001): metric cards over an empty index are all zeros, which reads as "the product is
 * broken" rather than "indexing has not finished". A store that *is* indexed but has had no
 * conversations shows the cards with an em-dash and helper text (ES-002) — the distinction
 * matters because the second one is working correctly and the first one is not done yet.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Admin;

/**
 * Renders the Overview shell and shapes `/v1/merchant/overview` for it.
 */
final class OverviewPage {

	/**
	 * The Overview body: metric cards and usage bars as empty skeletons.
	 *
	 * Every value node carries a `data-wcai-field` name that `payload()` produces a key
	 * for, so the contract between this markup and the script is one table read from both
	 * sides rather than a set of ids to keep in sync by hand.
	 */
	public function render(): void {
		echo '<div class="wcai-overview" data-wcai-page="overview">';

		// The loading state (§1.3). Removed by the script on first response; visible to a
		// merchant only while the backend read is in flight, which is the whole point —
		// the page has already rendered underneath it.
		// The loading line only. The metric cards below carry their own skeleton state
		// (`.is-loading`, dropped by the script on first response) rather than a second set
		// of placeholder cards stacked above them — two card grids in the DOM meant the
		// real ones sat empty underneath the placeholders, and any failure to unhide them
		// left the page showing skeletons over a duplicate.
		echo '<p class="wcai-loading wcai-loading-text" data-wcai-loading="1" role="status">'
			. esc_html__( 'Loading your dashboard…', 'woocommerce-ai-chat' ) . '</p>';

		// ES-001 — shown instead of the cards until the backend reports indexed content.
		echo '<div class="wcai-empty" data-wcai-empty="indexing" hidden>';
		echo '<h2>' . esc_html__( 'Setting up your assistant', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<p>' . esc_html__( 'We are indexing your store content. Your dashboard fills in as soon as the first pass finishes — you do not need to keep this page open.', 'woocommerce-ai-chat' ) . '</p>';
		echo '</div>';

		echo '<div class="wcai-cards is-loading" data-wcai-cards>';
		$this->render_card( 'conversations', __( 'Conversations (30 days)', 'woocommerce-ai-chat' ) );
		$this->render_card( 'answerRate', __( 'Answer rate', 'woocommerce-ai-chat' ) );
		// `is_quote`: this card's value is a shopper's question (per the design spec's
		// “Do you ship to Canada?”), not a number, and needs type sized for a sentence.
		$this->render_card( 'topUnanswered', __( 'Top unanswered', 'woocommerce-ai-chat' ), 'wcai-unanswered', true );
		$this->render_card( 'qualityScore', __( 'Content quality', 'woocommerce-ai-chat' ) );
		echo '</div>';

		// ES-002 — indexed and live, but nobody has asked anything yet.
		echo '<p class="wcai-hint" data-wcai-empty="conversations" hidden>';
		echo esc_html__( 'No conversations yet. Metrics appear here once shoppers start using the assistant.', 'woocommerce-ai-chat' );
		echo '</p>';

		// The heading is inside the hidden container, not above it. Left outside, it stayed
		// visible while its own content was still `hidden` — so the page showed a section
		// title over empty space until the AJAX response landed, and kept showing it
		// forever on a store whose usage read failed.
		echo '<section class="wcai-usage-section" data-wcai-usage hidden>';
		echo '<h2 class="wcai-section-title">' . esc_html__( 'This billing period', 'woocommerce-ai-chat' ) . '</h2>';
		echo '<div class="wcai-card wcai-usage-bars">';
		$this->render_usage_bar( 'replies', __( 'Chat replies', 'woocommerce-ai-chat' ) );
		$this->render_usage_bar( 'memoryItems', __( 'Memory items', 'woocommerce-ai-chat' ) );
		echo '<p class="wcai-period" data-wcai-field="period"></p>';
		echo '</div>';
		echo '</section>';
		echo '</div>';
	}

	/**
	 * One metric card.
	 *
	 * @param string  $field The `payload()` key that fills it.
	 * @param string  $label The translated card heading.
	 * @param ?string $link_page Panel page slug the card's value links to, when it has one.
	 * @param bool    $is_quote Whether the value is a sentence rather than a figure, and so
	 *                          needs body type instead of the 32px display size.
	 */
	private function render_card( string $field, string $label, ?string $link_page = null, bool $is_quote = false ): void {
		printf(
			'<div class="wcai-card"><h3>%1$s</h3><p class="wcai-card-value%4$s" data-wcai-field="%2$s">%3$s</p>',
			esc_html( $label ),
			esc_attr( $field ),
			// The em-dash, not "0": before the first response we do not know the value,
			// and a zero would be a claim (ES-002 also lands here for a live-but-quiet
			// store, where the em-dash is the correct final state too).
			esc_html( '—' ),
			$is_quote ? ' is-quote' : ''
		);
		if ( null !== $link_page ) {
			printf(
				'<p class="wcai-card-link"><a href="%1$s">%2$s</a></p>',
				esc_url( admin_url( 'admin.php?page=' . $link_page ) ),
				esc_html__( 'See all unanswered questions', 'woocommerce-ai-chat' )
			);
		}
		echo '</div>';
	}

	/**
	 * One usage bar (DUX-003).
	 *
	 * `<progress>` rather than a styled div: it is the element that means this, it is
	 * announced correctly by screen readers without ARIA, and the visible text beside it
	 * carries the same numbers for anyone who cannot infer them from a bar's width.
	 *
	 * @param string $field The `payload()['usage']` key that fills it.
	 * @param string $label The translated dimension name.
	 */
	private function render_usage_bar( string $field, string $label ): void {
		printf(
			'<div class="wcai-usage" data-wcai-usage-row="%1$s">' .
				'<span class="wcai-usage-label">%2$s</span>' .
				'<progress class="wcai-usage-meter" data-wcai-field="%1$sMeter" max="100" value="0"></progress>' .
				'<span class="wcai-usage-text" data-wcai-field="%1$sText"></span>' .
			'</div>',
			esc_attr( $field ),
			esc_html( $label )
		);
	}

	/**
	 * Shape `/v1/merchant/overview` into the fields `render()`'s markup names.
	 *
	 * Pure: no WordPress state beyond the formatting helpers, so it is directly testable
	 * against a contract-shaped array (§6.1).
	 *
	 * @param array<string, mixed> $body A `MerchantOverviewResponse`.
	 * @return array<string, mixed>
	 */
	public function payload( array $body ): array {
		$usage        = is_array( $body['usage'] ?? null ) ? $body['usage'] : array();
		$subscription = is_array( $body['subscription'] ?? null ) ? $body['subscription'] : array();
		$quotas       = is_array( $subscription['quotas'] ?? null ) ? $subscription['quotas'] : array();

		$indexed = isset( $body['indexed_items'] ) ? (int) $body['indexed_items'] : 0;
		$state   = is_string( $body['state'] ?? null ) ? (string) $body['state'] : '';

		return array(
			// ES-001 is a *state* question, not a count question: a store can have items
			// indexed and still be mid-pass. `indexing` is the backend's own word for it
			// (FR-017), and an empty index is the other way in.
			'isIndexing'   => 'indexing' === $state || 0 === $indexed,
			'indexedItems' => $indexed,
			'qualityScore' => isset( $body['quality_score'] ) ? (int) $body['quality_score'] : 0,
			'usage'        => array(
				'replies'     => $this->usage_row(
					isset( $usage['replies_used'] ) ? (int) $usage['replies_used'] : 0,
					isset( $quotas['replies_quota'] ) ? (int) $quotas['replies_quota'] : 0
				),
				'memoryItems' => $this->usage_row(
					isset( $usage['memory_items_used'] ) ? (int) $usage['memory_items_used'] : 0,
					isset( $quotas['memory_items_quota'] ) ? (int) $quotas['memory_items_quota'] : 0
				),
			),
			'period'       => $this->period_label( $usage ),
			'staleness'    => $this->staleness( is_array( $body['staleness'] ?? null ) ? $body['staleness'] : array() ),
		);
	}

	/**
	 * One usage dimension: the raw numbers, the percentage the bar fills to, and the
	 * pre-formatted "1,234 of 5,000" the merchant reads.
	 *
	 * An unlimited (0 or absent) quota is not a divide-by-zero to guard against — it is a
	 * real plan shape, and it renders as a count with no bar rather than as 0% or 100%,
	 * either of which would be a lie about a plan that has no ceiling.
	 *
	 * @return array{used: int, quota: int, percent: int, unlimited: bool, text: string}
	 */
	private function usage_row( int $used, int $quota ): array {
		$unlimited = $quota <= 0;
		$percent   = $unlimited ? 0 : (int) min( 100, floor( ( $used / $quota ) * 100 ) );

		$text = $unlimited
			? sprintf(
				/* translators: %s: number of units used this period. */
				__( '%s used', 'woocommerce-ai-chat' ),
				number_format_i18n( $used )
			)
			: sprintf(
				/* translators: 1: units used, 2: plan allowance, 3: percentage of the allowance used. */
				__( '%1$s of %2$s (%3$s%%)', 'woocommerce-ai-chat' ),
				number_format_i18n( $used ),
				number_format_i18n( $quota ),
				number_format_i18n( $percent )
			);

		return array(
			'used'      => $used,
			'quota'     => $quota,
			'percent'   => $percent,
			'unlimited' => $unlimited,
			'text'      => $text,
		);
	}

	/**
	 * "Resets on 14 August" — the billing period the usage bars are measured over.
	 *
	 * Formatted with the site's own date format so it matches the rest of `/wp-admin`
	 * rather than showing the contract's ISO-8601.
	 *
	 * @param array<string, mixed> $usage The response's `usage` block.
	 */
	private function period_label( array $usage ): string {
		$end = is_string( $usage['period_end'] ?? null ) ? strtotime( (string) $usage['period_end'] ) : false;
		if ( false === $end ) {
			return '';
		}

		return sprintf(
			/* translators: %s: the date the current billing period ends. */
			__( 'Usage resets on %s.', 'woocommerce-ai-chat' ),
			date_i18n( (string) get_option( 'date_format' ), $end )
		);
	}

	/**
	 * The freshness line, rendered from the backend's verdict rather than recomputed.
	 *
	 * D12 makes staleness backend-authoritative: `is_stale` is the backend's call, and the
	 * plugin's job is to say it in plain language. Deriving "stale" here from
	 * `hours_since_push` would put the threshold in two places, and they would drift the
	 * first time the backend tuned it.
	 *
	 * @param array<string, mixed> $staleness The response's `staleness` block.
	 * @return array{isStale: bool, text: string}
	 */
	private function staleness( array $staleness ): array {
		$is_stale = ! empty( $staleness['is_stale'] );
		$hours    = isset( $staleness['hours_since_push'] ) ? (float) $staleness['hours_since_push'] : null;

		if ( null === ( $staleness['last_push_received'] ?? null ) || null === $hours ) {
			return array(
				'isStale' => $is_stale,
				'text'    => __( 'No store content has been sent yet.', 'woocommerce-ai-chat' ),
			);
		}

		$text = $is_stale
			? sprintf(
				/* translators: %s: whole hours since the last successful content sync. */
				__( 'Your content was last synced %s hours ago. Open Health Check to see why syncing stopped.', 'woocommerce-ai-chat' ),
				number_format_i18n( (int) round( (float) $hours ) )
			)
			: __( 'Your content is up to date.', 'woocommerce-ai-chat' );

		return array(
			'isStale' => $is_stale,
			'text'    => $text,
		);
	}
}
