<?php
/**
 * `\WooAIChat\Api` namespace marker (`add-foundation-onboarding §1.2`).
 *
 * The sub-namespaces the spec calls for (TR-001–004) — `Api`, `Sync`, `Auth`, `REST`,
 * `Admin`, `Widget` — are autoloaded through one Composer PSR-4 root and materialise
 * the moment a class is placed at the right path under `src/`. `Sync`, `Auth`, and
 * `Admin` ship their first classes in this change; the remaining three (`Api`, `REST`,
 * `Widget`) ship their first classes with the epic changes that own them:
 *
 *   - `Api\*` — backend-client wiring beyond `/v1/auth/*`, owned by content
 *     ingestion (`/v1/index/*`) and shopper chat (`/v1/chat`); the auth + index
 *     HTTP surface lives under `Auth\` per the §3 layout.
 *   - `REST\*` — REST routes the merchant panel exposes to `/wp-admin`'s React app,
 *     owned by merchant-insight-ops.
 *   - `Widget\*` — the storefront widget enqueue + localize, owned by shopper-chat.
 *
 * The placeholder classes here keep the directory tree aligned with the autoload PSR-4
 * table without imposing a class API the owning epic would have to redesign. Empty
 * classes that exist only to populate namespaces are a code smell; the alternative
 * (empty `__init__.php` files under non-existent PSR-4 roots) is worse — there is no
 * PSR-4 file at all for an empty namespace, so a sniff auditing "the spec named six
 * sub-namespaces; verify they exist" needs something to find.
 *
 * @package WooAIChat
 */

declare(strict_types=1);

namespace WooAIChat\Api;

/**
 * Stub marking the `WooAIChat\Api` sub-namespace. Replaced by the epic change that
 * owns this namespace's first real class (content ingestion for `/v1/index/*`,
 * shopper chat for the remaining paths).
 */
final class NamespaceMarker {
}
