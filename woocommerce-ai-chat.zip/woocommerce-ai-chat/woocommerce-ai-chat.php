<?php
/**
 * Upsellix — plugin root (`add-foundation-onboarding §1.1`).
 *
 * The thin-client plugin (Layer 1, design D1): it enqueues the storefront widget,
 * routes the merchant admin panels, schedules the Action Scheduler jobs, and talks to
 * the SaaS backend over HTTPS. Nothing AI happens here — every AI call goes through the
 * backend (`add-shopper-chat`, `add-content-ingestion-kb`).
 *
 * This file is the WordPress entrypoint. It declares the plugin header, defines the
 * version constants, runs the compatibility guards (PHP/WooCommerce version, HPOS,
 * blocked outbound HTTPS), then bootstraps `WooAIChat\Plugin` on `plugins_loaded` —
 * WooCommerce has to exist first, because the rest of the plugin uses WC CRUD only
 * (HPOS-safe) and Action Scheduler ships with WooCommerce.
 *
 * @package WooAIChat
 *
 * @license GPL-2.0-or-later
 *
 * phpcs:disable WordPress.Files.FileName
 */

/**
 * Plugin Name: Upsellix
 * Plugin URI:  https://upsellix.com/
 * Description:  An AI support chat for WooCommerce. Backend-driven answers, no AI key on the store, encrypted token at rest. (Layer 1 — thin client.)
 * Version:      1.5.0
 * Requires at least: 6.3
 * Requires PHP:      8.0
 * Requires Plugins:  woocommerce
 * Author:       Upsellix
 * Author URI:   https://upsellix.com/
 * License:      GPL-2.0-or-later
 * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:  woocommerce-ai-chat
 * Domain Path:  /languages
 */

declare(strict_types=1);

defined( 'ABSPATH' ) || exit;

/**
 * The constants every later module reads for version, paths, slug, and the option keys
 * that store the activation/lifecycle state (`wai_*` per TR-008–010).
 *
 * `WAI_BACKEND_URL` is the SaaS backend base — the **public** address, because it feeds
 * both the server→server path and the storefront widget's `apiBase`, and the widget runs
 * in a shopper's browser. It defaults to `WAI_DEFAULT_BACKEND_URL` below, so a stock
 * install activates without touching `wp-config.php`; a deployment that needs a different
 * backend defines it and wins. `Auth\BackendUrl` owns the resolution, including the
 * optional `WAI_INTERNAL_BACKEND_URL` shortcut for the server path, and documents why the
 * *public* value is the shared one — and why a blank `define()` still fails loudly instead
 * of falling back to the default.
 */
if ( ! defined( 'WAI_VERSION' ) ) {
	define( 'WAI_VERSION', '1.5.0' );
}
/**
 * The seam version this build was written against — `info.version` in
 * `contracts/openapi.yaml`, NOT this plugin's own release number above.
 *
 * The two are unrelated on purpose. `WAI_VERSION` moves whenever the plugin ships anything;
 * this moves only when the plugin↔backend agreement changes, which is the question
 * `Ops\ApiVersion` asks when it compares this against the `X-WCAI-API-Version` header the
 * backend returns on every response. A merchant several plugin releases behind is usually
 * fine; a merchant a *major* seam version behind is not, and nothing could tell them apart
 * before this constant existed.
 *
 * Kept in step with the contract by `contracts/check_plugin_calls.py`, which fails CI if
 * this string and the contract's `info.version` disagree. Without that check this is a
 * number someone would forget to bump, and a stale value here reports "compatible" forever
 * — the exact failure the header was added to catch.
 */
if ( ! defined( 'WAI_CONTRACT_VERSION' ) ) {
	define( 'WAI_CONTRACT_VERSION', '1.0.0' );
}
if ( ! defined( 'WAI_SLUG' ) ) {
	define( 'WAI_SLUG', 'woocommerce-ai-chat' );
}
if ( ! defined( 'WAI_PLUGIN_FILE' ) ) {
	define( 'WAI_PLUGIN_FILE', __FILE__ );
}
if ( ! defined( 'WAI_PLUGIN_DIR' ) ) {
	define( 'WAI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'WAI_PLUGIN_URL' ) ) {
	define( 'WAI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

// `wai_*` option keys — the only `wp_options` rows the plugin owns (TR-008).
if ( ! defined( 'WAI_OPTION_STORE_TOKEN' ) ) {
	define( 'WAI_OPTION_STORE_TOKEN', 'wai_store_token' );
}
if ( ! defined( 'WAI_OPTION_WIDGET_TOKEN' ) ) {
	define( 'WAI_OPTION_WIDGET_TOKEN', 'wai_widget_token' );
}
if ( ! defined( 'WAI_OPTION_STORE_ID' ) ) {
	define( 'WAI_OPTION_STORE_ID', 'wai_store_id' );
}
if ( ! defined( 'WAI_OPTION_SITE_FINGERPRINT' ) ) {
	define( 'WAI_OPTION_SITE_FINGERPRINT', 'wai_site_fingerprint' );
}
if ( ! defined( 'WAI_OPTION_ACT_LABELS' ) ) {
	define( 'WAI_OPTION_ACT_LABELS', 'wai_activation_labels' );
}
if ( ! defined( 'WAI_OPTION_LICENSE_KEY_HASH' ) ) {
	// Stored hashed (SHA-256) — the only on-site record of which license this install
	// binds. The raw key never persists; re-onboarding after uninstall re-enters it.
	define( 'WAI_OPTION_LICENSE_KEY_HASH', 'wai_license_key_hash' );
}
if ( ! defined( 'WAI_OPTION_CONSENT' ) ) {
	// Data-processing consent (NFR-032/RC-001) is recorded as a unix timestamp + a
	// DPA version hash, so a later change to the DPA can be detected as needing
	// re-consent.
	define( 'WAI_OPTION_CONSENT', 'wai_consent_recorded' );
}
if ( ! defined( 'WAI_OPTION_SUBSCRIPTION_CACHE' ) ) {
	// The 24h transient fallback (NFR-037): keep the subscription state on disk so a
	// downed backend does not blank the gate. Plain `wp_options` row, not a transient,
	// because a transient losing its value under cache eviction would silently make
	// `last-known` look like "never known".
	define( 'WAI_OPTION_SUBSCRIPTION_CACHE', 'wai_subscription_state' );
}
if ( ! defined( 'WAI_TRANSIENT_SUBSCRIPTION_STATE' ) ) {
	define( 'WAI_TRANSIENT_SUBSCRIPTION_STATE', 'wai_subscription_state_transient' );
}
if ( ! defined( 'WAI_OPTION_KB_PAGE_OVERRIDES' ) ) {
	// Merchant include/exclude decisions for pages, `[ page_id => bool ]` (design D-6c).
	// Written by the Knowledge Base page (§5.3); read by `Sync\PageSelector` as the
	// override that outranks the slug/title heuristic in both directions.
	define( 'WAI_OPTION_KB_PAGE_OVERRIDES', 'wai_kb_page_overrides' );
}
if ( ! defined( 'WAI_OPTION_WIDGET_SETTINGS' ) ) {
	// The merchant's widget configuration (FR-012): appearance, behaviour, locale
	// override, and the RC-006/RC-009 compliance toggles, as one array row. One row
	// rather than a dozen: the Settings form writes them together, the widget reads them
	// together, and a dozen `wp_options` rows would be a dozen autoloaded queries for a
	// value that is only ever used whole.
	define( 'WAI_OPTION_WIDGET_SETTINGS', 'wai_widget_settings' );
}
if ( ! defined( 'WAI_OPTION_FAILURE_STREAK' ) ) {
	// Consecutive backend failures (FR-038's threshold of 3) and the last outcome, as a
	// plain `wp_options` row rather than a transient: the count has to survive the cache
	// eviction that an unhealthy host is *more* likely to have, or the streak resets to
	// zero forever and the merchant is never alerted.
	define( 'WAI_OPTION_FAILURE_STREAK', 'wai_backend_failure_streak' );
}
if ( ! defined( 'WAI_TRANSIENT_STATUS_SURFACE' ) ) {
	// The cached status-surface verdict. A transient is right here — an expired one just
	// means the next suspected outage re-pings, which is the correct behaviour, and the
	// TTL is what keeps a fleet-wide outage from turning into a fleet-wide ping storm.
	define( 'WAI_TRANSIENT_STATUS_SURFACE', 'wai_status_surface_state' );
}
if ( ! defined( 'WAI_TRANSIENT_RATE_LIMITED' ) ) {
	// When the backend last told us to slow down, and for how long. Holds the unix time the
	// `Retry-After` it sent expires at.
	//
	// A transient rather than an option because expiry *is* the semantics: a rate limit that
	// has elapsed is a rate limit that no longer exists, and a row that outlived its meaning
	// would leave a store showing "we are limiting your requests" indefinitely. That is the
	// opposite trade-off from `WAI_OPTION_FAILURE_STREAK` next door, which is an option
	// precisely because losing it silently un-alerts a merchant.
	define( 'WAI_TRANSIENT_RATE_LIMITED', 'wai_rate_limited_until' );
}
if ( ! defined( 'WAI_DEFAULT_BACKEND_URL' ) ) {
	// The production backend (ADR-005/ADR-006). `Auth\BackendUrl::canonical()` falls back to
	// this when a deployment defines no `WAI_BACKEND_URL` of its own, which is what lets a
	// stock install activate without a `wp-config.php` edit.
	//
	// A separate constant rather than a literal inside `canonical()` for two reasons: it
	// keeps the shipped hostnames in one readable block with the surface URLs below, and it
	// gives the test suite something to override — asserting the fallback needs a value the
	// test controls, and `WAI_BACKEND_URL` itself cannot serve that role because the branch
	// under test is the one where it is *undefined*.
	define( 'WAI_DEFAULT_BACKEND_URL', 'https://api.upsellix.com' );
}
if ( ! defined( 'WAI_STATUS_SURFACE_URL' ) ) {
	// The independent status surface (D15, `add-platform-ops-surfaces`). Deliberately a
	// *separate* constant from `WAI_BACKEND_URL` and hard-defaulted rather than derived
	// from it: a surface that shares configuration with the backend it reports on would
	// be misconfigured by the same mistake, which is the failure D15 exists to prevent.
	define( 'WAI_STATUS_SURFACE_URL', 'https://status.upsellix.com/state.json' );
}
if ( ! defined( 'WAI_UPDATES_MANIFEST_URL' ) ) {
	// The private distribution/update endpoint (NFR-036, `add-platform-ops-surfaces` §3,
	// design D-4). Same reasoning as `WAI_STATUS_SURFACE_URL`: static, hard-defaulted, and
	// on its own hostname rather than derived from `WAI_BACKEND_URL` — the distribution
	// path exists specifically to stay reachable when the backend is what needs the fix.
	// Built and published by `updates/build.sh` / `updates/deploy.sh`.
	define( 'WAI_UPDATES_MANIFEST_URL', 'https://updates.upsellix.com/plugin-info.json' );
}
if ( ! defined( 'WAI_ACTION_SCHEDULER_GROUP' ) ) {
	// Group the metering epic's jobs share — surfaces in the AS admin view under one
	// filter, and lets an operator clear our scheduled work without touching others.
	define( 'WAI_ACTION_SCHEDULER_GROUP', 'wc_ai_agent' );
}

/**
 * Load the translations for the `woocommerce-ai-chat` text domain (FR-090,
 * `add-merchant-insight-ops §5.1`).
 *
 * Hooked to `init`, not `plugins_loaded`. WordPress 6.7 started emitting a
 * `_doing_it_wrong` notice for text domains loaded before `init`, because core defers
 * its own JIT translation loading to that point; a merchant on 6.7+ would otherwise see
 * a PHP notice from a plugin doing nothing wrong on the 6.3 floor this plugin supports.
 * Nothing renders a translated admin string before `init` — the wizard and the Health
 * Check pages run on `admin_menu`/`admin_post`, both later — so the domain is in place
 * before the first string is asked for.
 *
 * The one exception is the missing-autoloader notice in `woocommerce_ai_chat_bootstrap()`
 * below, which by definition runs when the plugin cannot load its own classes. That
 * message stays untranslated in practice, and it is the right trade: an English sentence
 * telling a merchant to run `composer install` beats a fatal error in the translation
 * layer of a plugin that is already broken.
 *
 * `Domain Path: /languages` in the header covers the WordPress.org language pack; this
 * call covers a `.mo` shipped in or dropped into the plugin's own `languages/`.
 */
function woocommerce_ai_chat_load_textdomain(): void {
	load_plugin_textdomain(
		'woocommerce-ai-chat',
		false,
		dirname( plugin_basename( WAI_PLUGIN_FILE ) ) . '/languages'
	);
}
add_action( 'init', 'woocommerce_ai_chat_load_textdomain' );

/**
 * Bootstrap the plugin on `plugins_loaded`.
 *
 * Fired at priority 20 (after WooCommerce's own `plugins_loaded` hook at priority 10)
 * so `WC()` exists before we do anything that depends on it: HPOS compatibility is
 * declared on `before_woocommerce_init`, but the rest of the plugin waits for Woo here.
 *
 * The composer autoload is present in production (`composer install --no-dev` puts it
 * in the plugin zip) and in development. If it is missing, the activation hook fires a
 * notice and stops — the plugin cannot run without its autoloader (the rest is the
 * PSR-4 source, which the autoloader exposes).
 */
function woocommerce_ai_chat_bootstrap(): void {
	$autoload = WAI_PLUGIN_DIR . 'vendor/autoload.php';
	if ( ! file_exists( $autoload ) ) {
		add_action(
			'admin_notices',
			static function (): void {
				echo '<div class="notice notice-error"><p>';
				echo esc_html(
					__(
						'The Upsellix plugin is missing its dependencies. Run `composer install` in the plugin directory or reinstall the plugin zip.',
						'woocommerce-ai-chat'
					)
				);
				echo '</p></div>';
			}
		);
		return;
	}
	require_once $autoload;

	\WooAIChat\Plugin::instance();
}
add_action( 'plugins_loaded', 'woocommerce_ai_chat_bootstrap', 20 );

/**
 * Activation hook: register the `wai_*` options with sensible defaults, schedule the
 * daily Action Scheduler job. The actual license exchange happens through the onboarding
 * wizard; activation just primes the store and the gate to "inactive / await onboarding".
 *
 * Hooked from `register_activation_hook` below so it only fires on activation, never
 * on every load — `remove_action('plugins_loaded', …)` is not a security boundary here,
 * it is the difference between scheduling one job and scheduling N jobs.
 *
 * @param bool $network_wide Whether the plugin is being network-activated (multisite).
 *                           v1 does not support multisite; a network activation refuses
 *                           with a notice rather than half-working.
 */
function woocommerce_ai_chat_activate( $network_wide = false ): void {
	if ( $network_wide ) {
		wp_die(
			esc_html__(
				'Upsellix does not support multisite network activation in v1. Activate it per-site.',
				'woocommerce-ai-chat'
			)
		);
	}
	if ( ! class_exists( \WooAIChat\Plugin::class ) ) {
		// The activation hook runs *before* `plugins_loaded`, so `bootstrap()` has not
		// registered the autoloader yet. Load it here; every class this function touches
		// (Compatibility, Lifecycle) is PSR-4 and unreachable without it.
		$autoload = __DIR__ . '/vendor/autoload.php';
		if ( file_exists( $autoload ) ) {
			require_once $autoload;
		} else {
			// No autoloader — a source checkout where `composer install` has not run. The
			// zip always ships one (`updates/build.sh` runs `composer install --no-dev`),
			// so this path is a developer's, not a merchant's.
			//
			// This used to require exactly `Compatibility` and `Lifecycle`, "the classes
			// used below". They are the classes *called* below, which is not the same
			// thing: `Compatibility::backend_url_ok()` reaches `Auth\BackendUrl`, and
			// activation died with `Class "WooAIChat\Auth\BackendUrl" not found` — a
			// fatal, so wp-cli exits 255 and `wordpress-init` takes the whole
			// `docker compose up` down with it. Enumerating one more file would leave the
			// next transitive reference to find the same way.
			//
			// So register the PSR-4 rule the composer autoloader would have, over the same
			// `src/` tree. Prepended is deliberate: if a real autoloader is registered
			// afterwards it still wins for anything this cannot resolve.
			spl_autoload_register(
				static function ( string $class_name ): void {
					if ( 0 !== strpos( $class_name, 'WooAIChat\\' ) ) {
						return;
					}
					$relative = str_replace( '\\', '/', substr( $class_name, strlen( 'WooAIChat\\' ) ) );
					$path     = __DIR__ . '/src/' . $relative . '.php';
					if ( is_file( $path ) ) {
						require_once $path;
					}
				}
			);
		}
	}
	\WooAIChat\Compatibility::check_and_notice();
	\WooAIChat\Lifecycle::activate();
}
register_activation_hook( __FILE__, 'woocommerce_ai_chat_activate' );

/**
 * Deactivation hook: unschedule the Action Scheduler job and clear the subscription
 * transient. The store token is retained on deactivation (TR-008/NFR-039) so a merchant
 * who deactivates by accident and reactivates does not have to re-onboard — a revoked
 * token is a backend-side concern, surfaced by the next `/v1/auth/status`, not by
 * wiping the merchant's stored credentials on every deactivate.
 */
function woocommerce_ai_chat_deactivate(): void {
	if ( ! class_exists( \WooAIChat\Lifecycle::class ) ) {
		$autoload = __DIR__ . '/vendor/autoload.php';
		if ( file_exists( $autoload ) ) {
			require_once $autoload;
		} else {
			require_once __DIR__ . '/src/Lifecycle.php';
		}
	}
	\WooAIChat\Lifecycle::deactivate();
}
register_deactivation_hook( __FILE__, 'woocommerce_ai_chat_deactivate' );

// Uninstall lives in `uninstall.php`, gated by `WP_UNINSTALL_PLUGIN` — see NFR-039.
