=== WooCommerce AI Chat ===
Contributors: wcai
Tags: woocommerce, chat, ai, support, customer-service
Requires at least: 6.3
Tested up to: 6.5
Requires PHP: 8.0
Stable tag: 1.4.2
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires Plugins: woocommerce

An AI support chat for WooCommerce. Backend-driven answers, no AI key required on the store, encrypted token at rest.

== Description ==

WooCommerce AI Chat is a thin-client plugin that adds an AI support chat to your store.
It does **not** run AI on your server; instead, it talks to a SaaS backend over HTTPS
to obtain grounded answers from your catalogue. The plugin stores no AI provider key
and no vector index locally; it only enqueues the storefront widget and forwards
configuration and merchant decisions to the backend.

Key behaviour:

* **No AI key on your store.** Cost control lives on the backend (per-store metering +
  quota enforcement), not in your store's database.
* **Encrypted token at rest.** The private store token is AES-256-CBC encrypted
  using your site's `wp_salt('auth')` secret; the widget token is intentionally
  public, scoped to chat for your store.
* **Subscription gate.** The storefront widget only renders when your subscription
  state is active (or in grace); lapsed subscriptions hide the widget gracefully
  while keeping `/wp-admin` accessible.
* **HPOS-compatible.** Declares compatibility with WooCommerce's High-Performance
  Order Storage and writes back via WC CRUD only.
* **GDPR posture.** Explicit data-processing consent is required before activation
  completes; uninstalling the plugin purges local data and sends a best-effort
  erasure request to the backend. The Data Processing Agreement is linked from the
  onboarding wizard and the GitHub repo.

A backend is required. Define `WAI_BACKEND_URL` in `wp-config.php` to point at the
SaaS backend you have a subscription with. It must be the service's **public** https
address — the one a browser can open — because your shoppers' browsers use it too, to
reach the chat widget. The plugin refuses to activate if it cannot reach the backend
over HTTPS.

For more information, see the project README and the Data Processing Agreement at
the project documentation site.

== Installation ==

1. Install and activate WooCommerce 8.0 or later.
2. Upload the plugin zip via `Plugins → Add New → Upload Plugin`, or place the
   unzipped `woocommerce-ai-chat/` directory under `wp-content/plugins/`.
3. Activate. The activation notice will check PHP and WooCommerce versions and
   outbound HTTPS, and refuse with a plain-language message if a precondition fails.
4. Define `WAI_BACKEND_URL` in `wp-config.php`:

   `define( 'WAI_BACKEND_URL', 'https://api.wcai.example.invalid' );`

   Use the public https address. Both your store's server and your shoppers' browsers
   are given this URL, so a private or internal-only address stops the storefront chat
   widget from loading. If your server reaches the service by a shorter private route
   (a container network, a VPC link), put *that* in the optional
   `WAI_INTERNAL_BACKEND_URL` and leave `WAI_BACKEND_URL` public — almost no
   installation needs this.

5. Open the onboarding wizard via `WooCommerce → AI Chat`. Subscribe, enter your
   license key, accept the data-processing terms, and activate.

== Frequently Asked Questions ==

= Do I need an OpenAI key? =

No. WooCommerce AI Chat does **not** store, request, or accept an AI provider key
anywhere. The backend uses its own keys. The cost-control mechanism (metering,
quota enforcement) lives on the backend and is gated by your subscription.

= What happens if my subscription lapses? =

The widget hides itself on the storefront and your `wp-admin` continues to display
renewal prompts. No raw error is shown to shoppers — the widget degrades silently
until you renew.

= What happens to my data when I uninstall? =

On uninstall, the plugin empties every `wai_*` option it owns and sends a
best-effort erasure request to the backend. Local WooCommerce data (products,
orders, customers) is **never** touched. Data retained on the backend after the
erasure request fires is purged by the backend's grace-end schedule (per the Data
Processing Agreement).

= Can the chat answer in languages other than my store's default? =

Yes. The backend detects the shopper's language and answers in it, grounded in your
store content regardless of the language it was written in.

== Changelog ==

= 1.4.2 =

* Live re-index progress: the onboarding wizard's Indexing step and the Knowledge Base
  page now show a moving bar with real counts ("34 of 52 items sent"), the phase being
  indexed, and a rough time estimate — powered by the plugin's own walk record instead of
  a backend stub that always read idle.
* Honest completion: a re-index whose items were rejected by the subscription's content
  limit now reports that outcome in the error style, instead of announcing success above
  an empty knowledge base. Partial rejections report both counts.
* The "Re-index scheduled" toast was retired; the progress panel is the single voice for
  a running re-index, and a stale success notice can no longer sit above a failure.
* The quality checklist no longer repeats the same improvement tip twice.
* A walk stopped by the plan's memory cap now closes its progress record instead of
  leaving the bar running until it aged out as stale.

= 1.4.1 =

* Fixed: after starting a re-index, the Knowledge Base showed "Indexing status is
  unavailable right now." instead of confirming that the re-index was scheduled. The
  confirmation is now reported from the plugin's own queue (the same message the backend
  reports once its queue is live), and the "unavailable" wording is reserved for the case
  where the indexing status genuinely could not be checked.
* Fixed: a fresh store's first sync now starts the moment activation succeeds, instead of
  waiting for the nightly job (or a manual re-index) — "a first sync usually finishes
  within a few minutes of setup" is now actually true.
* Fixed: the wizard's indexing step stopped polling on the backend's very first answer,
  so the promised live progress never moved. It keeps watching until content is actually
  indexed, and says plainly when it stops watching rather than leaving a stale line.
* Fixed: resubmitting an old setup form from browser history could reopen guided setup
  on a store that had already finished it.
* Fixed: the Knowledge Base's panel scroll now respects "reduce motion" system settings.
* Translation template regenerated — all 297 plugin strings are translatable again.

= 1.4.0 =

* The setup wizard now walks all six of the steps it has always listed. Previously, clicking
  Activate jumped straight to "your store is connected" and steps 4, 5, and 6 were numbers in
  the sidebar with no screens behind them. They are now real pages:
    * **Indexing** shows live progress as your products, categories, and pages are read, with
      a running count of what has been indexed so far.
    * **Content quality check** shows your score against the bar the assistant needs to clear,
      what to improve, and — if you are below it — a "Publish anyway" button so a small
      catalogue is never permanently blocked.
    * **Widget colour** lets you pick the storefront chat colour during setup instead of
      hunting for it in Settings afterwards, with a live preview of the actual colour used.
* The sidebar step list now links back to any step you have already reached, so you can
  review indexing or change your colour without restarting setup.
* Every step of the post-activation flow can be skipped, on every screen including the last.
  Your widget is already live by that point, so none of these screens can trap you, and
  everything they set has a permanent home in the dashboard.
* Stores that activated before this release are unaffected: they keep going straight to the
  finished screen rather than being walked back through setup they already completed.

= 1.3.0 =

* Fixed: on installations where the store's server and its shoppers reach the AI service
  at different addresses, the storefront chat widget was given the server's address and
  never loaded — with nothing to show for it. No error, no admin notice, and Health Check
  reported the store as completely healthy. `WAI_BACKEND_URL` is now always the public
  address, used by both; a new optional `WAI_INTERNAL_BACKEND_URL` carries the server's
  private shortcut for the deployments that have one. Single-address installations, which
  is nearly all of them, are unaffected and need no change.
* Health Check has a new "Storefront connection" row reporting the address your shoppers'
  browsers are given, and whether they can actually use it. The other six rows describe
  what the AI service can see about your store, so none of them could ever have caught a
  storefront that never reached it.
* The chat widget is no longer loaded at all when its address is unusable — an unencrypted
  address, or one only your server can resolve. It previously loaded and then failed
  silently in the shopper's browser.
* Fixed: the setup wizard's step rail showed "Indexing", "Quality gate", and "Widget
  colour" as steps 4-6 with no way to reach them, which read as a wizard that stopped
  partway through. The rail now says plainly that those continue automatically in your
  dashboard, and "Open the dashboard" on the finished screen now goes straight to the
  Knowledge Base page — where indexing progress and the quality gate actually are.
* Fixed: opening the "Re-index your store?" confirmation from an empty Knowledge Base
  added it to the bottom of the page, below content that was still hidden, with no visual
  link to the button that opened it. It now renders next to the empty-state actions and
  scrolls into view when opened, matching the manual-entry panel's behaviour.
* Fixed: the chat widget's message input showed a double (sometimes triple) focus ring.
  Root cause was a stale compiled widget bundle predating an earlier fix already present
  in source; rebuilding and shipping this release resolves it for any site running the
  affected build.

= 1.2.0 =

* Fixed: the setup wizard was unreachable — every link into it ("Start setup", "Continue
  setup") died on "Sorry, you are not allowed to access this page", even for
  administrators. The page is now registered the way WordPress 6.x supports while staying
  out of the sidebar menu.
* Fixed: manually added knowledge-base answers were silently deleted by the nightly
  content sync within 24 hours of being added. They are now tracked locally and included
  in the sync manifest, so they persist.
* Fixed: toggling a manual knowledge-base entry off and back on actually deleted it while
  reporting success. Re-including now restores the stored answer.
* Fixed: the chat panel could render already open on page load; it now stays closed until
  the shopper opens it.
* The widget settings that were saved but never applied now work: trigger delay,
  scroll-depth trigger, and the age/content disclaimer text. The child-audience flag is
  now sent to the AI service with every chat request, though the service does not yet act
  on it — the setting's description has been corrected so it no longer implies that
  ticking it satisfies COPPA or GDPR Article 8 on its own.
* Fixed: Health Check showed a green "Healthy" banner with no rows exactly when the AI
  service was unreachable — the one moment the page matters most. It now reports the
  failed connection with a plain-language fix.
* Fixed: a missing or misconfigured backend URL on an activated store white-screened the
  entire WordPress admin instead of showing the explanatory notice.
* Fixed: uninstalling left six settings rows behind, and its data-erasure request to the
  AI service sent the encrypted token blob instead of the token, so the request could
  never have been accepted. Local removal is now complete and the request is correctly
  formed. Note that server-side erasure still relies on the backend's grace-end purge
  schedule described in the Data Processing Agreement.
* Renamed the mislabeled "Admin panel language" setting to "Chat widget language" — it
  always controlled the storefront chat window's language, never the admin.
* Redesign of every admin page: a clean, neutral, light interface that matches the
  WordPress admin. The panels no longer switch to a dark palette based on your operating
  system's appearance setting.

= 1.1.1 =

* Fixed: deleting the plugin from the Plugins screen got stuck on "Deleting…" and never
  completed. `uninstall.php` called into code that read several `wai_*` constants it
  never defined itself — WordPress never loads the main plugin file for this step, so
  every deletion fatal-errored immediately. Deletion now completes and still purges the
  same local data and best-effort backend erasure request as before.

= 1.1.0 =

* The plugin now has its own top-level "AI Chat" menu in the WordPress sidebar. Its
  pages were previously submenu items of WooCommerce, which meant they disappeared
  without warning whenever WooCommerce was inactive or another plugin reorganised that
  menu. WooCommerce is still required to run the plugin; only the menu moved.
* Fixed: the storefront chat widget never appeared. The compiled widget bundle shipped
  in the release package was a stale artifact that loaded and then did nothing. The
  release build now compiles the widget from source and refuses to publish without it.
* Fixed: most widget settings had no effect. Accent colour, launcher position, panel
  title, placeholder text, contact link, locale override — and the "Enable chat widget"
  switch itself — were saved but never reached the storefront. The trigger delay,
  scroll-depth trigger, custom disclaimer, and child-audience settings are still not
  applied by the widget; they are saved and will be honoured in a later release.
* The setup wizard now follows the full six-step flow, with a step rail, live
  connectivity feedback on the license field, and a persistent post-activation prompt.
* Added an explicit notice when `WAI_BACKEND_URL` is not defined, instead of the plugin
  silently doing nothing.
* Admin pages now require the `manage_options` capability and follow the operating
  system's light or dark appearance. Sites needing wider access can use the new
  `wcai_admin_capability` filter.

= 1.0.1 =

* Dry-run release for the private plugin update mechanism (`add-platform-ops-surfaces`
  §3–§4): proves discover → download → install works end to end through the update
  server, on a version an already-installed store can actually update from.
* No merchant-facing behaviour changes in this release — its whole point is exercising
  the distribution path itself, not shipping new functionality (design D-4).

= 0.1.0 =

* Initial onboarding wizard, plugin lifecycle, encrypted token storage, and the
  daily Action Scheduler subscription check.
* This is the foundation release; chat answering, content ingestion, and the merchant
  admin panels ship in follow-up releases. The activation spine is the standalone
  outcome this release delivers.

== Upgrade Notice ==

= 1.0.1 =

Dry-run release proving the private update mechanism. No merchant-facing changes.

= 0.1.0 =

Initial release. Install via the onboarding wizard and configure the backend URL in
`wp-config.php`.